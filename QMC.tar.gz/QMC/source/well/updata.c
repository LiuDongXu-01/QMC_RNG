#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>
#include "datastruct.h"
#include "myfunction.h"


int min(int a, int b)
{
    if(a<=b)
    {
        return a;
    }else{
        return b;
    }
}

int max(int a, int b)
{
    if(a<=b)
    {
        return b;
    }else{
        return a;
    }
}

void Diag_Update(void)
{
	int i, j, r,p, I, I1, ns, posi;
	int vert,lift_sum,right_sum;
	double prob_a, prob_b, w;
	for(p=0;p<MM;p++)
	{
		vert = Opstring[p][1];
		if(vert==-1)
		{
			r = min((int)(Random()*Nbond),(Nbond-1));
            		lift_sum = 0;
			for(j=0;j<=Vert_Size-1;j++)
			{
				lift_sum = lift_sum + Mosp[j]*Lattice[Bsite[r][j]];
			}
			right_sum = lift_sum;
			I = Wight1(lift_sum,right_sum);
			w = Wight[paraenv][I];
			prob_a = (w*Nbond*Beta[paraenv])/(MM-nh);
			if(Random() < prob_a)
			{
				Opstring[p][0] = 1;
				Opstring[p][1] = I;
				Opstring[p][2] = r;
				nh++;
			}else{
				continue;
			}
		}else{
			if(Opstring[p][0]==1) /* only the diagonal operator could be delete */
			{
                		I1 = Opstring[p][1];
				w = Wight[paraenv][I1];
				prob_b = (MM-nh+1)/(w*Beta[paraenv]*Nbond);
				if(Random()< prob_b)
				{
					Opstring[p][0] = -1;
					Opstring[p][1] = -1;
					Opstring[p][2] = -1;
					nh--;
				}else{
					continue;
				}
			}else{
                    		for(j=0;j<=Vert_Size-1;j++)
                    		{
                        		Lattice[Bsite[Opstring[p][2]][j]] = Vertex_Leg[1][Opstring[p][1]*Vert_Size + j];
                    		}
			}
		}
	}
}


void Adjustcutoff(void)
{
    /*warning this sub function will change a single thread's Global pointer Opsting, be careful with it*/
	int i, j;
    	int newmm;
    	int **opstring_temp = NULL;
    	newmm = nh + nh/4;
	if(newmm>MM)
	{
    		opstring_temp = (int **)malloc(2*newmm*sizeof(int));
        	for(i=0;i<newmm;i++)
        	{
            		opstring_temp[i] = (int *)malloc(3*sizeof(int));
        	}
        	for(i=0;i<newmm;i++)
        	{
            		opstring_temp[i][0] = -1;
            		opstring_temp[i][1] = -1;
            		opstring_temp[i][2] = -1;
        	}
        	for(i=0;i<MM;i++)
        	{
            		for(j=0;j<3;j++)
            		{
                		opstring_temp[i][j] = Opstring[i][j];
            		}
        	}
        	if(Opstring!=NULL)
        	{
            		for(i=0;i<=MM-1;i++)
            		{
                		if(Opstring[i]!=NULL)
                		{
                    			free(Opstring[i]);
                    			Opstring[i] = NULL;
                		}
            		}
	    		Opstring = NULL;
        	}
		if(Opstring==NULL)
        	{
            		Opstring = (int **)malloc(2*newmm*sizeof(int));
            		for(i=0;i<=newmm-1;i++)
            		{
                		Opstring[i] = (int *)malloc(3*sizeof(int));
            		}
        	}
        	for(i=0;i<=newmm-1;i++)
        	{
             		Opstring[i][0] = opstring_temp[i][0];
             		Opstring[i][1] = opstring_temp[i][1];
             		Opstring[i][2] = opstring_temp[i][2];
        	}
        	MM = newmm;
	}
	if(opstring_temp!=NULL)
    	{
        	for(i=0;i<=newmm-1;i++)
        	{
            		if(opstring_temp[i]!=NULL)
            		{
                		free(opstring_temp[i]);
                		opstring_temp[i] = NULL;
            		}
        	}
        	free(opstring_temp);
        	opstring_temp = NULL;
    	}

}


void Loop_Update(double tracation)  /*tracation loop length*/
{
	int i,j, vert_link, bound, index, temp, V1, V2, index1, index2, inner_shift, out_shift, link_postion, total_loop_length, total_loop_pass_count;
	int init_leg, init_index,init_shift, in_index, in_leg, out_index, out_leg, in_vert_index, out_vert_index, sgn;
	int *LinktoVirtual, c, k;
	int Total_Link, Trac;
	double rho = 0.0;
    Total_Link = 2*Vert_Size*nh;
    Trac = (int)((double)(nh)*2*Vert_Size*tracation);
    Link_Table = (int *)malloc(Total_Link*sizeof(int));
    LinktoVirtual = (int *)malloc(nh*sizeof(int)); /*stored the nh no-zeros operators in virtual time position in the virtual time sequence*/
    c = 0;
    for(i=0;i<=MM-1;i++)
    {
        if(Opstring[i][1]!=-1)
        {
            LinktoVirtual[c] = i;
            c++;
        }
    }
    if(c!=nh)
    {
        printf("error havened, please check Opstrings");
        printf("\n");
        printf("error code -1 will be return");
        printf("\n");
    }

    /*init the linktable*/
    for(i=0;i<=Total_Link-1;i++)
    {
        Link_Table[i] = i;
    }


	for(i=0;i<=Nsite-1;i++)
	{
		FLAGE[i].first = -1;
		FLAGE[i].last = -1;
	}
    for(i=0;i<=Total_Link-1;i++)
    {
        index = i/(2*Vert_Size);
        link_postion = LinktoVirtual[index];  /*location the vertex position in the virtual time*/
        j = i%(2*Vert_Size);  /*leg position relative in the vertex, j<VertSize-1 is in previous leg before operator,else is in last leg which after the operator*/
        if(Opstring[link_postion][1]!=-1)
        {
            bound = Opstring[link_postion][2];  /*from Opstring to obtain bond postion and to ensure leg's space position*/
            if(bound!=-1)
            {
		if(j<Vert_Size)
		{
                	if(FLAGE[Bsite[bound][j]].last!=-1)
                	{
                        	V1 = FLAGE[Bsite[bound][j]].last;
                        	Link_Table[V1] = i;
                        	Link_Table[i] = V1;
                        	if(FLAGE[Bsite[bound][j]].first==-1)
                        	{
                           		FLAGE[Bsite[bound][j]].first = i;
                        	}
			}else{
	                	FLAGE[Bsite[bound][j]].first = i;		
			}	
		}else{
                        FLAGE[Bsite[bound][j-Vert_Size]].last = i;
		}
            }else{
                printf("error happened, please check code!,error code -2 will be shown on screen!!");
                printf("\n");
            }
        }else{
            continue;
        }
    }

	for(i=0;i<=Nsite-1;i++)
	{
		V1 = FLAGE[i].first;
		if(V1!=-1)
		{
			V2 = FLAGE[i].last;
            temp = Link_Table[V1];
            Link_Table[V1] = Link_Table[V2];
            Link_Table[V2] = temp;
		}else{
			continue;
		}
	}

    /*init the linktable*/
    //	PrintF_Link_Table();
    //	Test_Link(Link_Table,Opstring,LinktoVirtual,Total_Link,MM);
	//for(i=0;i<=Ph.mm-1;i++)
	//{
	//	printf("%d",opstring[i].vert_index);/*counter for reach the target position from the orgin position by move up*/
	//}
    int index_after;

    if(nh!=0)
    {
        /*chose the start point in virtual, */
	total_loop_pass_count = 0;
	rho = 0.0;
        while(total_loop_pass_count<=Trac)
        {
            init_leg = min((int)(((double)(2*Vert_Size*nh))*Random()),2*Vert_Size*(nh-1));
            init_index = Opstring[LinktoVirtual[init_leg/(2*Vert_Size)]][1];
            init_shift = init_leg%(2*Vert_Size);
            if(init_shift<Vert_Size)
            {
                if(Vertex_Leg[0][init_index*Vert_Size+init_shift]==0)/*S^+ propagate upward*/
                {
                    sgn = 1;
                }else{
                	if(Vertex_Leg[0][init_index*Vert_Size+init_shift]==Mos)/*S^- propagate upward */
                	{
                    		sgn = 0;
                	}else{
                    		if(Random()<0.5)
                    		{
                        		sgn = 0;
                    		}else{
                        		sgn = 1;
                    		}
			}
                }
            }else{
                if(Vertex_Leg[1][init_index*Vert_Size+init_shift-Vert_Size]==0) /*S^- propagate downward */
                {
                    sgn = 0;
                }else{
                	if(Vertex_Leg[1][init_index*Vert_Size+init_shift-Vert_Size]==Mos)  /*S^+ propagate downward*/
                	{
                    		sgn = 1;
                	}else{
                    		if(Random()<0.5)
                    		{
                        		sgn = 0;
                    		}else{
                        		sgn = 1;
                    		}
			}
                }
            }
	    in_leg = init_leg;
            do{
                vert_link = in_leg/(2*Vert_Size);
                in_index = Opstring[LinktoVirtual[vert_link]][1];
                inner_shift = in_leg%(2*Vert_Size);
                Choose_Leg(in_index,inner_shift,&out_index,&out_shift,sgn,total_loop_pass_count);
                Opstring[LinktoVirtual[vert_link]][1] = out_index;
                Opstring[LinktoVirtual[vert_link]][0] = Vertex_Type[out_index];
                out_leg = vert_link*(2*Vert_Size) + out_shift;
                if(out_leg==init_leg)
                {
                    total_loop_pass_count++;
                    break;
                }
                in_leg = Link_Table[out_leg];
                total_loop_pass_count++;
            }while(in_leg!=init_leg);
        }
	for(i=0;i<=Nsite-1;i++)
	{
		if(FLAGE[i].first!=-1)
		{
		    vert_link = FLAGE[i].first/(2*Vert_Size);
		    inner_shift = FLAGE[i].first%(2*Vert_Size);
            	    Lattice[i] = Vertex_Leg[0][Opstring[LinktoVirtual[vert_link]][1]*Vert_Size+inner_shift];
		}else{
			if(Random()<0.5)
            		{
               			if(Lattice[i]==Mos)
                		{
                    			Lattice[i]--;
					continue;
                		}
				if(Lattice[i]==0)
                		{
                    			Lattice[i]++;
                		}else{
                    			Lattice[i]++;
                		}
            		}else{
                		continue;
            		}
		}
	}
    }
   
 
	  //  Test_Link(Link_Table,Opstring,LinktoVirtual,Total_Link,MM);



    if(Link_Table!=NULL)
    {
        free(Link_Table);
        Link_Table = NULL;
    }

    if(LinktoVirtual!=NULL)
    {
        free(LinktoVirtual);
        LinktoVirtual = NULL;
    }

}



void Loop_Update1(double tracation)  /*tracation loop length*/
{
	int i,j, vert_link, bound, index, temp, V1, V2, index1, index2, inner_shift, out_shift, link_postion, total_loop_length, total_loop_pass_count, loop_numb;
	int init_leg, init_index,init_shift, in_index, in_leg, out_index, out_leg, in_vert_index, out_vert_index, sgn;
	int *LinktoVirtual, c, k;
	int Total_Link, Trac;
	double rho;
	double *rho1 = (double *)malloc(3*sizeof(double));
        int contral, loop_cont;
//	nh = Sum1(Nhstring,2*Nt);
    Total_Link = 2*Vert_Size*nh;
    Trac = (int)((double)(MM)*tracation);
    Link_Table = (int *)malloc(Total_Link*sizeof(int));
    LinktoVirtual = (int *)malloc(nh*sizeof(int)); /*stored the nh no-zeros operators in virtual time position in the virtual time sequence*/
    c = 0;
    rho1[0] = 0.0;
    rho1[1] = 0.0;
    rho1[2] = 0.0;
    for(i=0;i<=MM-1;i++)
    {
        if(Opstring[i][1]!=-1)
        {
            LinktoVirtual[c] = i;
            c++;
        }
    }
    if(c!=nh)
    {
        printf("error havened, please check Opstrings");
        printf("\n");
        printf("error code -1 will be return");
        printf("\n");
    }

    /*init the linktable*/
    for(i=0;i<=Total_Link-1;i++)
    {
        Link_Table[i] = i;
    }


	for(i=0;i<=Nsite-1;i++)
	{
		FLAGE[i].first = -1;
		FLAGE[i].last = -1;
	}
    for(i=0;i<=Total_Link-1;i++)
    {
        index = i/(2*Vert_Size);
        link_postion = LinktoVirtual[index];  /*location the vertex position in the virtual time*/
        j = i%(2*Vert_Size);  /*leg position relative in the vertex, j<VertSize-1 is in previous leg before operator,else is in last leg which after the operator*/
        if(Opstring[link_postion][1]!=-1)
        {
            bound = Opstring[link_postion][2];  /*from Opstring to obtain bond postion and to ensure leg's space position*/
            if(bound!=-1)
            {
		if(j<Vert_Size)
		{
                	if(FLAGE[Bsite[bound][j]].last!=-1)
                	{
                        	V1 = FLAGE[Bsite[bound][j]].last;
                        	Link_Table[V1] = i;
                        	Link_Table[i] = V1;
                        	if(FLAGE[Bsite[bound][j]].first==-1)
                        	{
                           		FLAGE[Bsite[bound][j]].first = i;
                        	}
			}else{
	                	FLAGE[Bsite[bound][j]].first = i;		
			}	
		}else{
                        FLAGE[Bsite[bound][j-Vert_Size]].last = i;
		}
            }else{
                printf("error happened, please check code!,error code -2 will be shown on screen!!");
                printf("\n");
            }
        }else{
            continue;
        }
    }

	for(i=0;i<=Nsite-1;i++)
	{
		V1 = FLAGE[i].first;
		if(V1!=-1)
		{
			V2 = FLAGE[i].last;
            temp = Link_Table[V1];
            Link_Table[V1] = Link_Table[V2];
            Link_Table[V2] = temp;
		}else{
			continue;
		}
	}

    /*init the linktable*/
    //	PrintF_Link_Table();
    //	Test_Link(Link_Table,Opstring,LinktoVirtual,Total_Link,MM);
	//for(i=0;i<=Ph.mm-1;i++)
	//{
	//	printf("%d",opstring[i].vert_index);/*counter for reach the target position from the orgin position by move up*/
	//}
    int index_after;

    if(nh!=0)
    {
        /*chose the start point in virtual, */
        total_loop_pass_count = 0;
	loop_numb = 0;
        while(total_loop_pass_count<=Trac)
        {
cont1:      init_leg = min((int)(((double)(2*Vert_Size*nh))*Random()),2*Vert_Size*(nh-1));
            init_index = Opstring[LinktoVirtual[init_leg/(2*Vert_Size)]][1];
            init_shift = init_leg%(2*Vert_Size);
            if(init_shift<Vert_Size)
            {
                if(Vertex_Leg[0][init_index*Vert_Size+init_shift]==0)/*S^+ propagate upward*/
                {
                    sgn = 1;
                }else{
                	if(Vertex_Leg[0][init_index*Vert_Size+init_shift]==Mos)/*S^- propagate upward */
                	{
                    		sgn = 0;
                	}else{
                    		if(Random()<0.5)
                    		{
                        		sgn = 0;
                    		}else{
                        		sgn = 1;
                    		}
			}
                }
            }else{
                if(Vertex_Leg[1][init_index*Vert_Size+init_shift-Vert_Size]==0) /*S^- propagate downward */
                {
                    sgn = 0;
                }else{
                	if(Vertex_Leg[1][init_index*Vert_Size+init_shift-Vert_Size]==Mos)  /*S^+ propagate downward*/
                	{
                    		sgn = 1;
                	}else{
                    		if(Random()<0.5)
                    		{
                        		sgn = 0;
                    		}else{
                        		sgn = 1;
                    		}
			}
                }
            }
	    in_leg = init_leg;
            do{
                vert_link = in_leg/(2*Vert_Size);
                in_index = Opstring[LinktoVirtual[vert_link]][1];
                inner_shift = in_leg%(2*Vert_Size);
                Choose_Leg(in_index,inner_shift,&out_index,&out_shift,sgn,total_loop_pass_count);
                Opstring[LinktoVirtual[vert_link]][1] = out_index;
                Opstring[LinktoVirtual[vert_link]][0] = Vertex_Type[out_index];
                out_leg = vert_link*(2*Vert_Size) + out_shift;
                if(out_leg==init_leg)
                {
                    total_loop_pass_count++;
                    break;
                }
                in_leg = Link_Table[out_leg];
                total_loop_pass_count++;
            }while(in_leg!=init_leg);
	    loop_numb = loop_numb + 1;
        }
	for(i=0;i<=Nsite-1;i++)
	{
		if(FLAGE[i].first!=-1)
		{
		    	vert_link = FLAGE[i].first/(2*Vert_Size);
		    	inner_shift = FLAGE[i].first%(2*Vert_Size);
            	    	Lattice[i] = Vertex_Leg[0][Opstring[LinktoVirtual[vert_link]][1]*Vert_Size+inner_shift];
		}else{
			if(Random()<0.5)
            		{
               			if(Lattice[i]==Mos)
                		{
                    			Lattice[i]--;
					continue;
                		}
				if(Lattice[i]==0)
                		{
                    			Lattice[i]++;
                		}else{
                    			Lattice[i]++;
                		}
            		}else{
                		continue;
            		}
		}

	}

    }
   
	  //  Test_Link(Link_Table,Opstring,LinktoVirtual,Total_Link,MM);
	
    if(Link_Table!=NULL)
    {
        free(Link_Table);
        Link_Table = NULL;
    }

    if(LinktoVirtual!=NULL)
    {
        free(LinktoVirtual);
        LinktoVirtual = NULL;
    }
 
    if(rho1!=NULL)
    {
	free(rho1);
	rho1 = NULL;
    }
}

int Choose_Leg(int Vert_index, int shift_in, int *Vert_out_index, int *shift_out, int sgn, int k)/*if sgn==0, represent s^-. if sgn==1, represent s^+*/
{
    int i, j;
    int out_leg, out_segment, out_shift, in_leg;
    int seg, count, Total;
    double R;
    Total = 2*Vert_Size;
    R = Random();
    in_leg = Vert_index*Total + shift_in + sgn*Max_Size;
    seg = GLEG_MAP[paraenv][in_leg][0];
    for(i=0;i<=Total-1;i++)
    {
        if(R<GTM[paraenv][in_leg][i])
        {
            out_leg = GLEG_MAP[paraenv][in_leg][i];
            *Vert_out_index = (out_leg-sgn*Max_Size)/(2*Vert_Size);
            *shift_out = (out_leg-sgn*Max_Size)%(2*Vert_Size);
            return 0;
        }else{
                continue;
        }
    }
}


int Wight1(int lift,int right)
{
	int i;

	for(i=0;i<=VertNumb-1;i++)
	{
		if(Vertex_Sum[0][i]==right)
		{
			if(Vertex_Sum[1][i]==lift)
			{
				return i;
			}else{
				continue;
			}
		}else{
			continue;
		}
	}

}


