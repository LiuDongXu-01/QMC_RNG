#include "datastruct.h"
/*        type                   period                                          seed                                                            output
pcg       0                      unknown                                         unsigned long long                                              unsigned int
well      1                      2^512/1024/19973/44497                          unsind int[16/32/624/1391]                                      double 0-1
kiss      2                      2^127                                           unsigned int                                                    unsigned int

初始化：   int init (int type, int period,char* fname)
int 0-3 ,  3是SFMT 未完成
well 有周期16，32，624，1391     用的pcg的周期出处没有说明是多少，可以换个知道周期的
kiss 的unsigned long 在X86_64的linux可能会变成8位，测试改成8位的unsigned long long 出现问题， 所以改成了unsigned int 

调用随机数：  double random (void)
返回值 double 0-1    */


//pcg
#include <stdint.h>

uint32_t pcg32(void);
void pcg32_init(uint64_t seed);

//kiss

void seed_rand_kiss(unsigned long seed);
unsigned long rand_kiss();

//rand.c
int init(int type, int period,char*fname);
double Random(void);


/* ***************************************************************************** */
/* Copyright:      Francois Panneton and Pierre L'Ecuyer, University of Montreal */
/*                 Makoto Matsumoto, Hiroshima University                        */
/* Notice:         This code can be used freely for personal, academic,          */
/*                 or non-commercial purposes. For commercial purposes,          */
/*                 please contact P. L'Ecuyer at: lecuyer@iro.UMontreal.ca       */
/* ***************************************************************************** */

void InitWELLRNG512a (unsigned int *init);
double WELLRNG512a (void);

void InitWELLRNG1024a (unsigned int *init);
double WELLRNG1024a (void);

void InitWELLRNG19937a (unsigned int *);
extern double (*WELLRNG19937a) (void);

void InitWELLRNG44497a(unsigned int *);
extern double (*WELLRNG44497a) (void);
