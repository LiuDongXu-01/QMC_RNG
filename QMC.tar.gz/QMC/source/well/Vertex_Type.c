#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>
#include "datastruct.h"
#include "myfunction.h"



void Make_Vertex(void)
{
    int D, D1, i, j, k, k1, l, sum_l, sum_r, i_sum, j_sum, sum_temp, is;
    int sgn[2] = {-1,1};
    int leg1, leg2, leg3, leg4, legn;
    int *conf0 = (int *)malloc(Vert_Size*sizeof(int));
    int *conf1 = (int *)malloc(Vert_Size*sizeof(int));
    double sum_u0, sum_v0, sum_v1;
    Mosp = (int *)malloc(Vert_Size*sizeof(int));
    int *temp = (int *)malloc(Vert_Size*sizeof(int));
    Mosp[0] = 1;
    for(i=1;i<=Vert_Size-1;i++)
    {
        Mosp[i] = Mosp[i-1]*(Mos+1);
    }

    int *Vect_l = (int *)malloc(Vert_Size*sizeof(int));  /*Vect_l is the vertex leg's configure after operation*/
    int *Vect_r = (int *)malloc(Vert_Size*sizeof(int));  /*Vect_r store the vertex leg's configure before operation*/
    VertNumb = 0;
    D = Pow(Mos+1,Vert_Size);
    for(i=0;i<=D-1;i++)
    {
        Dec2Vect(i,Vect_l,Vert_Size);
        sum_l = Vect_Sum(Vect_l,Vert_Size);
        for(j=0;j<=D-1;j++)
        {
            Dec2Vect(j,Vect_r,Vert_Size);
            sum_r = Vect_Sum(Vect_r,Vert_Size);
            if(sum_l==sum_r)     /*"partical number converged"*/
            {
                Differ(Vect_l,Vect_r,temp);
                Vabs(temp);
                sum_temp = Vect_Sum(temp,Vert_Size);
                if(2<sum_temp)
                {
                    continue;
                }else{
		    if(i==j)
		    {
			VertNumb++;
		    }else{
			if(sum_temp==2)
			{
				for(k=0;k<=Vert_Size-1;k++)
				{
                            		leg1 = Vect_r[hopping1[k]];
                            		leg2 = Vect_r[hopping2[k]];
                            		leg3 = Vect_l[hopping1[k]];
                            		leg4 = Vect_l[hopping2[k]];	
					if(((leg1>leg3)&&(leg2<leg4))||((leg1<leg3)&&(leg2>leg4)))
					{
                    				VertNumb++;
						break;
					}else{
						continue;
					}
				}
			}	
		    }
                }
            }else{
                continue;
            }
        }
    }

    Max_Size = Vert_Size*VertNumb;

    Vertex_Leg = (int **)malloc(4*sizeof(int));
    Vertex_Leg[0] = (int *)malloc(Max_Size*sizeof(int));  /*stored the vert_r leg's confugure*/
    Vertex_Leg[1] = (int *)malloc(Max_Size*sizeof(int));  /*stored the vert_l leg's configure*/
    Vertex_Type = (int *)malloc(VertNumb*sizeof(int));
    Vertex_Sum = (int **)malloc(4*sizeof(int));
    Vertex_Sum[0] = (int *)malloc(VertNumb*sizeof(int));  /*stored the vert_r leg's confugure*/
    Vertex_Sum[1] = (int *)malloc(VertNumb*sizeof(int));  /*stored the vert_l leg's confugure*/
    Wight = (double **)malloc(2*process_numb*sizeof(double));

    for(i=0;i<=process_numb-1;i++)
    {
        Wight[i] = (double *)malloc(VertNumb*sizeof(double));
    }

    for(i=0;i<=process_numb-1;i++)
    {
        for(j=0;j<=VertNumb-1;j++)
        {
            Wight[i][j] = 0.0;   /*inited the wight matrix*/
        }
    }

    is = 0;
    for(i=0;i<=D-1;i++)
    {
        Dec2Vect(i,Vect_l,Vert_Size);
        sum_l = Vect_Sum(Vect_l,Vert_Size);
        for(j=0;j<=D-1;j++)
        {
            Dec2Vect(j,Vect_r,Vert_Size);
            sum_r = Vect_Sum(Vect_r,Vert_Size);
            if(sum_l==sum_r)
            {
                Differ(Vect_l,Vect_r,temp);
                Vabs(temp);
                sum_temp = Vect_Sum(temp,Vert_Size);
                if(2<sum_temp)
                {
                    continue;
                }else{
                    if(sum_temp==0)  /*diagonal operator*/
                    {
                        Vertex_Type[is] = 1;
                        for(k=0;k<=Vert_Size-1;k++)
                        {
                            Vertex_Leg[0][is*Vert_Size+k] = Vect_r[k];/*more larger leg_numb, the wight is more biger*/
                            Vertex_Leg[1][is*Vert_Size+k] = Vect_l[k];
                        }
                        Vertex_Sum[0][is] = j;
                        Vertex_Sum[1][is] = i;
                        is++;
                    }else{ /*off-diagonal operator*/
                        for(k=0;k<=Vert_Size-1;k++)
                        {
                            leg1 = Vect_r[hopping1[k]];
                            leg2 = Vect_r[hopping2[k]];
                            leg3 = Vect_l[hopping1[k]];
                            leg4 = Vect_l[hopping2[k]];
                            if((leg1<leg3)&&(leg4<leg2))
                            {
                                Vertex_Type[is] = 2;
 	                        Vertex_Sum[0][is] = j;
                            	Vertex_Sum[1][is] = i;
                            	for(k1=0;k1<=Vert_Size-1;k1++)
                            	{
                            		Vertex_Leg[0][is*Vert_Size+k1] = Vect_r[k1];
                            	 	Vertex_Leg[1][is*Vert_Size+k1] = Vect_l[k1];
                            	}
                            	is++;
				break;
                            }
                            if((leg3<leg1)&&(leg2<leg4))
                            {
                                Vertex_Type[is] = 2;
                            	Vertex_Sum[0][is] = j;
                            	Vertex_Sum[1][is] = i;
                            	for(k1=0;k1<=Vert_Size-1;k1++)
                            	{
                            		Vertex_Leg[0][is*Vert_Size+k1] = Vect_r[k1];
                            	 	Vertex_Leg[1][is*Vert_Size+k1] = Vect_l[k1];
                            	}
                            	is++;
				break;
                            }
                        }
                    }
                }
            }else{
                continue;
            }
        }
    }

    printf("%d",Clust_Type);
    for(i=0;i<=process_numb-1;i++)
    {
        for(j=0;j<=VertNumb-1;j++)
        {
            if(Vertex_Type[j]==1) /*diagonal operator*/
            {
                sum_u0 = 0.0;
                sum_v0 = 0.0;
		sum_v1 = 0.0;
                for(k=0;k<=Vert_Size-1;k++)
                {
                    conf0[k] = Vertex_Leg[0][j*Vert_Size+k];
                    conf1[k] = Vertex_Leg[1][j*Vert_Size+k];
                }
                for(l=0;l<=Vert_Size-1;l++)
                {
                    sum_u0 = sum_u0 + (((double)(conf0[l])*Miu[i]));
                }
		sum_u0 = sum_u0 + Miu1[i]*(double)(conf0[0]+conf0[3]) + Miu2[i]*(double)(conf0[1]+conf0[4]);
                for(l=0;l<=Vert_Size-1;l++)
                {
                      sum_v0 = sum_v0 + ((double)(conf0[hopping1[l]]))*((double)(conf0[hopping2[l]]));
 		 //  sum_v0 = sum_v0 + ((double)(conf0[l]))*((double)(conf0[(l+1)%Vert_Size]));
                }
		for(l=0;l<N_Size;l++)
		{
			sum_v1 = sum_v1 + (((double)(conf0[hopping_N1[l]]))*((double)(conf0[hopping_N2[l]])));
		}
		//sum_v1 = sum_v1 + ((double)(conf0[0])-0.5)*((double)(conf0[3]-0.5)) + ((double)(conf0[1])-0.5)*((double)(conf0[4]-0.5));
		if(Clust_Type==2)
		{
			if(Dim==1)
			{
				Wight[i][j] = Wight[i][j]  - V[i]*sum_v0/2.0 + sum_u0/2.0;
			}
			if(Dim==2)
			{
				Wight[i][j] = Wight[i][j]  - V[i]*sum_v0/2.0 + sum_u0/4.0;
			}
		}
                if(Clust_Type==3)
                {
                    Wight[i][j] = Wight[i][j] + Miu[i]*sum_u0/Bsite3.repead_miu0 - V[i]*sum_v0/Bsite3.repead_v0;
                }
                if(Clust_Type==4)
                {
                    Wight[i][j] = Wight[i][j] + Miu[i]*sum_u0/Bsite4.repead_miu0 - V[i]*sum_v0/Bsite4.repead_v0;
                }
                if(Clust_Type==5)
                {
                    Wight[i][j] = Wight[i][j] + Miu[i]*sum_u0/10.0 - V[i]*sum_v0/5.0 - V_N[i]*sum_v1/2.0;
                }
		if(Clust_Type==6)
		{
                    Wight[i][j] = Wight[i][j] + sum_u0/2.0 - V[i]*sum_v0 - V_N[i]*sum_v1;
		}
            }else{
		if(Clust_Type==2)
		{
		      Wight[i][j] = Wight[i][j] + T[i];
		}
                if(Clust_Type==3)
                {
                    Wight[i][j] = Wight[i][j] + T[i];
                }
                if(Clust_Type==4)
                {
                    Wight[i][j] = Wight[i][j] + T[i];
                }
                if(Clust_Type==5)
                {
                    Wight[i][j] = Wight[i][j] + T[i]/5.0;
                }
		if(Clust_Type==6)
		{	
                    Wight[i][j] = Wight[i][j] + T[i];
		}
            }
        }
    }



    GTM = (double ***)malloc(3*process_numb*sizeof(double));
    legn = 2*Vert_Size;
    D1 = legn*VertNumb;
    Max_Size = D1;
    for(i=0;i<=process_numb-1;i++)
    {
        GTM[i] = (double **)malloc(4*D1*sizeof(double));
        for(j=0;j<=2*D1-1;j++)
        {
            GTM[i][j] = (double *)malloc(legn*sizeof(double));
        }
    }
    GLEG_MAP = (int ***)malloc(3*process_numb*sizeof(int));
    for(i=0;i<=process_numb-1;i++)
    {
        GLEG_MAP[i] = (int **)malloc(2*2*D1*sizeof(int));
        for(j=0;j<=2*D1-1;j++)
        {
            GLEG_MAP[i][j] = (int *)malloc(legn*sizeof(int));
        }
    }

    /*inited the trans_prob matrix,*/

    for(i=0;i<=process_numb-1;i++)
    {
        for(j=0;j<=2*D1-1;j++)
        {
            for(k=0;k<=2*Vert_Size-1;k++)
            {
                GTM[i][j][k] = -1.0;
                GLEG_MAP[i][j][k] = -1;
            }
        }
    }

    if(Vect_l!=NULL)
    {
        free(Vect_l);
        Vect_l = NULL;
    }
    if(Vect_r!=NULL)
    {
        free(Vect_r);
        Vect_r = NULL;
    }
    if(conf0!=NULL)
    {
        free(conf0);
        conf0 = NULL;
    }
    if(conf1!=NULL)
    {
        free(conf1);
        conf1 = NULL;
    }
    if(temp!=NULL)
    {
        free(temp);
        temp = NULL;
    }
}


void Dec2Vect(int Dec, int *Vect, int Size)
{
    int i, j, k;
    int dec;
    dec = Dec;
    for(i=0;i<=Size-1;i++)
    {
        Vect[i] = dec%(Mos+1);
        dec = dec/(Mos+1);
    }
}



int Vect_Sum(int *Vect,int Size)
{
    int i;
    int sum = 0;
    for(i=0;i<=Size-1;i++)
    {
        sum = sum + Vect[i];
    }
    return sum;
}

int Differ(int *a,int *b, int *c)
{
	int i;
	for(i=0;i<=Vert_Size-1;i++)
	{
		c[i] = a[i] - b[i];
	}
}

int Vabs(int *a)
{
	int i;
	for(i=0;i<=Vert_Size-1;i++)
	{
		a[i] = abs(a[i]);
	}
}
