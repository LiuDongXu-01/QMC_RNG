#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>
#include "datastruct.h"
#include "datastruct.h"


void calc_TRMatrix(int **Vertex_class, double **TM, int D, int pid)
{
	int i, j, k, interrupt;
	double check, check1, W_total1=0.0, W_total=0.0, delta, delta2;


	for(i=0;i<=D-1;i++)
	{
		for(j=0;j<=D-1;j++)
		{
			TM[i][j] = 0.0;
		}
	}


		if(D==2)
		{
			if(Wight[pid][Vertex_class[0][0]]==Wight[pid][Vertex_class[0][0]])
			{
				TM[0][1] = Wight[pid][Vertex_class[0][0]];
				TM[1][0] = Wight[pid][Vertex_class[0][0]];
			}
			if(Wight[pid][Vertex_class[0][0]]>Wight[pid][Vertex_class[1][0]])
			{
				TM[0][0] = Wight[pid][Vertex_class[0][0]] - Wight[pid][Vertex_class[1][0]];
				TM[0][1] = Wight[pid][Vertex_class[1][0]];
				TM[1][0] = Wight[pid][Vertex_class[1][0]];
			}
		}

		if(D==3)
		{
			if((Wight[pid][Vertex_class[0][0]]-(Wight[pid][Vertex_class[1][0]] + Wight[pid][Vertex_class[2][0]])) > (double)(0.0))
			{
				TM[0][0] = Wight[pid][Vertex_class[0][0]]-(Wight[pid][Vertex_class[1][0]] + Wight[pid][Vertex_class[2][0]]);
				TM[0][1] = Wight[pid][Vertex_class[1][0]];
				TM[0][2] = Wight[pid][Vertex_class[2][0]];

				TM[1][0] = TM[0][1];
				TM[2][0] = TM[0][2];
			}else{
				TM[0][1] = (Wight[pid][Vertex_class[0][0]] + Wight[pid][Vertex_class[1][0]] - Wight[pid][Vertex_class[2][0]])/(double)(2);
				TM[0][2] = (Wight[pid][Vertex_class[0][0]] - Wight[pid][Vertex_class[1][0]] + Wight[pid][Vertex_class[2][0]])/(double)(2);
				TM[1][2] = ((0.0-Wight[pid][Vertex_class[0][0]]) + Wight[pid][Vertex_class[1][0]] + Wight[pid][Vertex_class[2][0]])/(double)(2);

				TM[1][0] = TM[0][1];
				TM[2][0] = TM[0][2];
				TM[2][1] = TM[1][2];
			}
		}


	if(D>=4)
	{
		check1 = Wight[pid][Vertex_class[1][0]] + Wight[pid][Vertex_class[2][0]] + Wight[pid][Vertex_class[3][0]] - Wight[pid][Vertex_class[0][0]];
		check = 0.0;

		for(i=1;i<=D-1;i++)
		{
			check = check + Wight[pid][Vertex_class[i][0]];
		}

		check = check - Wight[pid][Vertex_class[0][0]];


		if(check > -0.0000000000000001)
		{
			if(check1 > -0.0000000000000001)
			{

				if(D==4)
				{
					TM[0][1] = (Wight[pid][Vertex_class[0][0]] + Wight[pid][Vertex_class[1][0]] - Wight[pid][Vertex_class[2][0]] - Wight[pid][Vertex_class[3][0]])/(double)(2);
					TM[0][2] = (Wight[pid][Vertex_class[0][0]] - Wight[pid][Vertex_class[1][0]] + Wight[pid][Vertex_class[2][0]] - Wight[pid][Vertex_class[3][0]])/(double)(2);
					TM[1][2] = ((0.0-Wight[pid][Vertex_class[0][0]]) + Wight[pid][Vertex_class[1][0]] + Wight[pid][Vertex_class[2][0]] + Wight[pid][Vertex_class[3][0]])/(double)(2);
					TM[0][3] = Wight[pid][Vertex_class[3][0]];

					TM[1][0] = TM[0][1];
					TM[2][0] = TM[0][2];
					TM[2][1] = TM[1][2];
					TM[3][0] = TM[0][3];
				}
				if( D > 4)
				{
					TM[0][1] = (Wight[pid][Vertex_class[0][0]] + Wight[pid][Vertex_class[1][0]] - Wight[pid][Vertex_class[2][0]] - Wight[pid][Vertex_class[3][0]])/(double)(2);
					TM[0][2] = (Wight[pid][Vertex_class[0][0]] - Wight[pid][Vertex_class[1][0]] + Wight[pid][Vertex_class[2][0]] - Wight[pid][Vertex_class[3][0]])/(double)(2);
					TM[1][2] = ((0.0-Wight[pid][Vertex_class[0][0]]) + Wight[pid][Vertex_class[1][0]] + Wight[pid][Vertex_class[2][0]] + Wight[pid][Vertex_class[3][0]])/(double)(2);
					TM[3][4] = Wight[pid][Vertex_class[4][0]]/(double)(2);
					TM[0][3] = Wight[pid][Vertex_class[3][0]] - (Wight[pid][Vertex_class[4][0]]/(double)(2));
					TM[0][D-1] = Wight[pid][Vertex_class[D-1][0]]/2.0;


					TM[1][0] = TM[0][1];
					TM[2][0] = TM[0][2];
					TM[2][1] = TM[1][2];
					TM[4][3] = TM[3][4];
					TM[3][0] = TM[0][3];
					TM[D-1][0] = TM[0][D-1];


					for(i=4;i<=D-2;i++)
					{
						TM[0][i] = (Wight[pid][Vertex_class[i][0]] - Wight[pid][Vertex_class[i+1][0]])/(double)(2);
						TM[i][i+1] = Wight[pid][Vertex_class[i+1][0]]/(double)(2);

						TM[i][0] = TM[0][i];
						TM[i+1][i] = TM[i][i+1];
					}
				}
			}else{
				delta = - check1;

				if(D==4)
				{
					TM[0][1] = ((Wight[pid][Vertex_class[0][0]] - delta) + Wight[pid][Vertex_class[1][0]] - Wight[pid][Vertex_class[2][0]] - (Wight[pid][Vertex_class[3][0]]-delta))/(double)(2);
					TM[0][2] = ((Wight[pid][Vertex_class[0][0]] - delta) - Wight[pid][Vertex_class[1][0]] + Wight[pid][Vertex_class[2][0]] - (Wight[pid][Vertex_class[3][0]]-delta))/(double)(2);
					TM[1][2] = (0.0-(Wight[pid][Vertex_class[0][0]] - delta) + Wight[pid][Vertex_class[1][0]] + Wight[pid][Vertex_class[2][0]] + (Wight[pid][Vertex_class[3][0]]-delta))/(double)(2);
					TM[0][3] = Wight[pid][Vertex_class[3][0]];


					TM[1][0] = TM[0][1];
					TM[2][0] = TM[0][2];
					TM[2][1] = TM[1][2];
					TM[3][0] = TM[0][3];

				}

				if(D >= 5)
				{
					for(k=3;k<=D-1;k++)
					{
						for(i=k;i<=D-1;i++)
						{
                            W_total = 0.0;
                            W_total1 = 0.0;
							for(j=i;j<=D-1;j++)
							{
								W_total = W_total + Wight[pid][Vertex_class[j][0]];
							}

							for(j=i+1;j<=D-1;j++)
							{
								W_total1 = W_total1 + Wight[pid][Vertex_class[j][0]];
							}

							if((W_total1<delta)&&(delta<=W_total))
							{
								interrupt = i;
								goto BLA1 ;
							}
						}
					}
BLA1:				delta2 = delta - W_total1;
                    k = interrupt;
                    if(k==3)
                    {
                        for(j=k+1;j<=D-1;j++)
                        {
                            TM[0][j] = Wight[pid][Vertex_class[j][0]];
                            TM[j][0] = TM[0][j];
                        }


                        TM[0][1] = ((Wight[pid][Vertex_class[0][0]] - delta) + Wight[pid][Vertex_class[1][0]] - Wight[pid][Vertex_class[2][0]] - (Wight[pid][Vertex_class[3][0]]-delta2))/(double)(2);
                        TM[0][2] = ((Wight[pid][Vertex_class[0][0]] - delta) - Wight[pid][Vertex_class[1][0]] + Wight[pid][Vertex_class[2][0]] - (Wight[pid][Vertex_class[3][0]]-delta2))/(double)(2);
                        TM[1][2] = (-(Wight[pid][Vertex_class[0][0]] - delta) + Wight[pid][Vertex_class[1][0]] + Wight[pid][Vertex_class[2][0]] + (Wight[pid][Vertex_class[3][0]]-delta2))/(double)(2);
                        TM[0][3] = Wight[pid][Vertex_class[3][0]] - delta2;
                        TM[0][3] = TM[0][3] + delta2;

                        TM[1][0] = TM[0][1];
                        TM[2][0] = TM[0][2];
                        TM[2][1] = TM[1][2];
                        TM[3][0] = TM[0][3];
                    }
                    if(k>=4)
                    {
                        for(j=k+1;j<=D-1;j++)
                        {
                            TM[0][j] = Wight[pid][Vertex_class[j][0]];
                            TM[j][0] = TM[0][j];
                        }


                        TM[0][1] = ((Wight[pid][Vertex_class[0][0]] - delta) + Wight[pid][Vertex_class[1][0]] - Wight[pid][Vertex_class[2][0]] - Wight[pid][Vertex_class[3][0]])/(double)(2);
                        TM[0][2] = ((Wight[pid][Vertex_class[0][0]] - delta) - Wight[pid][Vertex_class[1][0]] + Wight[pid][Vertex_class[2][0]] - Wight[pid][Vertex_class[3][0]])/(double)(2);
                        TM[1][2] = (-(Wight[pid][Vertex_class[0][0]] - delta) + Wight[pid][Vertex_class[1][0]] + Wight[pid][Vertex_class[2][0]] + Wight[pid][Vertex_class[3][0]])/(double)(2);
                        TM[0][3] = Wight[pid][Vertex_class[3][0]] - ((Wight[pid][Vertex_class[4][0]] - delta2)/((double)(2)));
                        TM[0][k] = ((Wight[pid][Vertex_class[k][0]]-delta2)/(double)(2)) + delta2;
                        TM[k-1][k] = (Wight[pid][Vertex_class[k][0]]-delta2)/(double)(2);

                        TM[1][0] = TM[0][1];
                        TM[2][0] = TM[0][2];
                        TM[2][1] = TM[1][2];
                        TM[3][0] = TM[0][3];
                        TM[k][0] = TM[0][k];
                        TM[k][k-1] = TM[k-1][k];


                        for(i=4;i<=k-1;i++)
                        {
                            TM[0][i] = (Wight[pid][Vertex_class[i][0]] - Wight[pid][Vertex_class[i+1][0]])/(double)(2);
                            TM[i][i+1] = (Wight[pid][Vertex_class[i+1][0]])/(double)(2);
                            TM[i][0] = TM[0][i];
                            TM[i+1][i] = TM[i][i+1];
                        }
                    }

				}
			}
		}else{
			TM[0][0] = -check;
			for(i=1;i<=D-1;i++)
			{
				TM[i][0] = Wight[pid][Vertex_class[i][0]];
				TM[0][i] = Wight[pid][Vertex_class[i][0]];
			}
		}
	}


	printf("\n");

}





