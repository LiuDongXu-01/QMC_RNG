#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include "datastruct.h"
#include "myfunction.h"
int Pow(int expon,int length)
{
    int i;
    int sum = 1;
    if(length==0)
    {
        return sum;
    }else{
        for(i=0;i<=length-1;i++)
        {
            sum = sum*expon;
        }
    }
    return sum;
}


void Init_constant(void)
{
	int i, j, D, d, tot;
//===========================================初始化全局变量结构体Ph===================================================================//
//--------------------------------------------结构体变量Ph的基本解释------------------------------------------------------------------//
    Nbin=10;            //.....................Ph中定义i了量子梦特卡罗计算程序所必须的基本输入产量.....................................//
    Mstep=10000;         //.......Ph.nbin定义了蒙卡算法中
    Istep=50000;      //
    nh = 0;              //
    Interrupt_Switch = 0;
    Restart_Switch = 0;
    Rebalance_Switch = 0;
//===========================================初始化全局变量===================================================================//






        energy_shift = (double *)malloc(process_numb*sizeof(double));
        for(i=0;i<=process_numb-1;i++)
        {
            energy_shift[i] = 0.0;
        }

        Ob.diag_oper = 0;
        Ob.off_oper = 0;
        Ob.diag_trs_off = 0;
        Ob.off_trs_diag = 0;
        Ob.off_diag_number = 0;
        Ob.diag_number = 0;
        T = (double *)malloc(process_numb*sizeof(double));
        V = (double *)malloc(process_numb*sizeof(double));
	V_N = (double *)malloc(process_numb*sizeof(double));
        Miu = (double *)malloc(process_numb*sizeof(double));
	Miu1 = (double *)malloc(process_numb*sizeof(double));
	Miu2 = (double *)malloc(process_numb*sizeof(double));
        Beta = (double *)malloc(process_numb*sizeof(double));

}//initized the wight struct group;

void Init_Virtime(void)
{
	int i, j, k,total;
	FLAGE = NULL;
	FLAGE = (Link *)malloc(Nsite*sizeof(Link));

	for(i=0;i<=Nsite-1;i++)
	{
		FLAGE[i].first = -1;
		FLAGE[i].last = -1;
	}
	MM = 20;
    	Opstring = (int **)malloc(2*MM*sizeof(int));
    	for(i=0;i<=MM-1;i++)
    	{
        	Opstring[i] = (int *)malloc(3*sizeof(int));
    	}
    	for(i=0;i<=MM-1;i++)
    	{
        	Opstring[i][0] = -1;
        	Opstring[i][1] = -1;
        	Opstring[i][2] = -1;
    	}
    /*init the Observable which will used by following process*/
    	Total_step = Nbin*Mstep;


}


void Init_gf(void)
{
    int tmup, tmdown, temp_int, temp_min;
    int tmmx, nt;
    int i, j, k;
    int init_posi, dest_posi, init_shift, dest_shift, init_x, init_y, dest_x, dest_y, relat_x, relat_y, relat1_x, relat1_y;
    double rescal, dtau;
    Rescal = 5000.0;
    dtau = Beta[my_rank]/(Nt*2);
    Tmmx = (int)(Beta[my_rank]*Rescal);
    tmmx = Tmmx;
    nt = Nt;
    rescal = Rescal;
    Tm  = (double *)malloc(nt*sizeof(double));
    for(i=0;i<=nt-1;i++)
    {
        Tm[i] = (double)(i*dtau);  /*stored the virtual time postion*/
    }
    Tmgf = (int *)malloc(nt*sizeof(int));
    for(i=0;i<=nt-1;i++)
    {
        Tmgf[i] = (int)(rescal*Tm[i]);
    }

    Lpds0 = (double ***)malloc(3*process_numb*sizeof(double));
    for(i=0;i<=process_numb-1;i++)
    {
        Lpds0[i] = (double **)malloc(2*Nsite*3*sizeof(double));
        for(j=0;j<3*Nsite;j++)
        {
                Lpds0[i][j] = (double *)malloc(2*nt*sizeof(double));
        }
    }
    for(i=0;i<=process_numb-1;i++)
    {
            for(j=0;j<3*Nsite;j++)
            {
                 for(k=0;k<=2*nt-1;k++)
                 {
                    Lpds0[i][j][k] = 0.0;
                 }
            }
    }
    Lpds1 = (double ***)malloc(3*process_numb*sizeof(double));
    for(i=0;i<process_numb;i++)
    {
        Lpds1[i] = (double **)malloc(2*Nsite*3*sizeof(double));
        for(j=0;j<3*Nsite;j++)
        {
                Lpds1[i][j] = (double *)malloc(2*nt*sizeof(double));
        }
    }
    for(i=0;i<process_numb;i++)
    {
            for(j=0;j<3*Nsite;j++)
            {
                 for(k=0;k<=2*nt-1;k++)
                 {
                    Lpds1[i][j][k] = 0.0;
                 }
            }
    }
    
    GF0 = (double ***)malloc(3*process_numb*sizeof(double));
    for(i=0;i<process_numb;i++)
    {
        GF0[i] = (double **)malloc(2*Nsite*3*sizeof(double));
        for(j=0;j<3*Nsite;j++)
        {
                GF0[i][j] = (double *)malloc(2*Nt*sizeof(double));
        }
    }
    GF1 = (double ***)malloc(3*process_numb*sizeof(double));
    for(i=0;i<process_numb;i++)
    {
        GF1[i] = (double **)malloc(2*Nsite*3*sizeof(double));
        for(j=0;j<3*Nsite;j++)
        {
                GF1[i][j] = (double *)malloc(2*Nt*sizeof(double));
        }
    }

    for(i=0;i<process_numb;i++)
    {
        for(j=0;j<3*Nsite;j++)
        {
            for(k=0;k<=2*nt-1;k++)
            {
                    GF0[i][j][k] = 0.0;
                    GF1[i][j][k] = 0.0;
            }
        }
    }
    Tid = (int *)malloc(5*tmmx*sizeof(int));
    Nid = (int *)malloc(10*nt*sizeof(int));
    for(i=-2;i<=2;i++)
    {
        for(j=0;j<=nt-2;j++)
        {
            tmdown = (i+2)*tmmx+Tmgf[j];
            tmup = (i+2)*tmmx+Tmgf[j+1]-1;
            for(k=tmdown;k<=tmup;k++)
            {
                Tid[k] = 2*i*nt + j;
            }
            tmdown = (i+2+1)*tmmx - Tmgf[j+1];
            tmup = (i+2+1)*tmmx - Tmgf[j] - 1;
            for(k=tmdown;k<=tmup;k++)
            {
                Tid[k] = 2*(i+1)*nt - 2 - j;
            }
        }
        if(tmmx > 2*Tmgf[nt-1])
        {
            tmdown = (i+2)*tmmx + Tmgf[nt-1];
            tmup = (i+2+1)*tmmx - Tmgf[nt-1] -1;
            for(k=tmdown;k<=tmup;k++)
            {
                Tid[k] = nt - 1 + 2*i*nt;
            }
        }
        if(Tmgf[0] > 0)
        {
            tmdown = (i+2)*tmmx;
            tmup = (i+2)*tmmx + Tmgf[0] - 1;
            for(k=tmdown;k<=tmup;k++)
            {
                Tid[k] = 2*i*nt - 1;
            }
            tmdown = (i+2+1)*tmmx - Tmgf[0];
            tmup = (i+2+1)*tmmx -1;
            for(k=tmdown;k<=tmup;k++)
            {
                Tid[k] = 2*(i+1)*nt -1;
            }
        }
    }
    for(i=-4*nt-1;i<=6*nt-1;i++)
    {
        Nid[i+(4*nt+1)] = (6*nt + i)%(2*nt);
    }

    if(Tm!=NULL)
    {
        free(Tm);
        Tm = NULL;
    }
    Optm = (int *)malloc(MM*sizeof(int));
    for(i=0;i<=MM-1;i++)
    {
        Optm[i] = (int)(Random()*(Tmmx - MM));
    }

    for(i=0;i<=MM-1;i++)
    {
        temp_min = Optm[i];
        for(j=i+1;j<=MM-1;j++)
        {
            if(Optm[j] < temp_min)
            {
                Optm[i] = Optm[j];
                Optm[j] = temp_min;
                temp_min = Optm[i];
            }
        }
    }
    for(i=0;i<=MM-1;i++)
    {
        Optm[i] = Optm[i] + i;
    }
    Nl = (double *)malloc(3*process_numb*sizeof(double));
    for(i=0;i<3*process_numb;i++)
    {
          Nl[i] = 0.0;
    }
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++init the Szz for measure Corretion function++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
    Ob.Correct_Virtu_Time = (double ***)malloc(3*process_numb*sizeof(double));
    for(i=0;i<=process_numb-1;i++)
    {
	    Ob.Correct_Virtu_Time[i] = (double **)malloc(2*K_num*sizeof(double));
	    for(j=0;j<K_num;j++)
	    {
		    Ob.Correct_Virtu_Time[i][j] = (double *)malloc(Nt*sizeof(double));
	    }
    }
    
    for(i=0;i<process_numb;i++)
    {
	    for(j=0;j<K_num;j++)
	    {
		    for(k=0;k<Nt;k++)
		    {
			    Ob.Correct_Virtu_Time[i][j][k] = 0.0;
		    }
	    }
    }


 
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++init the rho_krho_k' for measure Corretion function++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

    Ob.Correct_Rho_Virtu_Time = (double ***)malloc(3*process_numb*sizeof(double));
    for(i=0;i<=process_numb-1;i++)
    {
	    Ob.Correct_Rho_Virtu_Time[i] = (double **)malloc(2*K_num*sizeof(double));
	    for(j=0;j<K_num;j++)
	    {
		    Ob.Correct_Rho_Virtu_Time[i][j] = (double *)malloc(Nt*sizeof(double));
	    }
    }
    
    for(i=0;i<process_numb;i++)
    {
	    for(j=0;j<K_num;j++)
	    {
		    for(k=0;k<Nt;k++)
		    {
			    Ob.Correct_Rho_Virtu_Time[i][j][k] = 0.0;
		    }
	    }
    }

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++Estabulish a Mapping which to Mapping Lattice in Kagome Lattice+++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/



   	Lattice_Map = (int **)malloc(3*2*sizeof(int));
	for(i=0;i<3;i++)
	{
		Lattice_Map[i] = (int *)malloc(Nsite*sizeof(int));
	}
	for(i=0;i<Nsite;i++)
	{
		Lattice_Map[0][i] = i;
		Lattice_Map[1][i] = 3*(i/3) + ((i%3) + 2)%3;
		Lattice_Map[2][i] = 3*(i/3) + ((i%3) + 1)%3;
	}

//	for(i=0;i<Nsite;i++)
//	{
//		init_shift = i%3;
//		init_posi = i/3;
//		init_x = init_posi%Dim_x;
//		init_y = init_posi/Dim_x;
//		for(j=0;j<Nsite;j++)
//		{
//			dest_shift = j%3;
//			dest = j/3;
//			dest_x = dest%Dim_x;
//			dest_y = dest/Dim_x;
//			relat_x = dest_x - init_x;
//			if(relat_x < 0)
//			{
//				relat_x = relat_x + Dim_x;
//			}
//			relat_y = dest_y - init_y;
//			if(relat_y < 0)
//			{
//				relat_y = relat_y + Dim_y;
//			}
//			if(init_shift==0)
//			{
//				Lattice_Map[i][j] = (relat_y*Dim_x + relat_x)*3 + dest_shift;
//			}
//			if(init_shift==1)
//			{	
//				relat1_x = - relat_x - relat_y;
//				relat1_y =  relat_x;
//				if(relat1_x < 0)
//				{
//					relat1_x = (relat1_x + 2*Dim_x)%Dim_x;
//				}
//				Lattice_Map[i][j] = (relat1_y*Dim_x + relat1_x)*3 + (dest_shift+2)%3;
//			}
//			if(init_shift==2)
//			{
//				relat1_x =  relat_y;
//				relat1_y = - relat_x - relat_y;
//				if(relat1_y < 0)
//				{
//					relat1_y = (relat1_y + 2*Dim_y)%Dim_y;
//				}
//				Lattice_Map[i][j] = (relat1_y*Dim_x + relat1_x)*3 + (dest_shift+1)%3;
//			}
//		}	
//	}
//	for(i=0;i<Nsite;i++)
//	{
//		for(j=0;j<Nsite;j++)
//		{
//			printf("%d%s",Lattice_Map[i][j]," ");
//		}
//		printf("\n");
//	}
}

