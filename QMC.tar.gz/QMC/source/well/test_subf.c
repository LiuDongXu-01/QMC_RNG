#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>
#include "datastruct.h"
#include "myfunction.h"


/*================================================================================================================*/
/*++++++++++++++++++++Warning!!! test_program in parall temping will caused massive disk space++++++++++++++++++++*/
/*=================================================================================================================*/

void Print_Vert_Wight(char *pwd)
{
	int i, j, leg_postion;
	char id;
	char *temp_pwd = (char *)malloc(1024*sizeof(char));
    id = my_rank + '0';
    char *ID[] = {id};
    strcat(temp_pwd,pwd);
    strcpy(temp_pwd,ID);
    FILE *fp1 = fopen(temp_pwd,"w+");

	for(i=0;i<=VertNumb-1;i++)
	{
		fprintf(fp1,"%s%s","Vert_Number:","\n");
		fprintf(fp1,"%d",i);
		fprintf(fp1,"%d","\n");
		for(j=0;j<=Vert_Size-1;j++)
		{
            leg_postion = i*Vert_Size + j;
			fprintf(fp1,"%d",Vertex_Leg[0][leg_postion]);
			fprintf(fp1,"%s"," ");
		}
		fprintf(fp1,"%s","\n");
		fprintf(fp1,"%s","----");
		fprintf(fp1,"%s","\n");
		for(j=0;j<=Vert_Size-1;j++)
		{
            leg_postion = i*Vert_Size + j;
			fprintf(fp1,"%d",Vertex_Leg[1][leg_postion]);
			fprintf(fp1,"%s"," ");
		}
		fprintf(fp1,"%s","\n");
	}
	if(temp_pwd!=NULL)
	{
        free(temp_pwd);
        temp_pwd = NULL;
	}
}

void Print_Trans_Prob(char *pwd)
{
	int i, j, k, leg_postion;
	char id;
	char *temp_pwd = (char *)malloc(1024*sizeof(char));
    id = my_rank + '0';
    char *ID[] = {id};
    strcat(temp_pwd,pwd);
    strcpy(temp_pwd,ID);
    FILE *fp1 = fopen(temp_pwd,"w+");

    for(i=0;i<=process_numb-1;i++)
    {
        for(j=0;j<=2*Max_Size-1;j++)
        {
            for(k=0;k<=2*Vert_Size-1;k++)
            {
                fprintf(fp1,"%7.lf",GTM[i][j][k]);
                fprintf(fp1,"%s"," ");
            }
            fprintf(fp1,"%s","\n");
        }
    }

    if(temp_pwd!=NULL)
    {
        free(temp_pwd);
        temp_pwd = NULL;
    }
}




