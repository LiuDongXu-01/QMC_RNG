#include "RNG.h";
#include <math.h>;
#include <stdio.h>;
#include <time.h>;

int main()
{
    time_t t_begin,t_end;
    t_begin=clock();//记录开始时间
    //dosomething();//调用函数
    

    /*unsigned long long  n = 100000000;
    double ave=0;
    unsigned long long i;
    unsigned long long m = 0;
    double u;
    for (i=0; i < n;i++)
    {
        ave += random();
    }
    printf("average=%.20f\n",ave/n);
    double a = random();
    for (i = 0; i < n;i++)
    {
        if(random()<a)
        {
            m++;
        }
    }
    u = m / (n*1.0);
    u /= a;
    printf("u/a=%.20f\n",u);   //测试*/

    init(1,44497,"seed.txt");
    unsigned long   n = 0;
    n--;
    for (unsigned long long i=0; i < n;i++)
    {
        random();
    }

    /*FILE *fp;
    fp = fopen("seed.txt", "w+");
    for (int i; i < 1391;i++)
    {
        fprintf(fp, "%u\t", 4294967295*random());
    }
    fclose(fp);*/
    t_end=clock();//记录结束时间
    printf("Timeused=%.3f\n",(double)(t_end-t_begin)/CLOCKS_PER_SEC);
    

    return 0;
}