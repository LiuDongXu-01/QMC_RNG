#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>
#include "datastruct.h"
#include "myfunction.h"

int Made_Trans_Vertex(char *pwd)
{
    int i, j, k, m, n, pd, is, is1, temp1, temp2, sgn, sum_test;
    int in_leg, out_leg, i_sum, j_sum, change1, change2, in_index, out_index;
    int legn = 2*Vert_Size;
    double wight, temp, max;
    int **Vertex_class0 = (int **)malloc(2*legn*sizeof(int));
    int **Vertex_class1 = (int **)malloc(2*legn*sizeof(int));
    int *record = (int *)malloc(VertNumb*sizeof(int));  /*recorder for S^- in_leg!*/
    int *record1 = (int *)malloc(VertNumb*sizeof(int)); /*recorder for S^+ in_leg!*/

    for(i=0;i<=VertNumb-1;i++)
    {
        record[i] = 0;
        record1[i] = 0;
    }

    for(i=0;i<=legn-1;i++)
    {
        Vertex_class0[i] = (int *)malloc(5*sizeof(int)); /*in_leg with s^-,s^- = (x+1)(p+1)/(x)(p)*/
    }
    for(i=0;i<=legn-1;i++)
    {
        Vertex_class1[i] = (int *)malloc(5*sizeof(int)); /*in_leg with s^+,s^+ = x(p+1)/(x+1)(p)*/
    }
    int *Vect_l = (int *)malloc(Vert_Size*sizeof(int));
    int *Vect_r = (int *)malloc(Vert_Size*sizeof(int));
    int *Mapping = NULL;
    double **TM = NULL;
    double **TM1 = NULL;
    		/*Debug code!!*/
		int code_count;
	    	int count11 = 0;
	    	/*Debug cdoe!!*/

    for(i=0;i<=VertNumb-1;i++)
    {
        for(j=0;j<=Vert_Size-1;j++)
        {
            Vect_r[j] = Vertex_Leg[0][i*Vert_Size+j];
            Vect_l[j] = Vertex_Leg[1][i*Vert_Size+j];
        }
        for(in_leg=0;in_leg<2*Vert_Size;in_leg++)
        {

            for(j=0;j<legn;j++)
            {
                Vertex_class0[j][0] = -1;
                Vertex_class0[j][1] = -1;
                Vertex_class0[j][2] = -1;
                Vertex_class0[j][3] = -1;
		Vertex_class0[j][4] = -1;
                Vertex_class1[j][0] = -1;
                Vertex_class1[j][1] = -1;
                Vertex_class1[j][2] = -1;
                Vertex_class1[j][3] = -1;
		Vertex_class1[j][4] = -1;
            }
	    is = 0;
	    is1 = 0;
            for(out_leg=0;out_leg<2*Vert_Size;out_leg++)
            {
            	if((in_leg<Vert_Size)&&(out_leg<Vert_Size))
		{
			/*double down, the in_leg and out_leg is in the same side, the converge law request +1, -1*/
               		change1 = Vect_r[in_leg] + 1;  /*in_leg is s^+*/
               		change2 = Vect_r[out_leg] - 1;
			if(in_leg==out_leg)
			{
				change1 = Vect_r[in_leg];
				change2 = Vect_r[out_leg];
			}
                	if((0<=change1)&&(change1<=Mos)&&(0<=change2)&&(change2<=Mos))
                	{
                    		temp1 = Vect_r[in_leg];
                    		temp2 = Vect_r[out_leg];
                    		Vect_r[in_leg] = change1;
                    		Vect_r[out_leg] = change2;
                    		i_sum = 0;
                    		j_sum = 0;
                    		for(k=0;k<=Vert_Size-1;k++)
                    		{
                        		i_sum = i_sum + Vect_l[k]*Mosp[k];
                        		j_sum = j_sum + Vect_r[k]*Mosp[k];
                    		}
                    		for(k=0;k<=VertNumb-1;k++)
                    		{
                        		if((Vertex_Sum[1][k]==i_sum)&&(Vertex_Sum[0][k]==j_sum))
                        		{
                            			Vertex_class1[is1][0] = k;
                            			Vertex_class1[is1][1] = in_leg;
                            			Vertex_class1[is1][2] = out_leg;
                            			Vertex_class1[is1][3] = 1;
						Vertex_class1[is1][4] = i;
                            			is1++;
                            			record1[k]= 1;
                        		}else{
                           		 continue;
                        		}
                    		}
                    		Vect_r[in_leg] = temp1;
                    		Vect_r[out_leg] = temp2;
                	}

                	change1 = Vect_r[in_leg] - 1;   /*in_leg is s^-*/
                	change2 = Vect_r[out_leg] + 1;
			if(in_leg==out_leg)
			{
				change1 = Vect_r[in_leg];
				change2 = Vect_r[out_leg];
			}
                	if((0<=change1)&&(change1<=Mos)&&(0<=change2)&&(change2<=Mos))
                	{
                    		temp1 = Vect_r[in_leg];
                    		temp2 = Vect_r[out_leg];
                    		Vect_r[in_leg] = change1;
                    		Vect_r[out_leg] = change2;
                    		i_sum = 0;
                    		j_sum = 0;
                    		for(k=0;k<=Vert_Size-1;k++)
                    		{
                        		i_sum = i_sum + Vect_l[k]*Mosp[k];
                        		j_sum = j_sum + Vect_r[k]*Mosp[k];
                    		}
                    		for(k=0;k<=VertNumb-1;k++)
                   		{
                        		if((Vertex_Sum[1][k]==i_sum)&&(Vertex_Sum[0][k]==j_sum))
                        		{
                            			Vertex_class0[is][0] = k;
                            			Vertex_class0[is][1] = in_leg;
                            			Vertex_class0[is][2] = out_leg;
                            			Vertex_class0[is][3] = 1;
						Vertex_class0[is][4] = i;
                            			is++;
                            			record[k] = 1;
                        		}else{
                           			 continue;
                        		}
                    		}
                    		Vect_r[in_leg] = temp1;
                    		Vect_r[out_leg] = temp2;
                	}
		}
		if((Vert_Size<=in_leg)&&(Vert_Size<=out_leg))
		{
                /*double up, the in_leg and out in the same side, the converge law request +1, -1*/
                	change1 = Vect_l[in_leg-Vert_Size] + 1;   /*in_leg is s^-*/
                	change2 = Vect_l[out_leg-Vert_Size] - 1;
			if(in_leg==out_leg)
			{
				change1 = Vect_l[in_leg-Vert_Size];
				change2 = Vect_l[out_leg-Vert_Size];
			}
                	if((0<=change1)&&(change1<=Mos)&&(0<=change2)&&(change2<=Mos))
                	{
                    		temp1 = Vect_l[in_leg-Vert_Size];
                    		temp2 = Vect_l[out_leg-Vert_Size];
                    		Vect_l[in_leg-Vert_Size] = change1;
                    		Vect_l[out_leg-Vert_Size] = change2;
                    		i_sum = 0;
                    		j_sum = 0;
                    		for(k=0;k<=Vert_Size-1;k++)
                    		{
                        		i_sum = i_sum + Vect_l[k]*Mosp[k];
                        		j_sum = j_sum + Vect_r[k]*Mosp[k];
                    		}
                    		for(k=0;k<=VertNumb-1;k++)
                    		{
                        		if((Vertex_Sum[1][k]==i_sum)&&(Vertex_Sum[0][k]==j_sum))
                        		{
                            			Vertex_class0[is][0] = k;
                            			Vertex_class0[is][1] = in_leg;
                            			Vertex_class0[is][2] = out_leg;
                            			Vertex_class0[is][3] = 2;
						Vertex_class0[is][4] = i;
                            			is++;
                            			record[k] = 1;
                        		}else{
                            			continue;
                        		}
                    		}
                    		Vect_l[in_leg-Vert_Size] = temp1;
                    		Vect_l[out_leg-Vert_Size] = temp2;
                	}
                	change1 = Vect_l[in_leg-Vert_Size] - 1; /*in_leg is s^+*/
                	change2 = Vect_l[out_leg-Vert_Size] + 1;
			if(in_leg==out_leg)
			{
				change1 = Vect_l[in_leg-Vert_Size];
				change2 = Vect_l[out_leg-Vert_Size];
			}
                	if((0<=change1)&&(change1<=Mos)&&(0<=change2)&&(change2<=Mos))
                	{
                    		temp1 = Vect_l[in_leg-Vert_Size];
                    		temp2 = Vect_l[out_leg-Vert_Size];
                    		Vect_l[in_leg-Vert_Size] = change1;
                    		Vect_l[out_leg-Vert_Size] = change2;
                    		i_sum = 0;
                    		j_sum = 0;
                    		for(k=0;k<=Vert_Size-1;k++)
                    		{
                            		i_sum = i_sum + Vect_l[k]*Mosp[k];
                            		j_sum = j_sum + Vect_r[k]*Mosp[k];
                    		}
                    		for(k=0;k<=VertNumb-1;k++)
                    		{
                        		if((Vertex_Sum[1][k]==i_sum)&&(Vertex_Sum[0][k]==j_sum))
                        		{
                            			Vertex_class1[is1][0] = k;
                            			Vertex_class1[is1][1] = in_leg;
                            			Vertex_class1[is1][2] = out_leg;
                            			Vertex_class1[is1][3] = 2;
						Vertex_class1[is1][4] = i;
                            			is1++;
                            			record1[k] = 1;
                        		}else{
                           			 continue;
                        		}
                   		}
                    		Vect_l[in_leg-Vert_Size] = temp1;
                    		Vect_l[out_leg-Vert_Size] = temp2;
                	}
		}
           /*in down, out up*/
		if((in_leg<Vert_Size)&&(Vert_Size<=out_leg))
		{
	                change1 = Vect_r[in_leg] + 1; /*in_leg is s^+*/
                	change2 = Vect_l[out_leg-Vert_Size] + 1;
                	if((0<=change1)&&(change1<=Mos)&&(0<=change2)&&(change2<=Mos))
                	{
                    		temp1 = Vect_r[in_leg];
                    		temp2 = Vect_l[out_leg-Vert_Size];
                    		Vect_r[in_leg] = change1;
                    		Vect_l[out_leg-Vert_Size] = change2;
                    		i_sum = 0;
                    		j_sum = 0;
                    		for(k=0;k<=Vert_Size-1;k++)
                    		{
                            		i_sum = i_sum + Vect_l[k]*Mosp[k];
                            		j_sum = j_sum + Vect_r[k]*Mosp[k];
                    		}
                    		for(k=0;k<=VertNumb-1;k++)
                    		{
                        		if((Vertex_Sum[1][k]==i_sum)&&(Vertex_Sum[0][k]==j_sum))
                        		{
                            			Vertex_class1[is1][0] = k;
                            			Vertex_class1[is1][1] = in_leg;
                            			Vertex_class1[is1][2] = out_leg;
                            			Vertex_class1[is1][3] = 3;
						Vertex_class1[is1][4] = i;
                            			is1++;
                            			record1[k] = 1;
                        		}else{
                            			continue;
                        		}
                    		}
                    		Vect_r[in_leg] = temp1;
                    		Vect_l[out_leg-Vert_Size] = temp2;
                	}
                	change1 = Vect_r[in_leg] - 1; /*in_leg is s^-*/
                	change2 = Vect_l[out_leg-Vert_Size] - 1;
                	if((0<=change1)&&(change1<=Mos)&&(0<=change2)&&(change2<=Mos))
                	{
                    		temp1 = Vect_r[in_leg];
                    		temp2 = Vect_l[out_leg-Vert_Size];
                    		Vect_r[in_leg] = change1;
                    		Vect_l[out_leg-Vert_Size] = change2;
                    		i_sum = 0;
                    		j_sum = 0;
                    		for(k=0;k<=Vert_Size-1;k++)
                    		{
                            		i_sum = i_sum + Vect_l[k]*Mosp[k];
                            		j_sum = j_sum + Vect_r[k]*Mosp[k];
                    		}
                    		for(k=0;k<=VertNumb-1;k++)
                    		{
                        		if((Vertex_Sum[1][k]==i_sum)&&(Vertex_Sum[0][k]==j_sum))
                        		{
                            			Vertex_class0[is][0] = k;
                            			Vertex_class0[is][1] = in_leg;
                            			Vertex_class0[is][2] = out_leg;
                            			Vertex_class0[is][3] = 3;
						Vertex_class0[is][4] = i;
                            			is++;
                           			 record[k] = 1;
                        		}else{
                            			continue;
                        		}
                    		}
                    		Vect_r[in_leg] = temp1;
                    		Vect_l[out_leg-Vert_Size] = temp2;
                	}
		}
		if((Vert_Size<=in_leg)&&(out_leg<Vert_Size))
		{
                	change1 = Vect_l[in_leg-Vert_Size] + 1; /*in_leg is s^-*/
                	change2 = Vect_r[out_leg] + 1;
                	if((0<=change1)&&(change1<=Mos)&&(0<=change2)&&(change2<=Mos))
                	{
                    		temp1 = Vect_l[in_leg-Vert_Size];
                    		temp2 = Vect_r[out_leg];
                    		Vect_l[in_leg-Vert_Size] = change1;
                    		Vect_r[out_leg] = change2;
                    		i_sum = 0;
                    		j_sum = 0;
                    		for(k=0;k<=Vert_Size-1;k++)
                    		{
                            		i_sum = i_sum + Vect_l[k]*Mosp[k];
                            		j_sum = j_sum + Vect_r[k]*Mosp[k];
                    		}
                    		for(k=0;k<=VertNumb-1;k++)
                    		{
                       			 if((Vertex_Sum[1][k]==i_sum)&&(Vertex_Sum[0][k]==j_sum))
                        		 {
                            			Vertex_class0[is][0] = k;
                            			Vertex_class0[is][1] = in_leg;
                            			Vertex_class0[is][2] = out_leg;
                            			Vertex_class0[is][3] = 4;
						Vertex_class0[is][4] = i;
                            			is++;
                            			record[k]=1;
                        		}else{
                            			continue;
                        		}
                    		}
                    		Vect_l[in_leg-Vert_Size] = temp1;
                    		Vect_r[out_leg] = temp2;
                	}
                	change1 = Vect_l[in_leg-Vert_Size] - 1;  /*in_leg is s^+*/
                	change2 = Vect_r[out_leg] - 1;
                	if((0<=change1)&&(change1<=Mos)&&(0<=change2)&&(change2<=Mos))
                	{
                    		temp1 = Vect_l[in_leg-Vert_Size];
                    		temp2 = Vect_r[out_leg];
                    		Vect_l[in_leg-Vert_Size] = change1;
                    		Vect_r[out_leg] = change2;
                    		i_sum = 0;
                    		j_sum = 0;
                    		for(k=0;k<=Vert_Size-1;k++)
                    		{
                            		i_sum = i_sum + Vect_l[k]*Mosp[k];
                            		j_sum = j_sum + Vect_r[k]*Mosp[k];
                    		}
                    		for(k=0;k<=VertNumb-1;k++)
                    		{
                        		if((Vertex_Sum[1][k]==i_sum)&&(Vertex_Sum[0][k]==j_sum))
                        		{
                            			Vertex_class1[is1][0] = k;
                            			Vertex_class1[is1][1] = in_leg;
                            			Vertex_class1[is1][2] = out_leg;
                            			Vertex_class1[is1][3] = 4;
						Vertex_class1[is1][4] = i;
                            			is1++;
                            			record1[k] = 1;
                        		}else{
                            			continue;
                        		}
                    		}
                    		Vect_l[in_leg-Vert_Size] = temp1;
                    		Vect_r[out_leg] = temp2;
			}
		}
           }


            /*start to calculated tansfor matrix */
            for(pd=0;pd<=process_numb-1;pd++)
            {
		if(1<is)
		{
                	Reorder(Vertex_class0,is,pd);
                	TM = (double **)malloc(2*is*sizeof(double));
                	for(m=0;m<=is-1;m++)
                	{
                    		TM[m] = (double *)malloc(is*sizeof(double));
                	}
			code_count = 2*count11;
			calc_TRMatrix(Vertex_class0,TM,is,pd);
               		for(m=0;m<=is-1;m++)
                	{
                    		wight = Wight[pd][Vertex_class0[m][4]];
                        	in_index = Vertex_class0[m][4]*2*Vert_Size + Vertex_class0[m][1];
                            	out_index = Vertex_class0[m][0]*2*Vert_Size + Vertex_class0[m][2];
				for(n=0;n<=is-1;n++)
				{
					if(Vertex_class0[n][0]==Vertex_class0[m][4])
					{
                        			GTM[pd][in_index][m] = TM[n][m]/wight;
                        			GLEG_MAP[pd][in_index][m] = out_index;
					}else{
						continue;
					}
				}
                	}
            		if(TM!=NULL)
            		{
                		for(m=0;m<=is-1;m++)
                		{
                    			if(TM[m]!=NULL)
                    			{
                        			free(TM[m]);
                        			TM[m] = NULL;
                    			}
                		}
                		free(TM);
                		TM = NULL;
            		}
		}
		if(1<is1)
		{
	                Reorder(Vertex_class1,is1,pd);
                	TM1 = (double **)malloc(2*is1*sizeof(double));
                	for(m=0;m<=is1-1;m++)
                	{
                    		TM1[m] = (double *)malloc(is1*sizeof(double));
                	}
			code_count = 2*count11 + 1;
               		calc_TRMatrix(Vertex_class1,TM1,is1,pd);
 	                for(m=0;m<=is1-1;m++)
                	{
                    		wight = Wight[pd][Vertex_class1[m][4]];
                        	in_index = Max_Size + Vertex_class1[m][4]*2*Vert_Size + Vertex_class1[m][1];
                           	out_index = Max_Size + Vertex_class1[m][0]*2*Vert_Size + Vertex_class1[m][2];
                    		for(n=0;n<=is1-1;n++)
                    		{
					if(Vertex_class1[n][0]==Vertex_class1[m][4])
					{
                        			GTM[pd][in_index][m] = TM1[n][m]/wight;
                        			GLEG_MAP[pd][in_index][m] = out_index;
					}
                                 }
                	}
            		if(TM1!=NULL)
            		{
                		for(m=0;m<=is1-1;m++)
                		{
                    			if(TM1[m]!=NULL)
                    			{
                        			free(TM1[m]);
                        			TM1[m] = NULL;
                    			}
                		}
                		free(TM1);
                		TM1 = NULL;
            		}
		}
 		count11++;
            }
       }
	count11++;
    }
    sum_test = 0;
    for(i=0;i<=VertNumb-1;i++)
    {
        sum_test = sum_test + record[i];
    }
    if(sum_test!=VertNumb)
    {
        printf("error happened in check the Vertex calculation, the all vertex_class do not cover all kinds of vertex");
        printf("\n");
        printf("the transform matrix will not be calculated, program ended with error code 1");
        printf("\n");
        return 1;
    }
    sum_test = 0;
    for(i=0;i<=VertNumb-1;i++)
    {
        sum_test = sum_test + record1[i];
    }
    if(sum_test!=VertNumb)
    {
        printf("error happened in check the Vertex calcation, the all vertex_class do not cover all kinds of vertex");
        printf("\n");
        printf("the transform matrix will not be calculated, program ended with error code 1");
        printf("\n");
        return 1;
    }



    /*reorder the transform prob!*/
    for(i=0;i<=process_numb-1;i++)
    {
        for(j=0;j<=2*Max_Size-1;j++)
        {
            for(k=0;k<=legn-1;k++)
            {
                max = GTM[i][j][k];
                for(m=k+1;m<=legn-1;m++)
                {
                    if(max < GTM[i][j][m])
                    {
                        max = GTM[i][j][m];
                        temp = GTM[i][j][k];
                        temp1 = GLEG_MAP[i][j][k];
                        GTM[i][j][k] = GTM[i][j][m];
                        GLEG_MAP[i][j][k] = GLEG_MAP[i][j][m];
                        GTM[i][j][m] = temp;
                        GLEG_MAP[i][j][m] = temp1;
                    }else{
                        continue;
                    }
                }
            }
        }
    }
    /*reorder the transform prob!*/



    for(i=0;i<=process_numb-1;i++)
    {
        for(j=0;j<=2*Max_Size-1;j++)
        {
            temp = 0.0;
            for(k=0;k<=legn-1;k++)
            {
                if(GLEG_MAP[i][j][k]!=-1)
                {
                    GTM[i][j][k] = GTM[i][j][k] + temp;
                    temp = GTM[i][j][k];
                }else{
                    continue;
                }
            }
        }
    }

    if(record!=NULL)
    {
        free(record);
        record = NULL;
    }
    if(record1!=NULL)
    {
        free(record1);
        record1 = NULL;
    }

    if(Vertex_class0!=NULL)
    {
        for(i=0;i<=2*Vert_Size-1;i++)
        {
            if(Vertex_class0[i]!=NULL)
             {
		free(Vertex_class0[i]);
            	Vertex_class0[i] = NULL;
	     }
        }
        free(Vertex_class0);
        Vertex_class0 = NULL;
    }
    if(Vertex_class1!=NULL)
    {
        for(i=0;i<=2*Vert_Size-1;i++)
        {
            if(Vertex_class1[i]!=NULL);
	    {
		free(Vertex_class1[i]);
            	Vertex_class1[i] = NULL;
	    }
        }
        free(Vertex_class1);
        Vertex_class1 = NULL;
    }
}



void Reorder(int **V, int D, int PID)
{
    int i ,j, posi, it;
    double max;
    int *temp = (int *)malloc(4*sizeof(int));

    for(i=0;i<=D-1;i++)
    {
        max = Wight[PID][V[i][0]];
        it = i;
        for(j=i+1;j<=D-1;j++)
        {
            if(max<Wight[PID][V[j][0]])
            {
                it = j;
		max = Wight[PID][V[j][0]];
            }
        }
        temp[0] = V[it][0];
        temp[1] = V[it][1];
        temp[2] = V[it][2];
        temp[3] = V[it][3];
	V[it][0] = V[i][0];
	V[it][1] = V[i][1];
	V[it][2] = V[i][2];
	V[it][3] = V[i][3];
        V[i][0] = temp[0];
        V[i][1] = temp[1];
       	V[i][2] = temp[2];
        V[i][3] = temp[3];
    }

    if(temp!=NULL)
    {
        free(temp);
        temp = NULL;
    }
}
