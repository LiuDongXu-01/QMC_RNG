#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>
#include "datastruct.h"
#include "myfunction.h"

void Wight_diag_shift(double delta,char *pwd)
{
	int i, is;
        double max_shift;
	double *min = (double *)malloc(process_numb*sizeof(double));
	double *shift = (double *)malloc(process_numb*sizeof(double));
	for(is=0;is<=process_numb-1;is++)
	{
        min[is] = 0.0;
	}
	FILE *fp = NULL;
    char *pwd_temp = (char *)malloc(1024*sizeof(char));
    strcpy(pwd_temp,pwd);
    strcat(pwd_temp,"/shift.txt");
    fp = fopen(pwd_temp,"a");

    for(is=0;is<=process_numb-1;is++)
    {
    	for(i=0;i<=VertNumb-1;i++)
        {
            if(Vertex_Type[i]==1)
            {
                if(Wight[is][i]<min[is])
                {
                    min[is] = Wight[is][i];
                }else{
                    continue ;
                }
            }else{
                continue ;
            }
        }
    }


    for(is=0;is<=process_numb-1;is++)
    {
        shift[is] = delta - min[is];
    }

    max_shift = shift[0];
    for(is=0;is<=process_numb-1;is++)
    {
	 if(max_shift < shift[is])
	 {
		max_shift = shift[is];
	 }else{
		continue;
	 }
    }

	fprintf(fp,"%lf",shift[i]);
	fclose(fp);
	fp = NULL;
    for(is=0;is<=process_numb-1;is++)
    {
      	for(i=0;i<=VertNumb-1;i++)
        {
            if(Vertex_Type[i]==1)
            {		
                Wight[is][i] = Wight[is][i] + max_shift;
            }
        }
    }


	if(pwd_temp!=NULL)
	{
        free(pwd_temp);
        pwd_temp = NULL;
	}

	for(is=0;is<=process_numb-1;is++)
	{
        	energy_shift[is] = shift[is];
	}
    if(min!=NULL)
    {
        free(min);
        min = NULL;
    }
    if(shift!=NULL)
    {
        free(shift);
        shift = NULL;
    }

}

int Min(int a, int b)
{
    if(a<b)
    {
        return a;
    }else{
        return b;
    }
}

int Max(int a, int b)
{
    if(a<b)
    {
        return b;
    }else{
        return a;
    }
}

int Maxm(int *string,int dim) /*this function was used to find the integer group's max value element*/
{
	int i,max;
	max = string[0];
	for(i=1;i<dim;i++)
	{
		if(max < string[i])
		{
			max = string[i];
		}
	}
	return max;
}

int Sum1(int *string,int dim)
{
	int sum=0;
	int i;
	for(i=0;i<dim;i++)
	{
		sum = sum + string[i];
	}
	return sum;
}
