#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>
#include "datastruct.h"
#include "myfunction.h"
#include "RNG.h"
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>


int init(int type, int period,char *fname)
{
    kind = type;
    TP = period;
    int i;
    FILE *fp = NULL;
    fp=fopen(fname, "r");



    if(kind==0)
    {
        unsigned int seed[2];
        fscanf(fp, "%u", &seed[0]);
        fscanf(fp, "%u", &seed[1]);
        unsigned long long seed0 =  seed[1];
        seed0=(seed0 << 32);
        seed0 += seed[0];
        pcg32_init(seed0);
    }
    else if(kind==1)
    {
        if(TP==512)
        {
            unsigned int seed[16];
            for(i = 0; i < 16;i++)
            {
		fscanf(fp, "%u", &seed[i]);
		seed[i] = seed[i]*(i+1);
            }
            InitWELLRNG512a (seed);
        }
        else if(TP==1024)
        {
            unsigned int seed[32];
            for(i = 0; i < 32;i++)
            {
                fscanf(fp, "%u", &seed[i]);
                seed[i] = seed[i]*(i+1);
            }
            InitWELLRNG1024a(seed);
        }
        else if(TP==19937)
        {
            unsigned int seed[624];
            for(i = 0; i < 624;i++)
            {
		fscanf(fp, "%u", &seed[i]);
                seed[i] = seed[i]*(i+1);
            }
            InitWELLRNG19937a(seed);
        }
        else if(TP==44497)
        {
            unsigned int seed[1391];
            for(i = 0; i < 1391;i++)
            {
		fscanf(fp, "%u", &seed[i]);
                seed[i] = seed[i]*(i+1);
            }
            InitWELLRNG44497a(seed);
        }
        else
            return 2;   //周期报错
    }
    else if(kind==2)
    {
        unsigned int seed;
        fscanf(fp, "%u", &seed);
        seed_rand_kiss(seed);
    }
    else if(kind==3)
    {
        init_sandvik(fname);
    }
    else
    {
        return 1;     //类型序数报错
    }
    fclose(fp);
    return 0;
}

int init_sandvik(char *pwd)
{
        long long int ran641;
        long long int  irmax;
        int  nb, b;
        FILE *fp;
        fp = NULL;
        irmax = (int)(Pow(2.0,31));
        irmax = 2*(irmax*irmax - 1) + 1;
        Ph_mul64 = 2862933555777941757;
        Ph_add64 = 1013904243;
        dmu64 = 0.5/(double)(irmax);

        fp = fopen(pwd,"r");
        if(fp!=NULL)
        {
                fscanf(fp,"%lld",&Ph_ran64);
        }else{
                printf("error !! file open failed!!");
        }
        if(fp !=NULL )
        {
        	fclose(fp);
        	fp = NULL;
        }
}

double Random_sandvik(void)
{
        double ran;
        Ph_ran64 = Ph_ran64*Ph_mul64 + Ph_add64;
        ran = 0.5 + dmu64*(double)(Ph_ran64);
        return ran;
}


double Random (void)
{
    double r;
    //printf("random output\n");
    if(kind==0)
    {
        r = pcg32() / 4294967295.0;
	return r;
    }
    else if(kind==1)
    {
        if(TP==512)
            return WELLRNG512a ();
        else if(TP==1024)
            return WELLRNG1024a();
        else if(TP==19937)
            return WELLRNG19937a();
        else if(TP==44497)
            return WELLRNG44497a();
    }
    else if(kind==2)
    {
        r = rand_kiss()/4294967295.0;
	return r;
    }
    else if(kind==3)
    {
    	return Random_sandvik();
    }
}

int min_int(int i,int j)
{
    int res;
    if(i<j)
    {
        res = i;
    }
    if(j<i)
    {
        res = j;
    }
    if(i==j)
    {
        res = i;
    }
    return res;
}
