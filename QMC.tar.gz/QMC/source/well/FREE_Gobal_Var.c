#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>
#include "datastruct.h"
#include "myfunction.h"

void Free_Gobal_Pointer(void)
{
    int i, j, table_len;
    if(Opstring!=NULL)
    {
        free(Opstring);
        Opstring = NULL;
    }
    if(Lattice!=NULL)
    {
        free(Lattice);
        Lattice = NULL;
    }
    if(Bsite!=NULL)
    {
        if(Clust_Type==3)
        {
            for(i=0;i<=2;i++)
            {
                if(Bsite[i]!=NULL)
                {
                    free(Bsite[i]);
                    Bsite[i] = NULL;
                }
            }
        }
        if(Clust_Type==4)
        {
            for(i=0;i<=3;i++)
            {
                if(Bsite[i]!=NULL)
                {
                    free(Bsite[i]);
                    Bsite[i] = NULL;
                }
            }
        }
        if(Clust_Type==5)
        {
            for(i=0;i<=4;i++)
            {
                if(Bsite[i]!=NULL)
                {
                    free(Bsite[i]);
                    Bsite[i] = NULL;
                }
            }
        }
    }
    if(Mosp!=NULL)
    {
        free(Mosp);
        Mosp = NULL;
    }
    if(T!=NULL)
    {
        free(T);
        T = NULL;
    }
    if(V!=NULL)
    {
        free(V);
        V = NULL;
    }
    if(Miu!=NULL)
    {
        free(Miu);
        Miu = NULL;
    }
    if(Beta!=NULL)
    {
        free(Beta);
        Beta = NULL;
    }
    if(pararec!=NULL)
    {
        free(pararec);
        pararec = NULL;
    }
    if(tpararec!=NULL)
    {
        free(tpararec);
        tpararec = NULL;
    }
    if(Wight!=NULL)
    {
        for(i=0;i<=process_numb-1;i++)
        {
            if(Wight[i]!=NULL)
            {
                free(Wight[i]);
                Wight[i] = NULL;
            }
        }
        free(Wight);
        Wight = NULL;
    }
    if(GTM!=NULL)
    {
        for(i=0;i<=process_numb-1;i++)
        {
            if(GTM[i]!=NULL)
            {
                for(j=0;j<=VertNumb-1;j++)
                {
                    if(GTM[i][j]!=NULL)
                    {
                        free(GTM[i][j]);
                        GTM[i][j] = NULL;
                    }
                }
                free(GTM[i]);
                GTM[i] = NULL;
            }
        }
        free(GTM);
        GTM = NULL;
    }

    if(Vertex_Type!=NULL)
    {
        free(Vertex_Type);
        Vertex_Type = NULL;
    }

    if(Vertex_Leg!=NULL)
    {
        if(Vertex_Leg[0]!=NULL)
        {
            free(Vertex_Leg[0]);
            Vertex_Leg[0] = NULL;
        }
        if(Vertex_Leg[1]!=NULL)
        {
            free(Vertex_Leg[1]);
            Vertex_Leg[1] = NULL;
        }
        free(Vertex_Leg);
        Vertex_Leg = NULL;
    }

    if(Vertex_Sum!=NULL)
    {
        if(Vertex_Sum[0]!=NULL)
        {
            free(Vertex_Sum[0]);
            Vertex_Sum[0] = NULL;
        }
        if(Vertex_Sum[1]!=NULL)
        {
            free(Vertex_Sum[1]);
            Vertex_Sum[1] = NULL;
        }
        free(Vertex_Sum);
        Vertex_Sum = NULL;
    }
    if(Exchange_Prob!=NULL)
    {
	    free(Exchange_Prob);
	    Exchange_Prob = NULL;
    }
    if(Exchange_Time!=NULL)
    {
	    for(i=0;i<=process_numb-1;i++)
	    {
		    if(Exchange_Time[i]!=NULL)
		    {
			    free(Exchange_Time[i]);
			    Exchange_Time[i] = NULL;
		    }
	    }
	    free(Exchange_Time);
	    Exchange_Time = NULL;
	    
    }
    if(Lattice_Map!=NULL)
    {
	  for(i=0;i<=2;i++)
	  {
		  if(Lattice_Map[i]!=NULL)
		  {
			 free(Lattice_Map[i]);
			 Lattice_Map[i] = NULL;
		  }
	  }
    }
    if(Ob.struct_factor!=NULL)
    {
	    free(Ob.struct_factor);
	    Ob.struct_factor = NULL;
    }
    if(Ob.Correct_Virtu_Time!=NULL)
    {
	  for(i=0;i<process_numb;i++)
	  {
		  if(Ob.Correct_Virtu_Time[i]!=NULL)
		  {
			 for(j=0;j<K_num;j++)
			 {
				if(Ob.Correct_Virtu_Time[i][j]!=NULL)
				{
					free(Ob.Correct_Virtu_Time[i][j]);
					Ob.Correct_Virtu_Time[i][j] = NULL;
				}
			 }
			 free(Ob.Correct_Virtu_Time[i]);
			 Ob.Correct_Virtu_Time[i] = NULL;
		  }
	  }
	  free(Ob.Correct_Virtu_Time);
	  Ob.Correct_Virtu_Time = NULL;
    }

    if(Ob.Correct_Rho_Virtu_Time!=NULL)
    {
	  for(i=0;i<process_numb;i++)
	  {
		  if(Ob.Correct_Rho_Virtu_Time[i]!=NULL)
		  {
			 for(j=0;j<K_num;j++)
			 {
				if(Ob.Correct_Rho_Virtu_Time[i][j]!=NULL)
				{
					free(Ob.Correct_Rho_Virtu_Time[i][j]);
					Ob.Correct_Rho_Virtu_Time[i][j] = NULL;
				}
			 }
			 free(Ob.Correct_Rho_Virtu_Time[i]);
			 Ob.Correct_Rho_Virtu_Time[i] = NULL;
		  }
	  }
	  free(Ob.Correct_Rho_Virtu_Time);
	  Ob.Correct_Rho_Virtu_Time = NULL;
    }
    if(Ob.Dens_Latti_Site!=NULL)
    {
	for(i=0;i<process_numb;i++)
	{	
		if(Ob.Dens_Latti_Site[i]!=NULL)
		{
			free(Ob.Dens_Latti_Site[i]);
			Ob.Dens_Latti_Site[i] = NULL;
		}
	}
	free(Ob.Dens_Latti_Site);
	Ob.Dens_Latti_Site = NULL;
    }
    if(Ob.loop_avg_length_mpi!=NULL)
    {
	 free(Ob.loop_avg_length_mpi);
	 Ob.loop_avg_length_mpi = NULL;
    }
    if(Tm!=NULL)
    {
	    free(Tm);
	    Tm = NULL;
    }
    if(Tmgf!=NULL)
    {
	    free(Tmgf);
	    Tmgf = NULL;
    }
    if(energy_shift!=NULL)
    {
	    free(energy_shift);
	    energy_shift = NULL;
    }
    if(Tid!=NULL)
    {
	    free(Tid);
	    Tid = NULL;
    }
    if(Nid!=NULL)
    {
	    free(Nid);
	    Nid = NULL;
    }
    if(Optm!=NULL)
    {
	    free(Optm);
	    Optm = NULL;
    }
    if(GF0!=NULL)
    {
	    for(i=0;i<process_numb;i++)
	    {
		    if(GF0[i]!=NULL)
		    {
			    for(j=0;j<3*Nsite;j++)
			    {
				    if(GF0[i][j]!=NULL)
				    {
					    free(GF0[i][j]);
					    GF0[i][j] = NULL;
				    }
			    }
			    free(GF0[i]);
			    GF0[i] = NULL;
		    }
		    free(GF0);
		    GF0=NULL;
	    }
    }
    if(GF1!=NULL)
    {
	    for(i=0;i<process_numb;i++)
	    {
		    if(GF1[i]!=NULL)
		    {
			    for(j=0;j<3*Nsite;j++)
			    {
				    if(GF1[i][j]!=NULL)
				    {
					    free(GF1[i][j]);
					    GF1[i][j] = NULL;
				    }
			    }
			    free(GF1[i]);
			    GF1[i] = NULL;
		    }
		    free(GF1);
		    GF1=NULL;
	    }
    }
    if(Lpds0!=NULL)
    {
	    for(i=0;i<process_numb;i++)
	    {
		    if(Lpds0[i]!=NULL)
		    {
			    for(j=0;j<3*Nsite;j++)
			    {
				    if(Lpds0[i][j]!=NULL)
				    {
					    free(Lpds0[i][j]);
					    Lpds0[i][j] = NULL;
				    }
			    }
			    free(Lpds0[i]);
			    Lpds0[i] = NULL;
		    }
		    free(Lpds0);
		    Lpds0=NULL;
	    }
    }
    if(Lpds1!=NULL)
    {
	    for(i=0;i<process_numb;i++)
	    {
		    if(Lpds1[i]!=NULL)
		    {
			    for(j=0;j<3*Nsite;j++)
			    {
				    if(Lpds1[i][j]!=NULL)
				    {
					    free(Lpds1[i][j]);
					    Lpds1[i][j] = NULL;
				    }
			    }
			    free(Lpds1[i]);
			    Lpds1[i] = NULL;
		    }
		    free(Lpds1);
		    Lpds1=NULL;
	    }
    }
    if(Trangle!=NULL)
    {
	for(i=0;i<L2;i++)
	{
		if(Trangle[i]!=NULL)
		{
			free(Trangle[i]);
			Trangle[i] = NULL;
		}
	}
	free(Trangle);
	Trangle = NULL;
    }
    if(Realf!=NULL)
    {
	    for(i=0;i<K_num;i++)
	    {
		    if(Realf[i]!=NULL)
		    {
			free(Realf[i]);
			Realf[i] = NULL;
		    }
	    }
	    free(Realf);
	    Realf = NULL;
    }

    if(Imagf!=NULL)
    {
	    for(i=0;i<K_num;i++)
	    {
		    if(Imagf[i]!=NULL)
		    {
			free(Imagf[i]);
			Imagf[i] = NULL;
		    }
	    }
	    free(Imagf);
	    Imagf = NULL;
    }

    if(Realfz!=NULL)
    {
	    for(i=0;i<K_num;i++)
	    {
		    if(Realfz[i]!=NULL)
		    {
			free(Realfz[i]);
			Realfz[i] = NULL;
		    }
	    }
	    free(Realfz);
	    Realfz = NULL;
    }
    
    if(Imagfz!=NULL)
    {
	    for(i=0;i<K_num;i++)
	    {
		    if(Imagfz[i]!=NULL)
		    {
			free(Imagfz[i]);
		    	Imagfz[i] = NULL;
		    }
	    }
	    free(Imagfz);
	    Imagfz = NULL;
    }
	
    if(Correctz_temp!=NULL)
    {
	    for(i=0;i<K_num;i++)
	    {
		if(Correctz_temp[i]!=NULL)
		{
			free(Correctz_temp[i]);
			Correctz_temp[i] = NULL;
		}
	    }
	    free(Correctz_temp);
	    Correctz_temp = NULL;
    }

        
}
