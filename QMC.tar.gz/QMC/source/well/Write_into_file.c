#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>
#include "datastruct.h"
#include "myfunction.h"
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>

void Add_Char_String(char *dest, char ch)
{
    int i, j;

    i = 0;
mark1:
    if((int)(dest[i]-'\0')!=0)
    {
        i = i + 1;
        goto mark1;
    }

    dest[i] = ch;

}

int Read_Input(char *pwd)
{
    int i, j, len, result;
    int sum;
    double sum1,floa_over;
    char *pwd_temp;
    char ch;
    char numb;
    char *ch_temp;
    char *number;
    number = (char *)malloc(16*sizeof(char));
    ch_temp = (char *)malloc(16*sizeof(char));
    char LATTIC[] = "LATTICE";
    char DIM[] = "DIM";
    char DIM_X[] = "DIM_X";
    char DIM_Y[] = "DIM_Y";
    char DIM_Z[] = "DIM_Z";
    char BC_1[] = "BOUNDARY_CONDITION";
    char Ph_N[] = "PHYCLUSIZE";
    char Ph_mm[] = "QMCLEN";
    char SHIFT[] = "SHIFT";
    char MSTEP[] = "MSTEP";
    char NBIN[] = "NBIN";
    char ISTEP[] = "ISTEP";
    char CYCLE[] = "CYCLE";
    char MAXOCCUP[] = "MAXOCCUP";
    char MPICONTRAL[] = "MPICONTRAL";
    char PARALSWITCH[] = "PARALSWITCH";
    char INTERRUPT[] = "INTERRUPT";
    char RESTART[] = "RESTART";
    char REBALANCE[] = "REBALANCE";
    char END[] = "END";
    pwd_temp = (char *)malloc(512*sizeof(char));
    strcpy(pwd_temp,pwd);
    strcat(pwd_temp,"/input.txt");
    FILE *fp_input;
    fp_input = NULL;
    fp_input = fopen(pwd_temp,"r");
    printf(pwd_temp);
    for(i=0;i<=15;i++)
    {
	 number[i] = '\0';
	 ch_temp[i] = '\0';
    }

    if(fp_input!=NULL)
    {
        do
        {
            ch = fgetc(fp_input);
            if((int)(ch-'\n')!=0)
            {
                Add_Char_String(ch_temp,ch);
            }
            else
            {
                if(strcmp(ch_temp,LATTIC)==0)
                {
                    do
                    {
                        numb = fgetc(fp_input);
                        if((int)(numb-'\n')!=0)
                        {
                            Add_Char_String(number,numb);
                        }
                        else
                        {
                            goto cont1;
                        }
cont1:
                        ;
                    }
                    while((int)(numb-'\n')!=0);
                    len = strlen(number);
                    sum = 0;
                    for(i=0; i<=len-1; i++)
                    {
                        sum = sum + (int)(number[i]-'0')*Pow(10,len-i-1);
                    }
                    Lattice_Sharpe = sum;

                    if(number!=NULL)
                    {
                        free(number);
                        number = NULL;
                    }
                    number = (char *)malloc(16*sizeof(char));
                    for(i=0; i<=15; i++)
                    {
                        number[i] = '\0';
                    }
                    if(ch_temp!=NULL)
                    {
                        free(ch_temp);
                        ch_temp = NULL;
                    }
                    ch_temp = (char *)malloc(512*sizeof(char));
                    for(i=0; i<=511; i++)
                    {
                        ch_temp[i] = '\0';
                    }
                    goto next;
                }

                if(strcmp(ch_temp,BC_1)==0)
                {
                    do
                    {
                        numb = fgetc(fp_input);
                        if((int)(numb-'\n')!=0)
                        {
                            Add_Char_String(number,numb);
                        }
                        else
                        {
                            goto cont2;
                        }
cont2:
                        ;
                    }
                    while((int)(numb-'\n')!=0);
                    len = strlen(number);
                    sum = 0;
                    for(i=0; i<=len-1; i++)
                    {
                        sum = sum + (int)(number[i]-'0')*Pow(10,len-i-1);
                    }
                    BC = sum;

                    if(number!=NULL)
                    {
                        free(number);
                        number = NULL;
                    }
                    number = (char *)malloc(16*sizeof(char));
                    for(i=0; i<=15; i++)
                    {
                        number[i] = '\0';
                    }
                    if(ch_temp!=NULL)
                    {
                        free(ch_temp);
                        ch_temp = NULL;
                    }
                    ch_temp = (char *)malloc(512*sizeof(char));
                    for(i=0; i<=511; i++)
                    {
                        ch_temp[i] = '\0';
                    }
                    goto next;
                }

                if(strcmp(ch_temp,DIM)==0)
                {
                    do
                    {
                        numb = fgetc(fp_input);
                        if((int)(numb-'\n')!=0)
                        {
                            Add_Char_String(number,numb);
                        }
                        else
                        {
                            goto cont3;
                        }
cont3:
                        ;
                    }
                    while((int)(numb-'\n')!=0);
                    len = strlen(number);
                    sum = 0;
                    for(i=0; i<=len-1; i++)
                    {
                        sum = sum + (int)(number[i]-'0')*Pow(10,len-i-1);
                    }
                    Dim = sum;
                    if(number!=NULL)
                    {
                        free(number);
                        number = NULL;
                    }
                    number = (char *)malloc(16*sizeof(char));
                    for(i=0; i<=15; i++)
                    {
                        number[i] = '\0';
                    }
                    if(ch_temp!=NULL)
                    {
                        free(ch_temp);
                        ch_temp = NULL;
                    }
                    ch_temp = (char *)malloc(512*sizeof(char));
                    for(i=0; i<=511; i++)
                    {
                        ch_temp[i] = '\0';
                    }
                    goto next;
                }

                if(strcmp(ch_temp,DIM_X)==0)
                {
                    do
                    {
                        numb = fgetc(fp_input);
                        if((int)(numb-'\n')!=0)
                        {
                            Add_Char_String(number,numb);
                        }
                        else
                        {
                            goto cont4;
                        }
cont4:
                        ;
                    }
                    while((int)(numb-'\n')!=0);
                    len = strlen(number);
                    sum = 0;
                    for(i=0; i<=len-1; i++)
                    {
                        sum = sum + (int)(number[i]-'0')*Pow(10,len-i-1);
                    }

                    Dim_x = sum;

                    if(number!=NULL)
                    {
                        free(number);
                        number = NULL;
                    }
                    number = (char *)malloc(16*sizeof(char));

                    for(i=0; i<=15; i++)
                    {
                        number[i] = '\0';
                    }

                    if(ch_temp!=NULL)
                    {
                        free(ch_temp);
                        ch_temp = NULL;
                    }
                    ch_temp = (char *)malloc(512*sizeof(char));
                    for(i=0; i<=511; i++)
                    {
                        ch_temp[i] = '\0';
                    }
                    goto next;
                }

                if(strcmp(ch_temp,DIM_Y)==0)
                {
                    do
                    {
                        numb = fgetc(fp_input);
                        if((int)(numb-'\n')!=0)
                        {
                            Add_Char_String(number,numb);
                        }
                        else
                        {
                            goto cont5;
                        }
cont5:
                        ;
                    }
                    while((int)(numb-'\n')!=0);
                    len = strlen(number);
                    sum = 0;
                    for(i=0; i<=len-1; i++)
                    {
                        sum = sum + (int)(number[i]-'0')*Pow(10,len-i-1);
                    }

                    Dim_y = sum;

                    if(number!=NULL)
                    {
                        free(number);
                        number = NULL;
                    }
                    number = (char *)malloc(16*sizeof(char));

                    for(i=0; i<=15; i++)
                    {
                        number[i] = '\0';
                    }
                    if(ch_temp!=NULL)
                    {
                        free(ch_temp);
                        ch_temp = NULL;
                    }
                    ch_temp = (char *)malloc(512*sizeof(char));
                    for(i=0; i<=511; i++)
                    {
                        ch_temp[i] = '\0';
                    }
                    goto next;
                }

                if(strcmp(ch_temp,DIM_Z)==0)
                {
                    do
                    {
                        numb = fgetc(fp_input);
                        if((int)(numb-'\n')!=0)
                        {
                            Add_Char_String(number,numb);
                        }
                        else
                        {
                            goto cont6;
                        }
cont6:
                        ;
                    }
                    while((int)(numb-'\n')!=0);
                    len = strlen(number);
                    sum = 0;
                    for(i=0; i<=len-1; i++)
                    {
                        sum = sum + (int)(number[i]-'0')*Pow(10,len-i-1);
                    }

                    Dim_z = sum;

                    if(number!=NULL)
                    {
                        free(number);
                        number = NULL;
                    }
                    number = (char *)malloc(16*sizeof(char));

                    for(i=0; i<=15; i++)
                    {
                        number[i] = '\0';
                    }

                    if(ch_temp!=NULL)
                    {
                        free(ch_temp);
                        ch_temp = NULL;
                    }
                    ch_temp = (char *)malloc(512*sizeof(char));
                    for(i=0; i<=511; i++)
                    {
                        ch_temp[i] = '\0';
                    }
                    goto next;
                }

                if(strcmp(ch_temp,Ph_N)==0)
                {
                    do
                    {
                        numb = fgetc(fp_input);
                        if((int)(numb-'\n')!=0)
                        {
                            Add_Char_String(number,numb);
                        }
                        else
                        {
                            goto cont7;
                        }
cont7:
                        ;
                    }
                    while((int)(numb-'\n')!=0);
                    len = strlen(number);
                    sum = 0;
                    for(i=0; i<=len-1; i++)
                    {
                        sum = sum + (int)(number[i]-'0')*Pow(10,len-i-1);
                    }

                    Vert_Size = sum;

                    if(number!=NULL)
                    {
                        free(number);
                        number = NULL;
                    }
                    number = (char *)malloc(16*sizeof(char));

                    for(i=0; i<=15; i++)
                    {
                        number[i] = '\0';
                    }

                    if(ch_temp!=NULL)
                    {
                        free(ch_temp);
                        ch_temp = NULL;
                    }
                    ch_temp = (char *)malloc(512*sizeof(char));

                    for(i=0; i<=511; i++)
                    {
                        ch_temp[i] = '\0';
                    }
                    goto next;
                }

                if(strcmp(ch_temp,Ph_mm)==0)
                {
                    do
                    {
                        numb = fgetc(fp_input);
                        if((int)(numb-'\n')!=0)
                        {
                            Add_Char_String(number,numb);
                        }
                        else
                        {
                            goto cont8;
                        }
cont8:
                        ;
                    }
                    while((int)(numb-'\n')!=0);
                    len = strlen(number);
                    sum = 0;
                    for(i=0; i<=len-1; i++)
                    {
                        sum = sum + (int)(number[i]-'0')*Pow(10,len-i-1);
                    }
                    Ms = sum;
                    if(number!=NULL)
                    {
                        free(number);
                        number = NULL;
                    }
                    number = (char *)malloc(16*sizeof(char));

                    for(i=0; i<=15; i++)
                    {
                        number[i] = '\0';
                    }

                    if(ch_temp!=NULL)
                    {
                        free(ch_temp);
                        ch_temp = NULL;
                    }
                    ch_temp = (char *)malloc(512*sizeof(char));
                    for(i=0; i<=511; i++)
                    {
                        ch_temp[i] = '\0';
                    }
                    goto next;
                }

                if(strcmp(ch_temp,SHIFT)==0)
                {
                     do{
                        numb = fgetc(fp_input);
                        if((int)(numb-'\n')!=0)
                        {
                            Add_Char_String(number,numb);
                        }else{
                            goto cont9;
                        }
cont9:                     ;
                    }while((int)(numb-'\n')!=0);
                    len = strlen(number);
                    j = 16;
                    sum1 = 0.0;
                    for(i=0;i<=len-1;i++)
                    {
                       if((int)(number[i]-'.')!=0)
                        {
                           if(i<=j)
                            {
                                sum1 = sum1 + ((int)(number[i]-'0'))*Pow(10,len-i-2);
                            }else{
                                sum1 = sum1 + ((int)(number[i]-'0'))*Pow(10,len-i-1);
                            }
                        }else{
                            j = i;
                        }
                    }
                    j = 0;
                    for(i=0;i<=len-1;i++)
                    {
                        j = j + 1;
                        if((int)(number[i]-'.')==0)
                        {
                            break;
                        }
                    }
                    floa_over = Pow(10,len-j);
                    sum1 = sum1 / floa_over;
                    shift = sum1;
                    if(number!=NULL)
                    {
                        free(number);
                        number = NULL;
                    }
                    number = (char *)malloc(16*sizeof(char));
                    for(i=0;i<=15;i++)
                    {
                        number[i] = '\0';
                    }
                    if(ch_temp!=NULL)
                    {
                        free(ch_temp);
                        ch_temp = NULL;
                    }
                    ch_temp = (char *)malloc(512*sizeof(char));
                    for(i=0;i<=511;i++)
                    {
                        ch_temp[i] = '\0';
                    }
                    goto next;
                }

                if(strcmp(ch_temp,MAXOCCUP)==0)
                {

                    do
                    {
                        numb = fgetc(fp_input);
                        if((int)(numb-'\n')!=0)
                        {
                            Add_Char_String(number,numb);
                        }
                        else
                        {
                            goto cont10;
                        }
cont10:
                        ;
                    }
                    while((int)(numb-'\n')!=0);
                    len = strlen(number);
                    sum = 0;
                    for(i=0; i<=len-1; i++)
                    {
                        sum = sum + (int)(number[i]-'0')*Pow(10,len-i-1);
                    }

                    Mos = sum;
                    if(number!=NULL)
                    {
                        free(number);
                        number = NULL;
                    }
                    number = (char *)malloc(16*sizeof(char));

                    for(i=0; i<=15; i++)
                    {
                        number[i] = '\0';
                    }

                    if(ch_temp!=NULL)
                    {
                        free(ch_temp);
                        ch_temp = NULL;
                    }
                    ch_temp = (char *)malloc(512*sizeof(char));
                    for(i=0; i<=511; i++)
                    {
                        ch_temp[i] = '\0';
                    }
                    goto next;
                }
                if(strcmp(ch_temp,MPICONTRAL)==0)
                {

                    do
                    {
                        numb = fgetc(fp_input);
                        if((int)(numb-'\n')!=0)
                        {
                            Add_Char_String(number,numb);
                        }
                        else
                        {
                            goto cont11;
                        }
cont11:
                        ;
                    }
                    while((int)(numb-'\n')!=0);
                    len = strlen(number);
                    sum = 0;
                    for(i=0; i<=len-1; i++)
                    {
                        sum = sum + (int)(number[i]-'0')*Pow(10,len-i-1);
                    }

                    alter_contral = sum;
                    if(number!=NULL)
                    {
                        free(number);
                        number = NULL;
                    }
                    number = (char *)malloc(16*sizeof(char));

                    for(i=0; i<=15; i++)
                    {
                        number[i] = '\0';
                    }

                    if(ch_temp!=NULL)
                    {
                        free(ch_temp);
                        ch_temp = NULL;
                    }
                    ch_temp = (char *)malloc(512*sizeof(char));
                    for(i=0; i<=511; i++)
                    {
                        ch_temp[i] = '\0';
                    }
                    goto next;
                }
                if(strcmp(ch_temp,PARALSWITCH)==0)
                {
                    do
                    {
                        numb = fgetc(fp_input);
                        if((int)(numb-'\n')!=0)
                        {
                            Add_Char_String(number,numb);
                        }
                        else
                        {
                            goto cont12;
                        }
cont12:
                        ;
                    }
                    while((int)(numb-'\n')!=0);
                    len = strlen(number);
                    sum = 0;
                    for(i=0; i<=len-1; i++)
                    {
                        sum = sum + (int)(number[i]-'0')*Pow(10,len-i-1);
                    }

                    Temping_Switch = sum;
                    if(number!=NULL)
                    {
                        free(number);
                        number = NULL;
                    }
                    number = (char *)malloc(16*sizeof(char));

                    for(i=0; i<=15; i++)
                    {
                        number[i] = '\0';
                    }

                    if(ch_temp!=NULL)
                    {
                        free(ch_temp);
                        ch_temp = NULL;
                    }
                    ch_temp = (char *)malloc(512*sizeof(char));
                    for(i=0; i<=511; i++)
                    {
                        ch_temp[i] = '\0';
                    }
                    goto next;
                }
 
                if(strcmp(ch_temp,INTERRUPT)==0)
                {
                    do
                    {
                        numb = fgetc(fp_input);
                        if((int)(numb-'\n')!=0)
                        {
                            Add_Char_String(number,numb);
                        }
                        else
                        {
                            goto cont13;
                        }
cont13:
                        ;
                    }
                    while((int)(numb-'\n')!=0);
                    len = strlen(number);
                    sum = 0;
                    for(i=0; i<=len-1; i++)
                    {
                        sum = sum + (int)(number[i]-'0')*Pow(10,len-i-1);
                    }

                    Interrupt_Switch = sum;

                    if(number!=NULL)
                    {
                        free(number);
                        number = NULL;
                    }
                    number = (char *)malloc(16*sizeof(char));

                    for(i=0; i<=15; i++)
                    {
                        number[i] = '\0';
                    }

                    if(ch_temp!=NULL)
                    {
                        free(ch_temp);
                        ch_temp = NULL;
                    }
                    ch_temp = (char *)malloc(512*sizeof(char));
                    for(i=0; i<=511; i++)
                    {
                        ch_temp[i] = '\0';
                    }
                    goto next;
                }

                if(strcmp(ch_temp,RESTART)==0)
                {
                    do
                    {
                        numb = fgetc(fp_input);
                        if((int)(numb-'\n')!=0)
                        {
                            Add_Char_String(number,numb);
                        }
                        else
                        {
                            goto cont14;
                        }
cont14:
                        ;
                    }
                    while((int)(numb-'\n')!=0);
                    len = strlen(number);
                    sum = 0;
                    for(i=0; i<=len-1; i++)
                    {
                        sum = sum + (int)(number[i]-'0')*Pow(10,len-i-1);
                    }

                    Restart_Switch = sum;

                    if(number!=NULL)
                    {
                        free(number);
                        number = NULL;
                    }
                    number = (char *)malloc(16*sizeof(char));

                    for(i=0; i<=15; i++)
                    {
                        number[i] = '\0';
                    }

                    if(ch_temp!=NULL)
                    {
                        free(ch_temp);
                        ch_temp = NULL;
                    }
                    ch_temp = (char *)malloc(512*sizeof(char));
                    for(i=0; i<=511; i++)
                    {
                        ch_temp[i] = '\0';
                    }
                    goto next;
                }

                if(strcmp(ch_temp,REBALANCE)==0)
                {
                    do
                    {
                        numb = fgetc(fp_input);
                        if((int)(numb-'\n')!=0)
                        {
                            Add_Char_String(number,numb);
                        }
                        else
                        {
                            goto cont15;
                        }
cont15:
                        ;
                    }
                    while((int)(numb-'\n')!=0);
                    len = strlen(number);
                    sum = 0;
                    for(i=0; i<=len-1; i++)
                    {
                        sum = sum + (int)(number[i]-'0')*Pow(10,len-i-1);
                    }

                    Rebalance_Switch = sum;

                    if(number!=NULL)
                    {
                        free(number);
                        number = NULL;
                    }
                    number = (char *)malloc(16*sizeof(char));

                    for(i=0; i<=15; i++)
                    {
                        number[i] = '\0';
                    }

                    if(ch_temp!=NULL)
                    {
                        free(ch_temp);
                        ch_temp = NULL;
                    }
                    ch_temp = (char *)malloc(512*sizeof(char));
                    for(i=0; i<=511; i++)
                    {
                        ch_temp[i] = '\0';
                    }
                    goto next;
                }

                if(strcmp(ch_temp,END)==0)
                {
                    break;
                }
            }

next:
            ;

        }
        while(ch!=EOF);
        result = 0;
    }
    else
    {
        printf("The input file do not exit!!");
        printf("\n");
        printf("Please check your input!!");
        result = -1;;
    }
    Clust_Type = 0;
    if(Lattice_Sharpe==2)
    {
	Clust_Type = Vert_Size;	    
    }

    if(pwd_temp!=NULL)
    {
        free(pwd_temp);
        pwd_temp = NULL;
    }
    if(fp_input!=NULL)
    {
        fclose(fp_input);
        fp_input = NULL;
    }
    if(ch_temp!=NULL)
    {
        free(ch_temp);
        ch_temp = NULL;
    }
    if(number!=NULL)
    {
        free(number);
        number = NULL;
    }
    if(pwd_temp!=NULL)
    {
        free(pwd_temp);
        pwd_temp = NULL;
    }

    return result;
}



void Read_temping_para(char *pwd)
{
    int i, j, len, result;
    int sum,is;
    double sum1,floa_over;
    char *pwd_temp;
    char numb;
    char *number;
    number = (char *)malloc(16*sizeof(char));
    pwd_temp = (char *)malloc(1024*sizeof(char));
    strcpy(pwd_temp,pwd);
    strcat(pwd_temp,"/temping.dat");
    char *ch_temp = (char *)malloc(16*sizeof(char));
    FILE *fp_temping_para_input;
    fp_temping_para_input = fopen(pwd_temp,"r");
    for(i=0;i<=15;i++)
    {
	number[i] = '\0';
	ch_temp[i] = '\0';
    }
    is = 0;
    if(fp_temping_para_input!=NULL)
    {
        for(is=0; is<=process_numb-1; is++)
        {
            do{
                numb = fgetc(fp_temping_para_input);
                if(((int)(numb-' ')!=0)&&((int)(numb-'\n')!=0))
                {
                    Add_Char_String(number,numb);
                }
                else
                {
                    goto cont13;
                }
cont13:          ;
            }while(((int)(numb-' ')!=0)&&((int)(numb-'\n')!=0));
            len = strlen(number);
            j = 16;
            sum1 = 0.0;
            for(i=0; i<=len-1; i++)
            {
                if((int)(number[i]-'.')!=0)
                {
                    if(i<=j)
                    {
                        sum1 = sum1 + ((int)(number[i]-'0'))*Pow(10,len-i-2);
                    }
                    else
                    {
                        sum1 = sum1 + ((int)(number[i]-'0'))*Pow(10,len-i-1);
                    }
                }
                else
                {
                    j = i;
                }
            }
            j = 0;
            for(i=0; i<=len-1; i++)
            {
                j = j + 1;
                if((int)(number[i]-'.')==0)
                {
                    break;
                }
            }
            floa_over = Pow(10,len-j);
            sum1 = sum1 / floa_over;
            T[is] = sum1;
            if(number!=NULL)
            {
                free(number);
                number = NULL;
            }
            number = (char *)malloc(16*sizeof(char));
            for(i=0; i<=15; i++)
            {
                number[i] = '\0';
            }
        }

        for(is=0; is<=process_numb-1; is++)
        {
            do{
                numb = fgetc(fp_temping_para_input);
                if(((int)(numb-' ')!=0)&&((int)(numb-'\n')!=0))
                {
                    Add_Char_String(number,numb);
                }
                else
                {
                    goto cont14;
                }
cont14:          ;
            }while(((int)(numb-' ')!=0)&&((int)(numb-'\n')!=0));
            len = strlen(number);
            j = 16;
            sum1 = 0.0;
            for(i=0; i<=len-1; i++)
            {
                if((int)(number[i]-'.')!=0)
                {
                    if(i<=j)
                    {
                        sum1 = sum1 + ((int)(number[i]-'0'))*Pow(10,len-i-2);
                    }
                    else
                    {
                        sum1 = sum1 + ((int)(number[i]-'0'))*Pow(10,len-i-1);
                    }
                }
                else
                {
                    j = i;
                }
            }
            j = 0;
            for(i=0; i<=len-1; i++)
            {
                j = j + 1;
                if((int)(number[i]-'.')==0)
                {
                    break;
                }
            }
            floa_over = Pow(10,len-j);
            sum1 = sum1 / floa_over;
            V[is] = sum1;
            if(number!=NULL)
            {
                free(number);
                number = NULL;
            }
            number = (char *)malloc(16*sizeof(char));
            for(i=0; i<=15; i++)
            {
                number[i] = '\0';
            }
        }


        for(is=0; is<=process_numb-1; is++)
        {
            do{
                numb = fgetc(fp_temping_para_input);
                if(((int)(numb-' ')!=0)&&((int)(numb-'\n')!=0))
                {
                    Add_Char_String(number,numb);
                }
                else
                {
                    goto cont15;
                }
cont15:          ;
            }while(((int)(numb-' ')!=0)&&((int)(numb-'\n')!=0));
            len = strlen(number);
            j = 16;
            sum1 = 0.0;
            for(i=0; i<=len-1; i++)
            {
                if((int)(number[i]-'.')!=0)
                {
                    if(i<=j)
                    {
                        sum1 = sum1 + ((int)(number[i]-'0'))*Pow(10,len-i-2);
                    }
                    else
                    {
                        sum1 = sum1 + ((int)(number[i]-'0'))*Pow(10,len-i-1);
                    }
                }
                else
                {
                    j = i;
                }
            }
            j = 0;
            for(i=0; i<=len-1; i++)
            {
                j = j + 1;
                if((int)(number[i]-'.')==0)
                {
                    break;
                }
            }
            floa_over = Pow(10,len-j);
            sum1 = sum1 / floa_over;
            V_N[is] = sum1;
            if(number!=NULL)
            {
                free(number);
                number = NULL;
            }
            number = (char *)malloc(16*sizeof(char));
            for(i=0; i<=15; i++)
            {
                number[i] = '\0';
            }
        }


        for(is=0; is<=process_numb-1; is++)
        {
            do{
                numb = fgetc(fp_temping_para_input);
                if((((int)(numb-' ')!=0))&&((int)(numb-'\n')!=0))
                {
                    Add_Char_String(number,numb);
                }
                else
                {
                    goto cont16;
                }
cont16:
                ;
            }while(((int)(numb-' ')!=0)&&((int)(numb-'\n')!=0));
            len = strlen(number);
            j = 16;
            sum1 = 0.0;
            for(i=0; i<=len-1; i++)
            {
                if((int)(number[i]-'.')!=0)
                {
                    if(i<=j)
                    {
                        sum1 = sum1 + ((int)(number[i]-'0'))*Pow(10,len-i-2);
                    }
                    else
                    {
                        sum1 = sum1 + ((int)(number[i]-'0'))*Pow(10,len-i-1);
                    }
                }
                else
                {
                    j = i;
                }
            }
            j = 0;
            for(i=0; i<=len-1; i++)
            {
                j = j + 1;
                if((int)(number[i]-'.')==0)
                {
                    break;
                }
            }
            floa_over = Pow(10,len-j);
            sum1 = sum1 / floa_over;
            Miu[is] = sum1;
            if(number!=NULL)
            {
                free(number);
                number = NULL;
            }
            number = (char *)malloc(16*sizeof(char));
            for(i=0; i<=15; i++)
            {
                number[i] = '\0';
            }
        }
 
       for(is=0; is<=process_numb-1; is++)
        {
            do{
                numb = fgetc(fp_temping_para_input);
                if((((int)(numb-' ')!=0))&&((int)(numb-'\n')!=0))
                {
                    Add_Char_String(number,numb);
                }
                else
                {
                    goto cont17;
                }
cont17:
                ;
            }while(((int)(numb-' ')!=0)&&((int)(numb-'\n')!=0));
            len = strlen(number);
            j = 16;
            sum1 = 0.0;
            for(i=0; i<=len-1; i++)
            {
                if((int)(number[i]-'.')!=0)
                {
                    if(i<=j)
                    {
                        sum1 = sum1 + ((int)(number[i]-'0'))*Pow(10,len-i-2);
                    }
                    else
                    {
                        sum1 = sum1 + ((int)(number[i]-'0'))*Pow(10,len-i-1);
                    }
                }
                else
                {
                    j = i;
                }
            }
            j = 0;
            for(i=0; i<=len-1; i++)
            {
                j = j + 1;
                if((int)(number[i]-'.')==0)
                {
                    break;
                }
            }
            floa_over = Pow(10,len-j);
            sum1 = sum1 / floa_over;
            Miu1[is] = sum1;
            if(number!=NULL)
            {
                free(number);
                number = NULL;
            }
            number = (char *)malloc(16*sizeof(char));
            for(i=0; i<=15; i++)
            {
                number[i] = '\0';
            }
        }


       for(is=0; is<=process_numb-1; is++)
        {
            do{
                numb = fgetc(fp_temping_para_input);
                if((((int)(numb-' ')!=0))&&((int)(numb-'\n')!=0))
                {
                    Add_Char_String(number,numb);
                }
                else
                {
                    goto cont18;
                }
cont18:
                ;
            }while(((int)(numb-' ')!=0)&&((int)(numb-'\n')!=0));
            len = strlen(number);
            j = 16;
            sum1 = 0.0;
            for(i=0; i<=len-1; i++)
            {
                if((int)(number[i]-'.')!=0)
                {
                    if(i<=j)
                    {
                        sum1 = sum1 + ((int)(number[i]-'0'))*Pow(10,len-i-2);
                    }
                    else
                    {
                        sum1 = sum1 + ((int)(number[i]-'0'))*Pow(10,len-i-1);
                    }
                }
                else
                {
                    j = i;
                }
            }
            j = 0;
            for(i=0; i<=len-1; i++)
            {
                j = j + 1;
                if((int)(number[i]-'.')==0)
                {
                    break;
                }
            }
            floa_over = Pow(10,len-j);
            sum1 = sum1 / floa_over;
            Miu2[is] = sum1;
            if(number!=NULL)
            {
                free(number);
                number = NULL;
            }
            number = (char *)malloc(16*sizeof(char));
            for(i=0; i<=15; i++)
            {
                number[i] = '\0';
            }
        }
        for(is=0;is<=process_numb-1;is++)
        {
            do{
                numb = fgetc(fp_temping_para_input);
                if(((int)(numb-' ')!=0)&&((int)(numb-'\n')!=0))
                {
                    Add_Char_String(number,numb);
                }
                else
                {
                    goto cont19;
                }
cont19:
                ;
            }while(((int)(numb-' ')!=0)&&((int)(numb-'\n')!=0));
            len = strlen(number);
            j = 16;
            sum1 = 0.0;
            for(i=0; i<=len-1; i++)
            {
                if((int)(number[i]-'.')!=0)
                {
                    if(i<=j)
                    {
                        sum1 = sum1 + ((int)(number[i]-'0'))*Pow(10,len-i-2);
                    }
                    else
                    {
                        sum1 = sum1 + ((int)(number[i]-'0'))*Pow(10,len-i-1);
                    }
                }
                else
                {
                    j = i;
                }
            }
            j = 0;
            for(i=0; i<=len-1; i++)
            {
                j = j + 1;
                if((int)(number[i]-'.')==0)
                {
                    break;
                }
            }
            floa_over = Pow(10,len-j);
            sum1 = sum1 / floa_over;
            Beta[is] = sum1;
            if(number!=NULL)
            {
                free(number);
                number = NULL;
            }
            number = (char *)malloc(16*sizeof(char));
            for(i=0; i<=15; i++)
            {
                number[i] = '\0';
            }
        }
    }
    if(pwd_temp!=NULL)
    {
        free(pwd_temp);
        pwd_temp = NULL;
    }
    if(fp_temping_para_input!=NULL)
    {
        fclose(fp_temping_para_input);
        fp_temping_para_input = NULL;
    }
    if(number!=NULL)
    {
        free(number);
        number = NULL;
    }
}

void Print_Input_Para(char *pwd)
{
    int i, j;
    int rank_numb;
    char *pwd_temp;
    char *evn_char = (char *)malloc(512*sizeof(char));
    pwd_temp = (char *)malloc(1024*sizeof(char));
    rank_numb = my_rank;
    Chart2Numb(rank_numb,evn_char);
    strcpy(pwd_temp,pwd);
    strcat(pwd_temp,"/");
    strcat(pwd_temp,evn_char);
    strcat(pwd_temp,"_Input.para");
    FILE *fp;
    fp = fopen(pwd_temp,"w");

    fprintf(fp,"%s","The dimesions of system is: ");
    fprintf(fp,"%d",Dim);
    fprintf(fp,"%s","\n");
    fprintf(fp,"%s","The scalar of x-direction: ");
    fprintf(fp,"%d",Dim_x);
    fprintf(fp,"%s","\n");
    fprintf(fp,"%s","The scalar of y-direction: ");
    fprintf(fp,"%d",Dim_y);
    fprintf(fp,"%s","\n");
    fprintf(fp,"%s","The scalar of z-direction: ");
    fprintf(fp,"%d",Dim_z);
    fprintf(fp,"%s","\n");
    fprintf(fp,"%s","The sizeof of Cluster-Vert: ");
    fprintf(fp,"%d",Vert_Size);
    fprintf(fp,"%s","\n");
    fprintf(fp,"%s","The number of z-direction Couple Parameter: ");
    for(i=0;i<=process_numb-1;i++)
    {
        fprintf(fp,"%lf%s",V[i]," ");
    }
    fprintf(fp,"%s","\n");
    fprintf(fp,"%s","The number of z-direction sub_negbor couple Parameter: ");
    for(i=0;i<=process_numb-1;i++)
    {
        fprintf(fp,"%lf%s",V_N[i]," ");
    }
    fprintf(fp,"%s","\n");
    fprintf(fp,"%s","The number of x-y direction Couple Parameter: ");
    for(i=0;i<=process_numb-1;i++)
    {
        fprintf(fp,"%lf%s",T[i]," ");
    }
    fprintf(fp,"%s","\n");
    fprintf(fp,"%s","The chemical potential: ");
    for(i=0;i<=process_numb-1;i++)
    {
        fprintf(fp,"%lf%s",Miu[i]," ");
    }
    fprintf(fp,"%s","\n");
    fprintf(fp,"%s","The length of virtual time sequeence: ");
    fprintf(fp,"%d",MM);
    fprintf(fp,"%s","\n");
    fprintf(fp,"%s","The number of Beta: ");
    for(i=0;i<=process_numb-1;i++)
    {
        fprintf(fp,"%lf%s",Beta[i]," ");
    }
    fprintf(fp,"%s","\n");
    fprintf(fp,"%s","The enegy-level shift is: ");
    fprintf(fp,"%lf",energy_shift);
    fprintf(fp,"%s","\n");
    fprintf(fp,"%s","The msteps was setting to: ");
    fprintf(fp,"%ld",Mstep);
    fprintf(fp,"%s","\n");
    fprintf(fp,"%s","The istep was setting to: ");
    fprintf(fp,"%d",Istep);
    fprintf(fp,"%s","\n");
    fprintf(fp,"%s","The nbin was setting to: ");
    fprintf(fp,"%d",Nbin);
    fprintf(fp,"%s","\n");
    if(fp!=NULL)
    {
        fclose(fp);
        fp =NULL;
    }

    if(pwd_temp!=NULL)
    {
        free(pwd_temp);
        pwd_temp = NULL;
    }


}

void Chart2Numb(int numb, char *C)
{
    int i, dec, k, is;
    i = 10;
    dec = 10;
    is = 0;
    do{
        k = numb%10;
        C[is] = (48 + k);
        is++;
        i = i*dec;
	numb = numb/10;
    }while(numb!=0);
    C[is] = '\0';
}


void Out_put_energy(char *pwd)
{
    int i, j,rank;
    double energy = 0.0;
    double sus = 0.0;
    double error,tau;
    FILE *fp;
    char *pwd_temp = (char *)malloc(1024*sizeof(char));
    strcpy(pwd_temp,pwd);
    strcat(pwd_temp,"/");
    strcat(pwd_temp,"energy_out");
    fp = fopen(pwd_temp,"a");
    rank = Nbin*Mstep;
    for(i=0;i<rank;i++)
    {
        energy = energy + Ob.energy[i];
    }
    fprintf(fp,"energy:");
    fprintf(fp,"%s","\n");
    energy = energy/(double)(rank);
    fprintf(fp,"%lf",energy);
    fprintf(fp,"%s","\n");
    error = Calc_Error_Bar(Ob.energy,rank,1000);
    tau = Calc_Auto_Corr_Time(Ob.energy,rank,10000);
    fprintf(fp,"error_bar:\n");
    fprintf(fp,"%lf%s",error,"\n");
    fprintf(fp,"auto_correction_time:\n");
    fprintf(fp,"%lf%s",tau,"\n");
    fclose(fp);
    fp = NULL;
    if(pwd_temp!=NULL)
    {
        free(pwd_temp);
	pwd_temp = NULL;
    }
}


void Out_put_mag(char *pwd)
{
    int i, j,rank;
    double mag = 0.0;
    double Mag_sq = 0.0;
    double Sf = 0.0;
    double error,tau;
    FILE *fp;
    char *pwd_temp = (char *)malloc(1024*sizeof(char));
    strcpy(pwd_temp,pwd);
    strcat(pwd_temp,"/");
    strcat(pwd_temp,"mag_out");
    fp = fopen(pwd_temp,"a");
    rank = Nbin*Mstep;
    for(i=0;i<rank;i++)
    {
        mag = mag + Ob.Mag[i];
    }
    mag = mag/(double)(rank);
    fprintf(fp,"mag:\n");
    fprintf(fp,"%lf%s",mag,"\n");
    error = Calc_Error_Bar(Ob.Mag,rank,1000);
    tau = Calc_Auto_Corr_Time(Ob.Mag,rank,10000);
    fprintf(fp,"error_bar:\n");
    fprintf(fp,"%lf%s",error,"\n");
    fprintf(fp,"auto_correction_time:\n");
    fprintf(fp,"%lf%s",tau,"\n");
    for(i=0;i<rank;i++)
    {
        Mag_sq = Mag_sq + Ob.Mag_sq[i];
    }
    fprintf(fp,"mag_square:\n");
    Mag_sq = Mag_sq/(double)(rank);   
    fprintf(fp,"%lf",Mag_sq);
    fprintf(fp,"%s","\n");
    error = Calc_Error_Bar(Ob.Mag_sq,rank,1000);
    tau = Calc_Auto_Corr_Time(Ob.Mag_sq,rank,10000);
    fprintf(fp,"error_bar:\n");
    fprintf(fp,"%lf%s",error,"\n");
    fprintf(fp,"auto_correction_time:\n");
    fprintf(fp,"%lf%s",tau,"\n");
    for(i=0;i<rank;i++)
    {
        Sf = Sf + Ob.Sf[i];
    }
    fprintf(fp,"mag_structure_factor:\n");
    Sf = Sf/(double)(rank);   
    fprintf(fp,"%lf",Sf);
    fprintf(fp,"%s","\n");
    error = Calc_Error_Bar(Ob.Sf,rank,1000);
    tau = Calc_Auto_Corr_Time(Ob.Sf,rank,10000);
    fprintf(fp,"error_bar:\n");
    fprintf(fp,"%lf%s",error,"\n");
    fprintf(fp,"auto_correction_time:\n");
    fprintf(fp,"%lf%s",tau,"\n");
    fclose(fp);
    fp = NULL;
    if(pwd_temp!=NULL)
    {
        free(pwd_temp);
	pwd_temp = NULL;
    }
}


void Out_put_winding(char *pwd)
{
    int i, j,rank;
    double winding = 0.0;
    double error,tau;
    FILE *fp;
    char *pwd_temp = (char *)malloc(1024*sizeof(char));
    strcpy(pwd_temp,pwd);
    strcat(pwd_temp,"/");
    strcat(pwd_temp,"winding_out");
    fp = fopen(pwd_temp,"a");
    rank = Nbin*Mstep;
    for(i=0;i<rank;i++)
    {
        winding = winding + Ob.Wind[i];
    }
    fprintf(fp,"winding:\n");
    winding = winding/(double)(rank);
    fprintf(fp,"%lf",winding);
    fprintf(fp,"%s","\n");
    error = Calc_Error_Bar(Ob.Wind,rank,1000);
    tau = Calc_Auto_Corr_Time(Ob.Wind,rank,10000);
    fprintf(fp,"error_bar:\n");
    fprintf(fp,"%lf%s",error,"\n");
    fprintf(fp,"auto_correction_time:\n");
    fprintf(fp,"%lf%s",tau,"\n");
    fclose(fp);
    fp = NULL;
    if(pwd_temp!=NULL)
    {
        free(pwd_temp);
	pwd_temp = NULL;
    }
}
double Calc_Error_Bar(double *arry, int length,int bin)
{
	int i, j, k,l,down_bound, up_bound;
	double sum = 0.0, avg,avg1,serror,Bias;
	double sum1;
	double *avg_arry = (double *)malloc(bin*sizeof(double));
	for(i=0;i<length;i++)
	{
		sum = sum + arry[i];
	}
	avg = sum/(double)(length);
	l = length/bin;
        for(i=0;i<bin;i++)
        {
                sum1 = 0.0;
                down_bound = i*l;
                up_bound = (i+1)*l-1;
                for(k=down_bound;k<=up_bound;k++)
                {
                        sum1 = sum1 + arry[k];
                }
                avg_arry[i] = sum - sum1;
                avg_arry[i] = avg_arry[i]/(length-l);
        }

        sum1 = 0.0;
        for(i=0;i<=bin-1;i++)
        {
                sum1 = sum1 + avg_arry[i];
        }
        avg1 = sum1/bin;
        Bias = (bin-1)*(avg1-avg);
        sum1 = 0.0;
        for(i=0;i<bin;i++)
        {
                sum1 = sum1 + avg_arry[i]*avg_arry[i];
        }
        sum1 = sum1/bin;
        serror = (sum1-avg1*avg1)*(bin-1);
        serror = sqrt(serror);
	if(avg_arry!=NULL)
	{
		free(avg_arry);
		avg_arry = NULL;
	}
	return serror;
}

double Calc_Auto_Corr_Time(double *arry, int length,int tmax)
{
	int i, j, k,counter;
	double sum = 0.0, avg,max,temp,fact1,fact2,tao;
	double sum1;
	double *auto_c = (double *)malloc(tmax*sizeof(double));
	for(i=0;i<length;i++)
	{
		sum = sum + arry[i];
	}
	avg = sum/(double)(length);
	for(i=0;i<tmax;i++)
        {
                temp = 0.0;
                for(k=i;k<length;k++)
                {
                        fact1 = arry[k-i] - avg;
                        fact2 = arry[k] - avg;
                        temp = temp + fact1*fact2;
                }
                auto_c[i] = temp/(length-i);
        }
        max = auto_c[0];
	for(i=0;i<tmax;i++)
        {
                auto_c[i] = auto_c[i]/max;
        }
	counter = 0;
        i= 0;
        while(auto_c[i] > 0.0)
        {
                counter++;
                i++;
        }
        tao = 0.0;
        for(i=1;i<=counter;i++)
        {
                tao = tao + auto_c[i];
        }
        tao = tao + 0.5;
	if(auto_c!=NULL)
	{
		free(auto_c);
		auto_c = NULL;
	}
	return tao;
}

void Print_Class(int **class, int IS, int type, char *pwd)
{
	int i, j;
	FILE *fp;
	int in_leg_type, out_leg_type;
	char *pwd_temp = (char *)malloc(1024*sizeof(char));
	strcpy(pwd_temp,pwd);
	strcat(pwd_temp,"/");
	strcat(pwd_temp,"class.txt");
	fp = fopen(pwd_temp,"w+");
	for(i=0;i<=IS-1;i++)
	{
		fprintf(fp,"%s","the index of the Vertex:");
		fprintf(fp,"%d",class[i][0]);
		fprintf(fp,"%s","\n");
		fprintf(fp,"%s","in leg type");
		fprintf(fp,"%d",type);
		if(class[i][3]==1)
		{
		 	in_leg_type = 0;
			out_leg_type = 0;
		}
		if(class[i][3]==2)
		{
			in_leg_type = 1;
			out_leg_type = 1;
		}
		if(class[i][3]==3)
		{
			in_leg_type = 0;
			out_leg_type = 1;
		}
		if(class[i][3]==4)
		{
			in_leg_type = 1;
			out_leg_type = 0;
		}
		fprintf(fp,"%s","in leg number:");
		fprintf(fp,"%d",(in_leg_type*Vert_Size + class[i][1]));
		fprintf(fp,"%s","\n");
		fprintf(fp,"%s","out leg number:");
		fprintf(fp,"%d",(out_leg_type*Vert_Size + class[i][2]));
		fprintf(fp,"%s","\n");
		for(j=0;j<=Vert_Size-1;j++)
		{
			fprintf(fp,"%d%s",Vertex_Leg[1][class[i][0]*Vert_Size+j]," ");
		}
		fprintf(fp,"%s","\n");
		fprintf(fp,"%s","-------------------------");
		fprintf(fp,"%s","\n");
		for(j=0;j<=Vert_Size-1;j++)
		{
			fprintf(fp,"%d%s",Vertex_Leg[0][class[i][0]*Vert_Size+j]," ");
		}
		fprintf(fp,"%s","\n");
	}
	
	fclose(fp);
	fp = NULL;
	if(pwd_temp!=NULL)
	{
		free(pwd_temp);
		pwd_temp = NULL;
	}
}





