#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>
#include "datastruct.h"
#include "myfunction.h"



void makelattice(int dim,int dim_x,int dim_y,int dim_z,int clust_type,int BC)
{
    int i, j, k;
    int x1, y1, z1, posi;
    int temp, temp1, temp2, trangle_posi, trangle_posi1, trangle_posi2;
    int hex_posi, hex_posi1, hex_posi2;
    int bond_numb, site_numb;
    int shift1;
    if(dim==1)
    {
        Nsite = dim_x;
        Nbond = Nsite;
        Vert_Size = 2;
	Clust_Type = 2;
        Bsite = (int **)malloc(2*Nbond*sizeof(int));
        for(i=0;i<=Nbond-1;i++)
        {
            Bsite[i] = (int *)malloc(Vert_Size*sizeof(int));
        }
        for(x1=0;x1<=dim_x-1;x1++)
        {
            for(i=0;i<=1;i++)
            {
                Bsite[x1][i] = (x1+i)%dim_x;
            }
        }
        hopping1 = (int *)malloc(Vert_Size*sizeof(int));
        hopping2 = (int *)malloc(Vert_Size*sizeof(int));

        hopping1[0] = 0;
        hopping1[1] = 1;
        hopping2[0] = 1;
        hopping2[1] = 0;
    }

    Lattice = (int *)malloc(Nsite*sizeof(int));
    for(i=0;i<=Nsite-1;i++)
    {
        Lattice[i] = Min(Mos,(int)(Random()*((double)(Mos+1))));
    }
}
