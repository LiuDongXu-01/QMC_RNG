#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>
#include "datastruct.h"
#include "myfunction.h"
#include <string.h>
#include <time.h>


void Init_Obser_Para(void)
{
    int i = 0;
    int j = 0;
    int k = 0;

    Ob.energy = (double *)malloc(Nbin*Mstep*sizeof(double));
    Ob.energy1 = (double *)malloc(Nbin*Mstep*sizeof(double));
    Ob.energy_ken = (double *)malloc(Nbin*Mstep*sizeof(double));
    swap_times = 0;
    pararec = (int *)malloc(Nbin*Mstep*sizeof(int));
    tpararec = (int *)malloc(Nbin*Mstep*process_numb*sizeof(int));
    Ob.energy = (double *)malloc(Nbin*Mstep*sizeof(double));
    Ob.Mag = (double *)malloc(Nbin*Mstep*sizeof(double));
    Ob.Mag_sq = (double *)malloc(Nbin*Mstep*sizeof(double));
    Ob.Sf = (double *)malloc(Nbin*Mstep*sizeof(double));
    Ob.Wind = (double *)malloc(Nbin*Mstep*sizeof(double));
}

void Measure_Energy(int step)
{
    int i, j, off_num = 0;
    double temp;
    temp = (double)(nh)/Beta[paraenv] - energy_shift[paraenv]*Nbond;
    Ob.energy[step] = temp;
}

void Measure_Mag(int step)
{
    int i, j, off_num = 0;
    double mag = 0.0;
    double sf1 = 0.0;
    double sf2 = 0.0;
    for(i=0;i<Nsite;i++)
    {
	    mag = mag + (double)(Lattice[i]) - 0.5;
    }
    for(i=0;i<Nsite;i=i+2)
    {
	sf1 = sf1 + (double)(Lattice[i])-0.5;
    }
    for(i=1;i<Nsite;i=i+2)
    {
	sf2 = sf2 + (double)(Lattice[i])-0.5;
    }
    
    Ob.Mag[step] = mag;
    Ob.Mag_sq[step] = mag*mag;
    mag = (sf1-sf2);
    Ob.Sf[step] = mag*mag/(double)(Nsite*Nsite);
}

void Measure_Wind(int step)
{
    int i, bond;
    int r, l;
    int windx = 0;
    double winding;
    int test;
    for(i=0;i<MM;i++)
    {
	    if(Opstring[i][0]>1)
	    {
		bond = Opstring[i][2];
		r = Vertex_Sum[0][Opstring[i][1]];
		l = Vertex_Sum[1][Opstring[i][1]];
		if(bond < Nsite)
		{
			if(l < r)
			{
				windx = windx + 1;
			}
			if(r < l)
			{
				windx = windx - 1;
			}
		}
	    }else{
		    continue;
	    }
    }
    test = windx%Dim_x;
    if(test==0)
    {
	winding = (double)(windx/Dim_x);
	Ob.Wind[step] = winding*winding;
    }else{
	    printf("error happend when measure the winding number!!\n");
    }
}

void Fourier_Trans_Init(void)
{
	int i, j, k, mark,count;
	int p1, p2, p3;
	int dim_x, dim_y;
	dim_x = Dim_x;
	dim_y = Dim_y;
	double Kx0, Ky0, Kx1, Ky1;
	double stepx, stepy;
	double pi = 3.14159265358979323;
	double normal;
	double px, py;
	double ds = 0.0, dis = 0.0;
	double B1x, B2x, B1y, B2y;
	double x_bond, y_bond, k1;
	B1x = 2.0*pi;
	B1y = 2*sqrt(3.0)*pi/3.0;
	B2x = -2.0*pi;
	B2y = B1y;
	B1x = B1x/dim_x;
	B2x = B2x/dim_y;
	B1y = B1y/dim_x;
	B2y = B2y/dim_y;
//	K_num = dim_x+2;
	/*Init the Kq, and all the Kq*/
	K_num = 0;
	for(i=0;i<=dim_x;i++)
	{
		for(j=0;j<=dim_y;j++)
		{
			px = i*B1x + j*B2x;
			py = i*B1y + j*B2y;
			if(fabs(px) < 0.00000000001)
			{
				ds = px*px + py*py;
				if(ds<(4*pi*pi/3.0)+0.0000000001)
				{
					K_num++;
				}
				continue;
			}
			k1 = py/px;
			if((k1<sqrt(3.0)-0.000000001)&&(-0.000000001<k1))
			{	
				if(0.0<px)
				{
					x_bond = 4*pi*sqrt(3.0)/(3.0*(k1+sqrt(3.0)));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						K_num++;
					}
				}
				if(px<0.0)
				{
					x_bond = -4*pi*sqrt(3.0)/(3.0*(k1+sqrt(3.0)));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						K_num++;
					}
				}
			}
			if((k1<-sqrt(3.0)-0.000000001)||(sqrt(3.0)-0.000000001<k1))
			{
				if(0.0<py)
				{
					x_bond = 2*pi*sqrt(3.0)/(3.0*k1);
					y_bond = 2*sqrt(3.0)*pi/3.0;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						K_num++;
					}
				}
				if(py<0.0)
				{
					x_bond = -2*pi*sqrt(3.0)/(3.0*k1);
					y_bond = -2*sqrt(3.0)*pi/3.0;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						K_num++;
					}
				}
				
			}
			if((k1<-0.000000001)&&(-sqrt(3.0)-0.000000001<k1))
			{
				if(0.0<py)
				{
					x_bond = 4*pi*sqrt(3.0)/(3.0*(k1-sqrt(3.0)));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						K_num++;
					}
				}
				if(py<0.0)
				{
					x_bond = 4*pi*sqrt(3.0)/(3.0*(sqrt(3.0)-k1));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						K_num++;
					}
				}
			}
		}
	}
	for(i=0;i<=dim_x;i++)
	{
		for(j=0;j<=dim_y;j++)
		{
			px = i*B1x - j*B2x;
			py = i*B1y - j*B2y;
			k1 = py/px;
			if(fabs(px) < 0.00000000001)
			{
				ds = px*px + py*py;
				if(ds<(4*pi*pi/3.0)+0.0000000001)
				{
					K_num++;
				}
				continue;
			}
			k1 = py/px;
			if((k1<sqrt(3.0)-0.000000001)&&(-0.000000001<k1))
			{	
				if(0.0<px)
				{
					x_bond = 4*pi*sqrt(3.0)/(3.0*(k1+sqrt(3.0)));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						K_num++;
					}
				}
				if(px<0.0)
				{
					x_bond = -4*pi*sqrt(3.0)/(3.0*(k1+sqrt(3.0)));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						K_num++;
					}
				}
			}
			if((k1<-sqrt(3.0)-0.000000001)||(sqrt(3.0)-0.000000001<k1))
			{
				if(0.0<py)
				{
					x_bond = 2*pi*sqrt(3.0)/(3.0*k1);
					y_bond = 2*sqrt(3.0)*pi/3.0;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						K_num++;
					}
				}
				if(py<0.0)
				{
					x_bond = -2*pi*sqrt(3.0)/(3.0*k1);
					y_bond = -2*sqrt(3.0)*pi/3.0;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						K_num++;
					}
				}
				
			}
			if((k1<-0.000000001)&&(-sqrt(3.0)-0.000000001<k1))
			{
				if(0.0<py)
				{
					x_bond = 4*pi*sqrt(3.0)/(3.0*(k1-sqrt(3.0)));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						K_num++;
					}
				}
				if(py<0.0)
				{
					x_bond = 4*pi*sqrt(3.0)/(3.0*(sqrt(3.0)-k1));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						K_num++;
					}
				}
			}

		}
	}
	for(i=0;i<=dim_x;i++)
	{
		for(j=0;j<=dim_y;j++)
		{
			px = -i*B1x + j*B2x;
			py = -i*B1y + j*B2y;
			k1 = py/px;
			if(fabs(px) < 0.00000000001)
			{
				ds = px*px + py*py;
				if(ds<(4*pi*pi/3.0)+0.0000000001)
				{
					K_num++;
				}
				continue;
			}
			k1 = py/px;
			if((k1<sqrt(3.0)-0.000000001)&&(-0.000000001<k1))
			{	
				if(0.0<px)
				{
					x_bond = 4*pi*sqrt(3.0)/(3.0*(k1+sqrt(3.0)));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						K_num++;
					}
				}
				if(px<0.0)
				{
					x_bond = -4*pi*sqrt(3.0)/(3.0*(k1+sqrt(3.0)));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						K_num++;
					}
				}
			}
			if((k1<-sqrt(3.0)-0.000000001)||(sqrt(3.0)-0.000000001<k1))
			{
				if(0.0<py)
				{
					x_bond = 2*pi*sqrt(3.0)/(3.0*k1);
					y_bond = 2*sqrt(3.0)*pi/3.0;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						K_num++;
					}
				}
				if(py<0.0)
				{
					x_bond = -2*pi*sqrt(3.0)/(3.0*k1);
					y_bond = -2*sqrt(3.0)*pi/3.0;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						K_num++;
					}
				}
				
			}
			if((k1<-0.000000001)&&(-sqrt(3.0)-0.000000001<k1))
			{
				if(0.0<py)
				{
					x_bond = 4*pi*sqrt(3.0)/(3.0*(k1-sqrt(3.0)));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						K_num++;
					}
				}
				if(py<0.0)
				{
					x_bond = 4*pi*sqrt(3.0)/(3.0*(sqrt(3.0)-k1));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						K_num++;
					}
				}
			}

			
		}
	}
	for(i=0;i<=dim_x;i++)
	{
		for(j=0;j<=dim_y;j++)
		{
			px = -i*B1x - j*B2x;
			py = -i*B1y - j*B2y;
			k1 = py/px;
			if(fabs(px) < 0.00000000001)
			{
				ds = px*px + py*py;
				if(ds<(4*pi*pi/3.0)+0.0000000001)
				{
					K_num++;
				}
				continue;
			}
			k1 = py/px;
			if((k1<sqrt(3.0)-0.000000001)&&(-0.000000001<k1))
			{	
				if(0.0<px)
				{
					x_bond = 4*pi*sqrt(3.0)/(3.0*(k1+sqrt(3.0)));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						K_num++;
					}
				}
				if(px<0.0)
				{
					x_bond = -4*pi*sqrt(3.0)/(3.0*(k1+sqrt(3.0)));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						K_num++;
					}
				}
			}
			if((k1<-sqrt(3.0)-0.000000001)||(sqrt(3.0)-0.000000001<k1))
			{
				if(0.0<py)
				{
					x_bond = 2*pi*sqrt(3.0)/(3.0*k1);
					y_bond = 2*sqrt(3.0)*pi/3.0;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						K_num++;
					}
				}
				if(py<0.0)
				{
					x_bond = -2*pi*sqrt(3.0)/(3.0*k1);
					y_bond = -2*sqrt(3.0)*pi/3.0;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						K_num++;
					}
				}
				
			}
			if((k1<-0.000000001)&&(-sqrt(3.0)-0.000000001<k1))
			{
				if(0.0<py)
				{
					x_bond = 4*pi*sqrt(3.0)/(3.0*(k1-sqrt(3.0)));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						K_num++;
					}
				}
				if(py<0.0)
				{
					x_bond = 4*pi*sqrt(3.0)/(3.0*(sqrt(3.0)-k1));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						K_num++;
					}
				}
			}
		
		}
	}

	if(Kq==NULL)
	{
		Kq = (double **)malloc(2*K_num*sizeof(double));
		for(i=0;i<K_num;i++)
		{
			Kq[i] = (double *)malloc(2*sizeof(double));
		}
	}else{
		printf("init the K-space error!!\n");
	}
	count = 0;
	for(i=0;i<=dim_x;i++)
	{
		for(j=0;j<=dim_y;j++)
		{
			px = i*B1x + j*B2x;
			py = i*B1y + j*B2y;
			if(fabs(px) < 0.00000000001)
			{
				ds = px*px + py*py;
				if(ds<(4*pi*pi/3.0)+0.0000000001)
				{
					Kq[count][0] = 0.0;
					Kq[count][1] = py;
					count++;
				}
				continue;
			}
			k1 = py/px;
			if((k1<sqrt(3.0)-0.000000001)&&(-0.000000001<k1))
			{	
				if(0.0<px)
				{
					x_bond = 4*pi*sqrt(3.0)/(3.0*(k1+sqrt(3.0)));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						Kq[count][0] = px;
						Kq[count][1] = py;
						count++;
					}
				}
				if(px<0.0)
				{
					x_bond = -4*pi*sqrt(3.0)/(3.0*(k1+sqrt(3.0)));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						Kq[count][0] = px;
						Kq[count][1] = py;
						count++;
					}
				}
			}
			if((k1<-sqrt(3.0)-0.000000001)||(sqrt(3.0)-0.000000001<k1))
			{
				if(0.0<py)
				{
					x_bond = 2*pi*sqrt(3.0)/(3.0*k1);
					y_bond = 2*sqrt(3.0)*pi/3.0;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						Kq[count][0] = px;
						Kq[count][1] = py;
						count++;
					}
				}
				if(py<0.0)
				{
					x_bond = -2*pi*sqrt(3.0)/(3.0*k1);
					y_bond = -2*sqrt(3.0)*pi/3.0;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						Kq[count][0] = px;
						Kq[count][1] = py;
						count++;
					}
				}
				
			}
			if((k1<-0.000000001)&&(-sqrt(3.0)-0.000000001<k1))
			{
				if(0.0<py)
				{
					x_bond = 4*pi*sqrt(3.0)/(3.0*(k1-sqrt(3.0)));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						Kq[count][0] = px;
						Kq[count][1] = py;
						count++;
					}
				}
				if(py<0.0)
				{
					x_bond = 4*pi*sqrt(3.0)/(3.0*(sqrt(3.0)-k1));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						Kq[count][0] = px;
						Kq[count][1] = py;
						count++;
					}
				}
			}
		}
	}
	for(i=0;i<=dim_x;i++)
	{
		for(j=0;j<=dim_y;j++)
		{
			px = i*B1x - j*B2x;
			py = i*B1y - j*B2y;
			k1 = py/px;
			if(fabs(px) < 0.00000000001)
			{
				ds = px*px + py*py;
				if(ds<(4*pi*pi/3.0)+0.0000000001)
				{
					Kq[count][0] = 0.0;
					Kq[count][1] = py;
					count++;
				}
				continue;
			}
			k1 = py/px;
			if((k1<sqrt(3.0)-0.000000001)&&(-0.000000001<k1))
			{	
				if(0.0<px)
				{
					x_bond = 4*pi*sqrt(3.0)/(3.0*(k1+sqrt(3.0)));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						Kq[count][0] = px;
						Kq[count][1] = py;
						count++;
					}
				}
				if(px<0.0)
				{
					x_bond = -4*pi*sqrt(3.0)/(3.0*(k1+sqrt(3.0)));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						Kq[count][0] = px;
						Kq[count][1] = py;
						count++;
					}
				}
			}
			if((k1<-sqrt(3.0)-0.000000001)||(sqrt(3.0)-0.000000001<k1))
			{
				if(0.0<py)
				{
					x_bond = 2*pi*sqrt(3.0)/(3.0*k1);
					y_bond = 2*sqrt(3.0)*pi/3.0;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						Kq[count][0] = px;
						Kq[count][1] = py;
						count++;
					}
				}
				if(py<0.0)
				{
					x_bond = -2*pi*sqrt(3.0)/(3.0*k1);
					y_bond = -2*sqrt(3.0)*pi/3.0;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						Kq[count][0] = px;
						Kq[count][1] = py;
						count++;
					}
				}
				
			}
			if((k1<-0.000000001)&&(-sqrt(3.0)-0.000000001<k1))
			{
				if(0.0<py)
				{
					x_bond = 4*pi*sqrt(3.0)/(3.0*(k1-sqrt(3.0)));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						Kq[count][0] = px;
						Kq[count][1] = py;
						count++;
					}
				}
				if(py<0.0)
				{
					x_bond = 4*pi*sqrt(3.0)/(3.0*(sqrt(3.0)-k1));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						Kq[count][0] = px;
						Kq[count][1] = py;
						count++;
					}
				}
			}

		}
	}
	for(i=0;i<=dim_x;i++)
	{
		for(j=0;j<=dim_y;j++)
		{
			px = -i*B1x + j*B2x;
			py = -i*B1y + j*B2y;
			k1 = py/px;
			if(fabs(px) < 0.00000000001)
			{
				ds = px*px + py*py;
				if(ds<(4*pi*pi/3.0)+0.0000000001)
				{
					Kq[count][0] = 0.0;
					Kq[count][1] = py;
					count++;
				}
				continue;
			}
			k1 = py/px;
			if((k1<sqrt(3.0)-0.000000001)&&(-0.000000001<k1))
			{	
				if(0.0<px)
				{
					x_bond = 4*pi*sqrt(3.0)/(3.0*(k1+sqrt(3.0)));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						Kq[count][0] = px;
						Kq[count][1] = py;
						count++;
					}
				}
				if(px<0.0)
				{
					x_bond = -4*pi*sqrt(3.0)/(3.0*(k1+sqrt(3.0)));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						Kq[count][0] = px;
						Kq[count][1] = py;
						count++;
					}
				}
			}
			if((k1<-sqrt(3.0)-0.000000001)||(sqrt(3.0)-0.000000001<k1))
			{
				if(0.0<py)
				{
					x_bond = 2*pi*sqrt(3.0)/(3.0*k1);
					y_bond = 2*sqrt(3.0)*pi/3.0;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						Kq[count][0] = px;
						Kq[count][1] = py;
						count++;
					}
				}
				if(py<0.0)
				{
					x_bond = -2*pi*sqrt(3.0)/(3.0*k1);
					y_bond = -2*sqrt(3.0)*pi/3.0;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						Kq[count][0] = px;
						Kq[count][1] = py;
						count++;
					}
				}
				
			}
			if((k1<-0.000000001)&&(-sqrt(3.0)-0.000000001<k1))
			{
				if(0.0<py)
				{
					x_bond = 4*pi*sqrt(3.0)/(3.0*(k1-sqrt(3.0)));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						Kq[count][0] = px;
						Kq[count][1] = py;
						count++;
					}
				}
				if(py<0.0)
				{
					x_bond = 4*pi*sqrt(3.0)/(3.0*(sqrt(3.0)-k1));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						Kq[count][0] = px;
						Kq[count][1] = py;
						count++;
					}
				}
			}

			
		}
	}
	for(i=0;i<=dim_x;i++)
	{
		for(j=0;j<=dim_y;j++)
		{
			px = -i*B1x - j*B2x;
			py = -i*B1y - j*B2y;
			k1 = py/px;
			if(fabs(px) < 0.00000000001)
			{
				ds = px*px + py*py;
				if(ds<(4*pi*pi/3.0)+0.0000000001)
				{
					Kq[count][0] = 0.0;
					Kq[count][1] = py;
					count++;
				}
				continue;
			}
			k1 = py/px;
			if((k1<sqrt(3.0)-0.000000001)&&(-0.000000001<k1))
			{	
				if(0.0<px)
				{
					x_bond = 4*pi*sqrt(3.0)/(3.0*(k1+sqrt(3.0)));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						Kq[count][0] = px;
						Kq[count][1] = py;
						count++;
					}
				}
				if(px<0.0)
				{
					x_bond = -4*pi*sqrt(3.0)/(3.0*(k1+sqrt(3.0)));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						Kq[count][0] = px;
						Kq[count][1] = py;
						count++;
					}
				}
			}
			if((k1<-sqrt(3.0)-0.000000001)||(sqrt(3.0)-0.000000001<k1))
			{
				if(0.0<py)
				{
					x_bond = 2*pi*sqrt(3.0)/(3.0*k1);
					y_bond = 2*sqrt(3.0)*pi/3.0;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						Kq[count][0] = px;
						Kq[count][1] = py;
						count++;
					}
				}
				if(py<0.0)
				{
					x_bond = -2*pi*sqrt(3.0)/(3.0*k1);
					y_bond = -2*sqrt(3.0)*pi/3.0;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						Kq[count][0] = px;
						Kq[count][1] = py;
						count++;
					}
				}
				
			}
			if((k1<-0.000000001)&&(-sqrt(3.0)-0.000000001<k1))
			{
				if(0.0<py)
				{
					x_bond = 4*pi*sqrt(3.0)/(3.0*(k1-sqrt(3.0)));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						Kq[count][0] = px;
						Kq[count][1] = py;
						count++;
					}
				}
				if(py<0.0)
				{
					x_bond = 4*pi*sqrt(3.0)/(3.0*(sqrt(3.0)-k1));
					y_bond = k1*x_bond;
					dis = x_bond*x_bond + y_bond*y_bond + 0.00000000001;
					ds = px*px + py*py;
					if(ds<dis)
					{
						Kq[count][0] = px;
						Kq[count][1] = py;
						count++;
					}
				}
			}
		
		}
	}
	printf("%s%d%s","the K_num is:",K_num,"\n");
	if(FMatrix==NULL)
	{
		FMatrix = (double ***)malloc(3*K_num*sizeof(double));
		for(i=0;i<K_num;i++)
		{
			FMatrix[i] = (double **)malloc(2*Nsite*sizeof(double));
			for(j=0;j<Nsite;j++)
			{
				FMatrix[i][j] = (double *)malloc(2*sizeof(double));
			}
		}
	}else{
		printf("the init FMatrix error!!\n");
	}

	for(i=0;i<K_num;i++)
	{
		for(j=0;j<Nsite;j++)
		{
			FMatrix[i][j][0] = cos(Lattice_Cor[j][0]*Kq[i][0] + Lattice_Cor[j][1]*Kq[i][1]);
			FMatrix[i][j][1] = sin(Lattice_Cor[j][0]*Kq[i][0] + Lattice_Cor[j][1]*Kq[i][1]);
		}
	}/*this code used to general F kernal*/
//	for(i=0;i<K_num;i++)
//	{
//		for(j=0;j<Nsite;j++)
//		{
//			if(j%3==0)
//			{
//				p1 = j;
//				p2 = j+1;
//				p3 = j+2;
//			}
//			px = Lattice_Cor[p1][0] + Lattice_Cor[p2][0] + Lattice_Cor[p3][0];
//			px = px/3.0;
//			py = Lattice_Cor[p1][1] + Lattice_Cor[p2][1] + Lattice_Cor[p3][1];
//			py = py/3.0;
//			FMatrix[i][j][0] = cos(px*Kq[i][0] + py*Kq[i][1]);
//			FMatrix[i][j][1] = sin(px*Kq[i][0] + py*Kq[i][1]);
//		}
//	}
	Realf = (double **)malloc(2*K_num*sizeof(double));
	for(i=0;i<K_num;i++)
	{
		Realf[i] = (double *)malloc(2*Nt*sizeof(double));
	}
	Imagf = (double **)malloc(2*K_num*sizeof(double));
	for(i=0;i<K_num;i++)
	{
		Imagf[i] = (double *)malloc(2*Nt*sizeof(double));
	}
	Realfz = (double **)malloc(2*K_num*sizeof(double));
	for(i=0;i<K_num;i++)
	{
		Realfz[i] = (double *)malloc(2*Nt*sizeof(double));
	}
	Imagfz = (double **)malloc(2*K_num*sizeof(double));
	for(i=0;i<K_num;i++)
	{
		Imagfz[i] = (double *)malloc(2*Nt*sizeof(double));
	}
	Correctz_temp = (double **)malloc(2*K_num*sizeof(double));
	for(i=0;i<Nt;i++)
	{
		Correctz_temp[i] = (double *)malloc(Nt*sizeof(double));
	}
}

void Struct_Factor_Kagome(double Q_x, double Q_y, int step)
{
    double pi = 3.14159265358979324;
    double *Imag = (double *)malloc(2*sizeof(double)); /*alloc a two dimension of group to resp the virtual number, which first one element resp real part and sencond part resp the virtual part*/
    Imag[0] = 0.0;
    Imag[1] = 0.0;
    int i, j;
    int *d_ij = (int *)malloc(2*sizeof(int)); /*used to tempeleted the displace between the points i and j, first is x_direction, seconed is y_directed*/
    int tra_posi_x_i, tra_posi_y_i, inner_tra_i, tra_posi_x_j, tra_posi_y_j, inner_tra_j;
    int dim_x, dim_y;
    int spin_i, spin_j;
    dim_x = Dim_x;
    dim_y = Dim_y;
    double Zeta, Struct_factor_real, Struct_factor_imag;
    Struct_factor_imag = 0.0;
    Struct_factor_real = 0.0;
    if(BC==1) /*when the BC==1,the base in the k-space, is cross 120 degree,when BC==2 the bases in the k-space is crossed 90 degree*/
    {
        for(i=0;i<=Nsite-1;i++)
        {
            inner_tra_i = i%3;
            tra_posi_x_i = i/3;
            tra_posi_x_i = tra_posi_x_i%(dim_x);
            tra_posi_y_i = i/3;
            tra_posi_y_i = tra_posi_y_i/(dim_x);
            spin_i = Lattice[i];
            for(j=0;j<=Nsite-1;j++)
            {
                spin_j = Lattice[j];
                inner_tra_j = j%3;
                tra_posi_x_j = j/3;
                tra_posi_x_j = tra_posi_x_j%(dim_x);
                tra_posi_y_j = j/3;
                tra_posi_y_j = tra_posi_y_j/(dim_x);
                if(inner_tra_i==0)
                {
                    if(inner_tra_j==0)
                    {
                        d_ij[0] = (tra_posi_x_i*2 + tra_posi_y_i*2) - (tra_posi_x_j*2 + tra_posi_y_j*2);
                        d_ij[1] = tra_posi_x_j*2 - tra_posi_x_i*2;
                    }
                    if(inner_tra_j==1)
                    {
                        d_ij[0] = (tra_posi_x_i*2 + tra_posi_y_i*2) - (tra_posi_x_j*2 + tra_posi_y_j*2);
                        d_ij[1] = (tra_posi_x_j*2 - 1) - tra_posi_x_i*2;
                    }
                    if(inner_tra_j==2)
                    {
                        d_ij[0] = (tra_posi_x_i*2 + tra_posi_y_i*2) - (tra_posi_x_j*2 + tra_posi_y_j*2 + 1);
                        d_ij[1] = tra_posi_x_j*2 - tra_posi_x_i*2;
                    }
                }

                if(inner_tra_i==1)
                {
                    if(inner_tra_j==0)
                    {
                        d_ij[0] = (tra_posi_x_i*2 + tra_posi_y_i*2) - (tra_posi_x_j*2 + tra_posi_y_j*2);
                        d_ij[1] = tra_posi_x_j*2 - (tra_posi_x_i*2 - 1);
                    }
                    if(inner_tra_j==1)
                    {
                        d_ij[0] = (tra_posi_x_i*2 + tra_posi_y_i*2) - (tra_posi_x_j*2 + tra_posi_y_j*2);
                        d_ij[1] = (tra_posi_x_j*2 - 1) - (tra_posi_x_i*2 - 1);
                    }
                    if(inner_tra_j==2)
                    {
                        d_ij[0] = (tra_posi_x_i*2 + tra_posi_y_i*2) - (tra_posi_x_j*2 + tra_posi_y_j*2 + 1);
                        d_ij[1] = tra_posi_x_j*2 - (tra_posi_x_i*2 - 1);
                    }
                }

                if(inner_tra_i==2)
                {
                    if(inner_tra_j==0)
                    {
                        d_ij[0] = (tra_posi_x_i*2 + tra_posi_y_i*2 + 1) - (tra_posi_x_j*2 + tra_posi_y_j*2);
                        d_ij[1] = tra_posi_x_j*2 - tra_posi_x_i*2;
                    }
                    if(inner_tra_j==1)
                    {
                        d_ij[0] = (tra_posi_x_i*2 + tra_posi_y_i*2 + 1) - (tra_posi_x_j*2 + tra_posi_y_j*2);
                        d_ij[1] = (tra_posi_x_j*2 - 1) - tra_posi_x_i*2;
                    }
                    if(inner_tra_j==2)
                    {
                        d_ij[0] = (tra_posi_x_i*2 + tra_posi_y_i*2 + 1) - (tra_posi_x_j*2 + tra_posi_y_j*2 + 1);
                        d_ij[1] = tra_posi_x_j*2 - tra_posi_x_i*2;
                    }
                }
                Zeta = cos(pi/6)*Q_x*((double)(d_ij[0]) + 0.5*(double)(d_ij[1])) + (Q_y + 0.5*Q_x)*(double)(d_ij[1])*cos(pi/6);
                Imag[0] = cos(Zeta);
                Imag[1] = -sin(Zeta);
                Struct_factor_real = Struct_factor_real + spin_i*spin_j*Imag[0];
                Struct_factor_imag = Struct_factor_imag + spin_i*spin_j*Imag[1];
            }
        }
        if(fabs(Struct_factor_imag)<0.00000000001)
        {
            Ob.struct_factor[step] = Struct_factor_real/((double)(Nsite*Nsite));
        }else{
            printf("error! the structure factor must be a real number");
            printf("\n");
            printf("%lf",Struct_factor_imag);
            printf("\n");
        }
    }else{

    }
}



void Correct_Szz(void)
{
        int i, j, k;
        double tao;
	int t1, t2;
	int vert, I, r;
	int posi,l;
	int *spin = (int  *)malloc(Nsite*sizeof(int));
	for(i=0;i<Nsite;i++)
	{
		spin[i] = Lattice[i];
	}
	for(i=0;i<K_num;i++)
	{
		for(j=0;j<2*Nt;j++)
		{
			Realf[i][j] = 0.0;
			Imagf[i][j] = 0.0;
		}
	}
	double **temp = (double **)malloc(2*K_num*sizeof(double));
	for(i=0;i<K_num;i++)
	{
		temp[i] = (double *)malloc(Nt*sizeof(double));
	}
	for(i=0;i<K_num;i++)
	{
		for(j=0;j<Nt;j++)
		{
			temp[i][j] = 0.0;
		}
	}
	for(i=0;i<2*Nt;i++)
	{
		for(j=0;j<K_num;j++)
		{
			for(k=0;k<Nsite;k++)
			{
				Realf[j][i] = Realf[j][i] + (double)(spin[k])*FMatrix[j][k][0];
				Imagf[j][i] = Imagf[j][i] + (double)(spin[k])*FMatrix[j][k][1];
			}
		}	
		for(j=0;j<Ms;j++)
		{
			t1 = i*Ms + j;
			I = Opstring[t1][0];
			if(1<I)
			{
				vert = Opstring[t1][1];
				r = Opstring[t1][2];
				for(k=0;k<Vert_Size;k++)
				{
					posi = Bsite[r][k];
					spin[posi] = Vertex_Leg[1][vert*Vert_Size + k];
				}
			}
		}
	}
	for(i=0;i<K_num;i++)
	{
		for(j=0;j<2*Nt;j++)
		{
			t1 = j;
			for(k=0;k<Nt;k++)
			{
				t2 = t1 + k;
				if((2*Nt)<=t2)
				{
					t2 = t2%(2*Nt);
				}
				temp[i][k] = temp[i][k] + Realf[i][t1]*Realf[i][t2] + Imagf[i][t1]*Imagf[i][t2];		
			}
		}
	}
	for(i=0;i<K_num;i++)
	{
		for(j=0;j<Nt;j++)
		{
			Ob.Correct_Virtu_Time[paraenv][i][j] = Ob.Correct_Virtu_Time[paraenv][i][j] + temp[i][j]/((double)(2*Nt*Nsite));
		}
	}
	for(i=0;i<Nsite;i++)
	{
		Lattice_Spin[paraenv][i] = Lattice_Spin[paraenv][i] + (double)(Lattice[i]);
	}
	if(spin!=NULL)
	{
		free(spin);
		spin = NULL;
	}
	if(temp!=NULL)
	{
		for(i=0;i<K_num;i++)
		{
			if(temp[i]!=NULL)
			{
				free(temp[i]);
				temp[i] = NULL;
			}
		}
		free(temp);
		temp = NULL;
	}
}

void Correct_rho(void)
{
	int i, j, k;
        double tao, s;
	int t1, t2;
	int vert, I, r;
	int posi,l;
	int *spin = (int  *)malloc(Nsite*sizeof(int));
	double dspin;
	for(i=0;i<Nsite;i++)
	{
		spin[i] = Lattice[i];
	}
	for(i=0;i<K_num;i++)
	{
		for(j=0;j<2*Nt;j++)
		{
			Realfz[i][j] = 0.0;
			Imagfz[i][j] = 0.0;
		}
	}

	for(i=0;i<K_num;i++)
	{
		for(j=0;j<Nt;j++)
		{
			Correctz_temp[i][j] = 0.0;
		}
	}
	for(i=0;i<2*Nt;i++)
	{
		for(j=0;j<K_num;j++)
		{
			for(k=0;k<Nsite;k++)
			{
				if(k%3==0)
				{
					dspin = (double)(spin[k])+(double)(spin[k+1])+(double)(spin[k+2]);
					dspin =dspin/3.0;
				}
				Realfz[j][i] = Realfz[j][i] + dspin*FMatrix[j][k][0];
				Imagfz[j][i] = Imagfz[j][i] + dspin*FMatrix[j][k][1];
			}
			Realfz[j][i] = Realfz[j][i]/3.0;
			Imagfz[j][i] = Imagfz[j][i]/3.0;
		}	
		for(j=0;j<Ms;j++)
		{
			t1 = i*Ms + j;
			I = Opstring[t1][0];
			if(1<I)
			{
				vert = Opstring[t1][1];
				r = Opstring[t1][2];
				for(k=0;k<Vert_Size;k++)
				{
					posi = Bsite[r][k];
					spin[posi] = Vertex_Leg[1][vert*Vert_Size + k];
				}
			}
		}
	}
	for(i=0;i<K_num;i++)
	{
		for(j=0;j<2*Nt;j++)
		{
			t1 = j;
			for(k=0;k<Nt;k++)
			{
				t2 = t1 + k;
				if((2*Nt)<=t2)
				{
					t2 = t2%(2*Nt);
				}
				Correctz_temp[i][k] = Correctz_temp[i][k] + Realfz[i][t1]*Realfz[i][t2] + Imagfz[i][t1]*Imagfz[i][t2];		
			}
		}
	}
	for(i=0;i<K_num;i++)
	{
		for(j=0;j<Nt;j++)
		{
			Ob.Correct_Rho_Virtu_Time[paraenv][i][j] = Ob.Correct_Rho_Virtu_Time[paraenv][i][j] + Correctz_temp[i][j]/(2*Nt*Nsite);	
		}
	}
	if(spin!=NULL)
	{
		free(spin);
		spin = NULL;
	}
}
int Minium(double *Disp, int dim)
{
	int i;
	int posi=0;
	double temp = Disp[0];
	for(i=1;i<dim;i++)
	{
		if(Disp[i] < temp)
		{
			posi = i;
			temp = Disp[i];
		}
	}
	return posi;
}
