#ifndef _DATASTRUCT_H
#define _DATASTRUCT_H
#include "SFMT.h"
/*+=========================================================================+*/
/*+++++++++controler which used to decided program's basic formation+++++++++*/
/*===========================================================================*/
       extern double Squre2;
       extern double Squre3;
       extern double Pi;
       extern int Break_Switch;/*if 0 no break_backup, if 1 Break backup point after each Backup_point_step nbins all conf will save which used to restart*/
       extern int Detail_Switch;/*if 0 no detail ouput; if 1 output the paremeter used to debug; if 2 only out put final measure results; */
       extern int Temping_Switch;/*if 0 no parall temping, the configuration will not exchange, which parameter will laod decide by alter_contral but envoled independent with on exchange.if 1 the parall temping will enable and the configuration will exchange, and which parameter will be temping dcide by the alter_contal*/
       extern int Interrupt_Switch;/*if 0, there no interrupt;if 1 when thermal equlilibrium end, the conf will saved and program will self-terminate;if 2 conf will saved after each bins to override the older file; if 3 saved conf will start after thermal equailib;*/
       extern int Restart_Switch;/*if 0, pragram normal excute; if not be 0, program will found conf file to try restart; if Restart_Switch==Interrupt_Switch, program will restart as interrupt point;if  Restart_Switch!=Interrupt_Switch;*/
       extern int Rebalance_Switch; /*if 0, pragram restart with no rebalance which to reduce auto-correction time, if > 0, is the rebalance steps after restart*/
       extern int Istep, Mstep, Boost_trap, Nbin, Backup_point_step, sweep,sweep_measure;
       extern int wrap_type;
       extern int swap_times;
/*+=========================================================================+*/
/*+++++++controler which used to decided program's basic formation end+++++++*/
/*===========================================================================*/
/******************************************************************************************************/
/******************************************************************************************************/
/******************************************************************************************************/


/*+=========================================================================+*/
/*++++++++++++++++++++++++++++++++MPI parameter++++++++++++++++++++++++++++++*/
/*===========================================================================*/

       extern int my_rank;
       extern int process_numb;
       extern int source, dest;
       extern int paraenv;
       extern int alter_contral;  /*this to ensure which kinds of temping parameter will be choose, if 0 no temping,program will be single core running*/
        /*if 1 temperature beta is be temping, if 2, hopping t is be temping. if 3 the couping strength V is be temping, if 4 the chemical poentation miu is temping, if >4 temping parameter will defined by user*/
       extern double EPS, MAXREAL, RHO;
       extern double *Exchange_Prob; /*exchange conf i and conf j 's prob*/
       extern int **Exchange_Time;
 //      extern int **record_tconf;
 //      extern int **record_pconf;
       extern int *pararec;
       extern int *tpararec;

       extern unsigned int Ph_ran64;
       extern sfmt_t Ph_sfmt;
/*+=========================================================================+*/
/*+++++++++++++++++++++++++MPI parameter end+++++++++++++++++++++++++++++++++*/
/*===========================================================================*/
/******************************************************************************************************/
/******************************************************************************************************/
/******************************************************************************************************/



/*+=========================================================================+*/
/*++++++++++++++++++++++++++++++++Hamiliton++++++++++++++++++++++++++++++++++*/
/*===========================================================================*/

/*H=-t0(bi^+*bj+bi*bj^+)+v0(ni*nj) + v1(ni*nj) ....-mu0*ni*/
/*if Spin_Bose_Switch==0*/
/*mos=1 only!! define by program own, input will be no useful*/
/*if Spin_Bose_Switch==*/
/*mos=input will be no used*/
/*if Paral_Switch==0 or 1; t0,v0, and mu0 will be a single value*/
/*if Paral_Switch==2; t0,v0, mu0 and Beta will be Vector as length of processnumber*/

/*ALL THOSE PARAMETER WILL GET BY INPUT SCRIPT*/

/*+=========================================================================+*/
/*+++++++++++++++++++++++++++Hamiliton end+++++++++++++++++++++++++++++++++++*/
/*===========================================================================*/

/******************************************************************************************************/
/******************************************************************************************************/
/******************************************************************************************************/





/*+=========================================================================+*/
/*++++++++++++++++the lattice structure setting parameter++++++++++++++++++++*/
/*===========================================================================*/
       extern int Total_step;
       extern int Dim; /*system dimension*/
       extern int Dim_x, Dim_y, Dim_z, L1, L2; /*the lattce x, y, z sizes*/
       extern int Nsite;  /*total number of sites in lattice system*/
       extern int Nbond;  /*total number of bounds in lattice system*/
       extern int Lattice_Sharpe; /*this is to sure the sharpe of lattice, for 1 dimension lattice*/
        /*for 2dimsension lattice, 0 is square lattice, 1 is trangle lattice, 2 is kagome lattice*/
       extern int Bond_Size; /*the bond size which decide, program setting is 2*/
       extern int *Max_Site_Occp;/*the maxium occuptication in each size in every type size*/
       extern int *Mosp; /*used to conversion Max_Site_Occp to Dec*/
       extern int *Lattice; /*store the spin or occup at ith lattice*/
       extern int **Bsite; /*store the bond's mapping to Lattice's coordinate*/
       extern int **Trangle;/*used to fast find the lattice points which get the lattice point's spin*/
       extern int BC; /*for kagome lattice, two kind of boundry should be chosed 0 is */
       extern int Mos;
       extern double *energy_shift;
       extern double shift;
       extern double Rescal; /*this is the Rescale the virtual time when calc the green*/
       extern double ***GF0;
       extern double ***GF1;
       extern double ***Lpds0; /*record the S^- operator head's moving path length*/
       extern double ***Lpds1;/*record the S^+ operator head's moving path lengtg*/
       extern double **Lattice_Spin;
       extern int *Tmgf; /*stored the 'flag' in virtual time, according this to counting*/
       extern int *Tid;
       extern int *Nid;
       extern int *Optm;/*define the data structure for the  green-function calculation*/
       extern int *Nhstring;
       extern int Nt; /*the number of samples in the virtual time's direction*/
       extern int Tmmx; /*the layer number of the virtual or the length of Opstring after rescale*/
       extern int Total_N;
       extern int K_num;
       extern double **Lattice_Cor;/*the coordinate in real space's coordinate was stored*/ 
       extern int Ms; /*this is the number of slice according the one specify*/
       extern double *Nl; /*Total loop Wight in difference parameter env*/
       extern double *Tm;
       extern double ***FMatrix;/*store the karnal of Fourier transformate*/
       extern double **Kq;/*store the k-space coordinate,Kq[i][0] = Kix,Kq[i][1] = kiy*/
       extern double **Realf;
       extern double **Imagf;
       extern double **Realfz;/*stored the real part of rho-rho correction's transform kern*/
       extern double **Imagfz;/*stored thr imag part of rho-rho correction's transform kern*/
       extern double **Correctz_temp;/*temp buffer,used to reduce alloc memeroy times in rho-rho corection*/
  	
		

typedef struct Trangle_Bond
{
    int Bond_numb;
    int Site_numb;
    int **Tsite; /*store the trangle bond's postion resprensed by postion in bsite*/
    int **Trangle2Bsite;/*stored bond postion information by lattice*/
    double repead_t0, repead_v0, repead_miu0;
} Bond_3;

typedef struct Square_Bond
{
    int Bond_numb;
    int Site_numb;
    int **Ssite;
    int **Square2Bsite;
    double repead_t0, repead_v0, repead_miu0;
} Bond_4;

typedef struct Alpha_Bond /*"A" structure type bond which used in kagome lattice*/
{
    int Bond_numb;
    int Site_numb;
    int **Asite;
    int **Alpha2Bsite;
    double repead_t0, repead_v0, repead_miu0;
} Bond_5;

typedef struct Hex_Bond /*the HEX type bond could used in kagome lattice*/
{
    int Bond_numb;
    int Site_numb;
    int **Hbsite;
    int **Hex2Bsite;
    double repead_t0, repead_v0, repead_miu0;
} Bond_6;

typedef struct N_Bond
{
    int Bond_numb;
    int Site_numb;
    int **Nbsite;
    int **Nbsite2Bsite;
    double repead_t0, repead_v0, repead_miu0;
} Bond_n;


extern int *hopping1; /*stored all hopping point*/
extern int *hopping2; /*stored all hopping point*/
extern int *hopping_N1;
extern int *hopping_N2;

/*+=========================================================================+*/
/*++++++++++++++the lattice structure setting parameter end++++++++++++++++++*/
/*===========================================================================*/
/******************************************************************************************************/
/******************************************************************************************************/
/******************************************************************************************************/



/*+=========================================================================+*/
/*+++++++++++++++++++++++Vertex Table and Maping+++++++++++++++++++++++++++++*/
/*===========================================================================*/
/******************************************************************************************************/
/******************************************************************************************************/
/******************************************************************************************************/


    extern double **Wight; /*each threads have same wight,which wight(i,j) indicede jth vertex's wight under ith's temping parameter*/
    extern double ***GTM; /*each thread have same transform prob matrix, TM[i][j][k] means under ith's temping parameter, trans the vertx-conf i to j's prob */
    /*i = before_vertex_indx X leg_num + in_leg  */
    extern int ***GLEG_MAP;

    extern int *Vertex_Type; /*Vertex[i] is ith operator's type, and if 1 is diagonal operator, gt 1 is off diagonal operator*/
    extern int **Vertex_Leg; /*Vertex_leg[0][i*sizeClus:i*sizeClus + sizeClus-1] stored the ith(vertex_index i) operator's right(before)legs occupt,Vertex_leg[1][i*sizeClus:i*sizeClus + sizeClus-1] stored the ith operator's lift(after)legs occupt*/
    extern int **Vertex_Sum; /*Vert_sum[i][0] stored the ith operator's right(before operation)leg's conf as Dec number*/
    /*Vert_sum[i][1] stored the ith operator's lift(after operation)leg's conf as Dec number*/
    extern int nh; /*the no-zero opertor's number in operator's string which lying in virtual time, must init at each sub-threads begain*/
    extern int **Opstring;/*operator's string,length is MM,opstring[i][0] is vertex type: if -1 means no operator at i th virtual slice, if 1 is diagonal operator, other's is off-diagonal operators. opstring[i][1] is vertex_index,opstring[i][i] is the bond_index*/
    extern int MM; /*the initied length of the virtual time sequence, which will be growth!!*/
    extern int Ms;/*the length of each virtual slice, all slices with same Ms*/
    extern int *Link_Table;
    extern int *Wind_Mapping;
    extern int Clust_Type;/* if 1: is usual setting, the cluster size is 2 BondSize is 2. if 3: the bondsize is 3, Vexter sharpe is trangle, if 4 is square vertex, Bondsize is 4, if 5 is A sharpe*/
    /* vertex and bondsize is 5, if 6 is Hex sharpe vertex, bondsize is 6, if gt 6, self define the sharpe of vertex*/
    extern int Vert_Size;
    extern int N_Size;
    extern int VertNumb;
    extern int Max_Size; /*the dimension of the Vertex_Leg, equal to leg_numb*vertex_numb*/
    extern double *T; /*T[i] stored hopping parameter, the length of T equal to process number,temping parameter is T*/
    extern double *V; /*V[i] stored coupling constant, the length of V equal to process number,temping parameter is V*/
    extern double *V_N;
    extern double *Miu; /*Miu[i] stored coupling constant, the length of Miu equal to process number,temping parameter is Miu*/
    extern double *Miu1;
    extern double *Miu2;
    extern double *Beta; /*Beta[i] stored the beta = 1/KT, the length of Beta equal to process number, temping parameter is Beta*/

/*+=========================================================================+*/
/*++++++++++++++++++++++Vertex Table and Maping++++++++++++++++++++++++++++++*/
/*===========================================================================*/
/******************************************************************************************************/
/******************************************************************************************************/
/******************************************************s************************************************/

typedef struct Store_Link
{

    int first;
    int last;

} Link;


typedef struct ObserveVables
{
    double *energy;       /*measure energy */
    double *energy1;       /*measure error bar and RMS of energy between measure energy*/
    double energy3;       /*used to menasure energy in themrmaliztion step to sure the the energy converged!!*/
    double *energy_ken;
    double MagMoment1;
    double MagMoment2;
    double Capacity1;
    double Capacity2;
    double reach_rato;   /*++++++off-diagonal used to record the system++++++*/
    double data1[7];
    double data2[7];
    double Winding_Averg1;
    double *Wind;
    double *Mag;
    double *Mag_sq;
    double *Sf;
    double Winding_Averg2;
    double *struct_factor;
    double *Correct_ob;
    double *Correct_ob1;
    double **Dens_Latti_Site; /*used to store hard-core bosn in sub-lattice site in each lattice site*/
    double ***Correct_Virtu_Time;
    double ***Correct_Rho_Virtu_Time;
    double **Correction_2D;
    double **correct_2d_temp;
    double **trac;
    int *Loop_vert_class;
    int **virtual_time_dis_count;
    double ***trac2d;
    int *loop_length_counter;
    long int *length_vs_counter;
    int *loop_num_count;
    double *loop_avg_length_mpi; /*used to recoed the average loop_length in each temping parameter*/
    long int virt_time_length;
    int diag_oper, off_oper;
    int diag_trs_off, off_trs_diag;
    int large_loop_numb;
    long int off_diag_number, diag_number;
    //double energy_bais; /*store the auto-correction time of system energy's error bar!*/
} OV;

typedef struct Meansure_Temp{
    int Cycle;
    int pointer1;    //used to point the energy_store_arry!
    int pointer2;    //used to point the Magment_store_arry!
    int pointer3;
    int pointer4;
    int pointer5;
    int Limit;
    double *Store_arry1;  /*used to store the energy data in the energy_store_arry*/
    double *Store_arry2;  /*used to store the energy data in the Magnetmoment store_arry*/
    double *Store_arry3;  /*used to store the energy data in the Winding number store_arry*/
    double *Store_arry4;  /*used to store space correction function Sz_i*Sz_j*/
} MT;


extern Link *FLAGE;

extern OV Ob;

extern Bond_3 Bsite3;

extern Bond_4 Bsite4;

extern Bond_5 Bsite5;

extern Bond_6 Bsite6;

extern double *Meansure_Temp1;

extern double *Meansure_Temp2;

extern MT M_arry;

/*measure green function used !!*/
extern double *tm;

extern double **gf;

extern double **lpds;

extern int *tmgf;

extern int *tid;

extern int *nid;

extern int *optm;

extern int **Lattice_Map;

extern double  **choose_porb;

extern int *trans_vertex;

extern int *segment;

extern int *segment_sum;

extern unsigned int STATE[1391];

extern unsigned int state_i;

#endif
