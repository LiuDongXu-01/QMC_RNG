#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>
#include "datastruct.h"
#include "myfunction.h"



void makelattice(int dim,int dim_x,int dim_y,int dim_z,int clust_type,int BC)
{
    int i, j, k;
    int x1, y1, z1, posi;
    int temp, temp1, temp2, trangle_posi, trangle_posi1, trangle_posi2;
    int hex_posi, hex_posi1, hex_posi2;
    int bond_numb, site_numb;
    int shift1;
    if(dim==1)
    {
        Nsite = dim_x;
        Nbond = Nsite;
        Vert_Size = 2;
	Clust_Type = 2;
        Bsite = (int **)malloc(2*Nbond*sizeof(int));
        for(i=0;i<=Nbond-1;i++)
        {
            Bsite[i] = (int *)malloc(Vert_Size*sizeof(int));
        }
        for(x1=0;x1<=dim_x-1;x1++)
        {
            for(i=0;i<=1;i++)
            {
                Bsite[x1][i] = (x1+i)%dim_x;
            }
        }
        hopping1 = (int *)malloc(Vert_Size*sizeof(int));
        hopping2 = (int *)malloc(Vert_Size*sizeof(int));

        hopping1[0] = 0;
        hopping1[1] = 1;
        hopping2[0] = 1;
        hopping2[1] = 0;
    }

    if(dim==2)
    {
        if(Lattice_Sharpe==0) /*square lattice*/
        {
            Nsite = dim_x*dim_y;
            Nbond = 2*Nsite;
            Bsite = (int **)malloc(2*Nbond*sizeof(int));
            Vert_Size = 2;
	    Clust_Type = 2;
            for(i=0;i<=Nbond-1;i++)
            {
                Bsite[i] = (int *)malloc(Vert_Size*sizeof(int));
            }

            for(y1=0;y1<=dim_y-1;y1++)
			{
				for(x1=0;x1<=dim_x-1;x1++)
				{
					temp = x1 + y1*dim_x;
					for(i=0;i<=1;i++)
					{
						Bsite[temp][i] = (x1 + i)%dim_x + y1 * dim_x;
                        Bsite[temp+Nsite][i] = x1 + ((y1+i)%dim_y)*dim_x;
					}
				}
			}
			hopping1 = (int *)malloc(Vert_Size*sizeof(int));
			hopping2 = (int *)malloc(Vert_Size*sizeof(int));
            hopping1[0] = 0;
            hopping1[1] = 1;
            hopping2[0] = 1;
            hopping2[1] = 0;
        }
    }
   

    Lattice = (int *)malloc(Nsite*sizeof(int));
    for(i=0;i<=Nsite-1;i++)
    {
        Lattice[i] = Min(Mos,(int)(Random()*((double)(Mos+1))));
    }

	/*following code is used to get each points position of cluster in the kagome lattice */
    	/*if the lattice changed, please change those code*/
    L1 = dim_x*dim_y;
    L2 = 2*L1;
    int tra, tra1;
    Trangle = (int **)malloc(2*L2*sizeof(int));
    for(i=0;i<L2;i++)
    {
	    Trangle[i] = (int *)malloc(3*sizeof(int));
    }
    for(i=0;i<dim_y;i++)
    {
	    for(j=0;j<dim_x;j++)
	    {
		    tra = i*dim_x+j;
                    Trangle[tra][0] = 3*tra;
                    Trangle[tra][1] = Trangle[tra][0] + 1;
                    Trangle[tra][2] = Trangle[tra][0] + 2;
                    tra1 = tra + L1;
                    Trangle[tra1][0] = Trangle[tra][2];
                    Trangle[tra1][1] = 3*(i*dim_x+((j+1)%dim_x)) + 1;
                    Trangle[tra1][2] = 3*(((i+1)%dim_y)*dim_x + j);
            }
    }
}
