#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <malloc.h>
#include "datastruct.h"
#include "myfunction.h"




       double Squre2 = 1.414213562373095048801689;
       double Squre3 = 1.732050807568877293527446;
       double Pi = 3.1415926535897932384626433832795;
       int Detail_Switch;/*if 0 no detail ouput; if 1 output the paremeter used to debug; if 2 only out put final measure results; */
       int Temping_Switch;
       int Interrupt_Switch;
       int Restart_Switch;
       int Rebalance_Switch;
       int Istep, Mstep, Boost_trap, Nbin, Backup_point_step, sweep,sweep_measure;
       int wrap_type;
       int swap_times;
       int Total_step;
       int my_rank;
       int process_numb;
       int source, dest;
       int paraenv;
       int alter_contral;  /*this to ensure which kinds of temping parameter will be choose, if 0 no temping,program will be single core running*/
        /*if 1 temperature beta is be temping, if 2, hopping t is be temping. if 3 the couping strength V is be temping, if 4 the chemical poentation miu is temping, if >4 temping parameter will defined by user*/
       double EPS = 1.0e-200;
       double MAXREAL = 1.0e200;
       double *Exchange_Prob; /*exchange conf i and conf j 's prob*/
       int **Exchange_Time;
       int *pararec;
       int *tpararec;

 //      int **record_tconf = NULL;
 //      int **record_pconf = NULL;

       unsigned int Ph_ran64;
       sfmt_t Ph_sfmt;

/*+=========================================================================+*/
/*++++++++++++++++the lattice structure setting parameter++++++++++++++++++++*/
/*===========================================================================*/

       int Dim; /*system dimension*/
       int Dim_x, Dim_y, Dim_z, L1, L2; /*the lattce x, y, z sizes*/
       int Nsite;  /*total number of sites in lattice system*/
       int Nbond;  /*total number of bounds in lattice system*/
       int Lattice_Sharpe; /*this is to sure the sharpe of lattice, for 1 dimension lattice*/
        /*for 2dimsension lattice, 0 is square lattice, 1 is trangle lattice, 2 is kagome lattice*/
       int Bond_Size; /*the bond size which decide, program setting is 2*/
       int *Max_Site_Occp = NULL;/*the maxium occuptication in each size in every type size*/
       int *Mosp = NULL; /*used to conversion Max_Site_Occp to Dec*/
       int *Lattice = NULL; /*store the spin or occup at ith lattice*/
       int **Bsite = NULL; /*store the bond's mapping to Lattice's coordinate*/
       int **Trangle = NULL;/*used to fast find the lattice points which get the lattice point's spin*/
       int **Lattice_Map = NULL;
       int BC; /*for kagome lattice, two kind of boundry should be chosed 0 is */
       int Mos;
       int Nt;
	int Total_N;
       double *Nl = NULL;
       int Tmmx;

       double *energy_shift;
       double shift;
       double Rescal;
       double RHO;
       int *Tmgf = NULL;
       int *Tid = NULL;
       int *Nid = NULL;
       int *Optm = NULL;
       double *Tm = NULL;
       double ***GF0 = NULL;
       double ***GF1 = NULL;
       double ***Lpds0 = NULL;
       double ***Lpds1 = NULL;
       int *hopping1 = NULL; /*stored all hopping point*/
       int *hopping2 = NULL; /*stored all hopping point*/
       int *hopping_N1 = NULL;
       int *hopping_N2 = NULL;
       double **Lattice_Cor = NULL;
       double ***FMatrix = NULL;
       double **Kq = NULL;
       double **Realf = NULL;
       double **Imagf = NULL;
       double **Realfz = NULL;
       double **Imagfz = NULL;
       double **Correctz_temp = NULL;
       double **Lattice_Spin = NULL;
       int K_num;
       int Ms;


       double **Wight = NULL; /*each threads have same wight,which wight(i,j) indicede jth vertex's wight under ith's temping parameter*/
       double ***GTM = NULL; /*each thread have same transform prob matrix, TM[i][j][k] means under ith's temping parameter, trans the vertx-conf i to j's prob */
    /*i = before_vertex_indx X leg_num + in_leg  */
       int ***GLEG_MAP = NULL;

       int *Vertex_Type = NULL; /*Vertex[i] is ith operator's type, and if 1 is diagonal operator, gt 1 is off diagonal operator*/
       int **Vertex_Leg = NULL; /*Vertex_leg[0][i*sizeClus:i*sizeClus + sizeClus-1] stored the ith(vertex_index i) operator's right(before)legs occupt,Vertex_leg[1][i*sizeClus:i*sizeClus + sizeClus-1] stored the ith operator's lift(after)legs occupt*/
       int **Vertex_Sum = NULL; /*Vert_sum[i][0] stored the ith operator's right(before operation)leg's conf as Dec number*/
    /*Vert_sum[i][1] stored the ith operator's lift(after operation)leg's conf as Dec number*/
	int nh; /*the no-zero opertor's number in operator's string which lying in virtual time, must init at each sub-threads begain*/
    	int **Opstring = NULL;/*operator's string,length is MM,opstring[i][0] is vertex type: if -1 means no operator at i th virtual slice, if 1 is diagonal operator, other's is off-diagonal operators. opstring[i][1] is vertex_index,opstring[i][i] is the bond_index*/
        int *Nhstring  = NULL;
	int MM; /*the initied length of the virtual time sequence, which will be growth!!*/
    int Ms;
    int *Link_Table = NULL;
    int *Wind_Mapping= NULL;
    int Clust_Type;/* if 1: is usual setting, the cluster size is 2 BondSize is 2. if 3: the bondsize is 3, Vexter sharpe is trangle, if 4 is square vertex, Bondsize is 4, if 5 is A sharpe*/
    /* vertex and bondsize is 5, if 6 is Hex sharpe vertex, bondsize is 6, if gt 6, self define the sharpe of vertex*/
    int Vert_Size;
    int N_Size;
    int VertNumb;
    int Max_Size; /*the dimension of the Vertex_Leg, equal to leg_numb*vertex_numb*/
    double *T = NULL; /*T[i] stored hopping parameter, the length of T equal to process number,temping parameter is T*/
    double *V = NULL; /*V[i] stored coupling constant, the length of V equal to process number,temping parameter is V*/
    double *V_N = NULL;/*store the V1*/
    double *Miu = NULL; /*Miu[i] stored coupling constant, the length of Miu equal to process number,temping parameter is Miu*/
    double *Miu1 = NULL; /*the ping field added in Hex cluster*/
    double *Miu2 = NULL;/*the ping field in Hex cluster*/
    double *Beta = NULL; /*Beta[i] stored the beta = 1/KT, the length of Beta equal to process number, temping parameter is Beta*/

    Link *FLAGE;

    OV Ob;

    Bond_3 Bsite3;
 	
    Bond_4 Bsite4;
    
    Bond_5 Bsite5;

    Bond_6 Bsite6;
    
    unsigned int STATE[1391]; 

    unsigned int state_i = 0; 

