#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>
#include "datastruct.h"
#include "myfunction.h"
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>

double Random(void)
{
        double y,start,stop;
        y = sfmt_genrand_res53(&Ph_sfmt);
    	return y;
}

void init( char *pwd)
{
    int len, sum, i;
    char *pwd_temp = (char *)malloc(1024*sizeof(char));
    strcpy(pwd_temp,pwd);
    strcat(pwd_temp,"/seed.txt");
    FILE *fp;
    fp = NULL;
    char numb;
    char *number = (char *)malloc(32*sizeof(char));
        fp = fopen(pwd_temp,"r");
        if(fp!=NULL)
        {
        for(i=0;i<=31;i++)
        {
            number[i] = '\0';
        }
        do{
                numb = fgetc(fp);
                if((int)(numb-'\n')!=0)
                {
                        Add_Char_String(number,numb);
                }else{
                        goto cont1;
                }
cont1:                     ;
        }while((int)(numb-'\n')!=0);
        len = strlen(number);
        sum = 0;
        for(i=0;i<=len-1;i++)
        {
            sum = sum + (int)(number[i]-'0')*Pow(10,len-i-1);
        }
        Ph_ran64 = (unsigned int)sum;

        if(number!=NULL)
        {
            free(number);
            number = NULL;
        }
        if(pwd_temp!=NULL)
        {
            free(pwd_temp);
            pwd_temp = NULL;
        }
        }else{
        printf("error !! file open failed!!");
        }
        if(fp!=NULL )
        {
        fclose(fp);
        fp = NULL;
        }
	sfmt_init_gen_rand(&Ph_sfmt,Ph_ran64);
}

int min_int(int i,int j)
{
    int res;
    if(i<j)
    {
        res = i;
    }
    if(j<i)
    {
        res = j;
    }
    if(i==j)
    {
        res = i;
    }
    return res;
}
