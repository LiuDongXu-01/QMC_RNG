#!/bash/bin/
p=`pwd`
arry=("607" "1279" "2281" "4253" "11213" "19937" "44497" "86243" "132049" "216091")
make_arry=("SFMT_MEXP=-DSFMT_MEXP=607" "SFMT_MEXP=-DSFMT_MEXP=1279" "SFMT_MEXP=-DSFMT_MEXP=2281" "SFMT_MEXP=-DSFMT_MEXP=4253" "SFMT_MEXP=-DSFMT_MEXP=11213" "SFMT_MEXP=-DSFMT_MEXP=19937" "SFMT_MEXP=-DSFMT_MEXP=44497" "SFMT_MEXP=-DSFMT_MEXP=86243" "SFMT_MEXP=-DSFMT_MEXP=132049" "SFMT_MEXP=-DSFMT_MEXP=216091")
	core=0
        while [ `echo "$core<10"|bc` -eq 1 ]
	do
		d="$core"
		cd $p
		make clean
		make ${make_arry[core]}
		cd $p/bin/Release
		mkdir ${arry[core]}
		mv QMC_test_v1 ${arry[core]}/QMC
		cd $p/
		core=`echo "scale=2;$core+1"|bc`
	done
