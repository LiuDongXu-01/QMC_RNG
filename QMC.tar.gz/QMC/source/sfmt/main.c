#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>
#include "datastruct.h"
#include "myfunction.h"
#include <string.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>


int main(int argc,char **argv)
{
	clock_t start_loop, stop_loop;  
	clock_t start_total,stop_total;  
	int i, j, I, count, istep, mstep, nbin, k;
    	double energy_first, energy_last;
	double CPU_time_loop = 0.0;
	double CPU_time_total;
	double head0, head1;
	double pi = 3.14159265358979324;
	int error, iss;
	char buffer[2048];
	char *pwd = argv[1]; 
    	paraenv = 0;
    	process_numb = 1;
    	my_rank = 0;
    	init(pwd);
    	Init_constant();
    	Read_Input(pwd);   
	Read_temping_para(pwd);
    	Print_Input_Para(pwd);  
	makelattice(Dim,Dim_x,Dim_y,Dim_z,Clust_Type,BC); /*Construction one-dimensional lattice*/
	
	Make_Vertex();	/*Get all possible Vertex, calculation all Vertics weight*/
	Wight_diag_shift(shift,pwd);/*Shift weight of all diagonal vertics to keep each vertics's weight large than 0*/
	Made_Trans_Vertex(pwd); /**/
	Init_Virtime();
	/*theromlization*/
	for(i=0;i<Istep;i++)
	{
		Diag_Update();
		Loop_Update1(2.0);
		Adjustcutoff();
	}
	/*theromliztion*/
	Init_Obser_Para();
	CPU_time_total = 0.0;
	for(i=0;i<Nbin;i++)
	{
		for(j=0;j<Mstep;j++)
		{
			start_total = clock();
		    	Diag_Update();
                  	Loop_Update1(0.125);
			stop_total = clock();
			CPU_time_total = CPU_time_total + (double)(stop_total-start_total)/CLOCKS_PER_SEC;
		   	Measure_Energy(i*Mstep + j);
			Measure_Mag(i*Mstep + j);
			Measure_Wind(i*Mstep + j);
		}
	}
	FILE *fp = NULL;
	char *pwd_temp = (char *)malloc(1024*sizeof(char));
    	strcpy(pwd_temp,pwd);
    	strcat(pwd_temp,"/MeasureCPU_time.txt");
    	fp = fopen(pwd_temp,"w+");
    	if(fp!=NULL)
    	{
		fprintf(fp,"%s%s","CPU Time","\n");
        	fprintf(fp,"%lf",CPU_time_total);
    	}
        fclose(fp);
        fp = NULL;
	if(pwd_temp!=NULL)
    	{
        	free(pwd_temp);
        	pwd_temp = NULL;
    	}
        Out_put_energy(pwd);
	Out_put_mag(pwd);
	Out_put_winding(pwd);
	Free_Gobal_Pointer();
        return 0;
}
