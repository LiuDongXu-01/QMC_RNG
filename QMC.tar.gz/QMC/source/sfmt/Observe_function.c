#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>
#include "datastruct.h"
#include "myfunction.h"
#include <string.h>
#include <time.h>


void Init_Obser_Para(void)
{
    int i = 0;
    int j = 0;
    int k = 0;

    Ob.energy = (double *)malloc(Nbin*Mstep*sizeof(double));
    Ob.energy1 = (double *)malloc(Nbin*Mstep*sizeof(double));
    Ob.energy_ken = (double *)malloc(Nbin*Mstep*sizeof(double));
    swap_times = 0;
    pararec = (int *)malloc(Nbin*Mstep*sizeof(int));
    tpararec = (int *)malloc(Nbin*Mstep*process_numb*sizeof(int));
    Ob.energy = (double *)malloc(Nbin*Mstep*sizeof(double));
    Ob.Mag = (double *)malloc(Nbin*Mstep*sizeof(double));
    Ob.Mag_sq = (double *)malloc(Nbin*Mstep*sizeof(double));
    Ob.Sf = (double *)malloc(Nbin*Mstep*sizeof(double));
    Ob.Wind = (double *)malloc(Nbin*Mstep*sizeof(double));
}

void Measure_Energy(int step)
{
    int i, j, off_num = 0;
    double temp;
    temp = (double)(nh)/Beta[paraenv] - energy_shift[paraenv]*Nbond;
    Ob.energy[step] = temp;
}

void Measure_Mag(int step)
{
    int i, j, off_num = 0;
    double mag = 0.0;
    double sf1 = 0.0;
    double sf2 = 0.0;
    for(i=0;i<Nsite;i++)
    {
	    mag = mag + (double)(Lattice[i]) - 0.5;
    }
    for(i=0;i<Nsite;i=i+2)
    {
	sf1 = sf1 + (double)(Lattice[i])-0.5;
    }
    for(i=1;i<Nsite;i=i+2)
    {
	sf2 = sf2 + (double)(Lattice[i])-0.5;
    }
    
    Ob.Mag[step] = mag;
    Ob.Mag_sq[step] = mag*mag;
    mag = (sf1-sf2);
    Ob.Sf[step] = mag*mag/(double)(Nsite*Nsite);
}

void Measure_Wind(int step)
{
    int i, bond;
    int r, l;
    int windx = 0;
    double winding;
    int test;
    for(i=0;i<MM;i++)
    {
	    if(Opstring[i][0]>1)
	    {
		bond = Opstring[i][2];
		r = Vertex_Sum[0][Opstring[i][1]];
		l = Vertex_Sum[1][Opstring[i][1]];
		if(bond < Nsite)
		{
			if(l < r)
			{
				windx = windx + 1;
			}
			if(r < l)
			{
				windx = windx - 1;
			}
		}
	    }else{
		    continue;
	    }
    }
    test = windx%Dim_x;
    if(test==0)
    {
	winding = (double)(windx/Dim_x);
	Ob.Wind[step] = winding*winding;
    }else{
	    printf("error happend when measure the winding number!!\n");
    }
}

int Minium(double *Disp, int dim)
{
	int i;
	int posi=0;
	double temp = Disp[0];
	for(i=1;i<dim;i++)
	{
		if(Disp[i] < temp)
		{
			posi = i;
			temp = Disp[i];
		}
	}
	return posi;
}
