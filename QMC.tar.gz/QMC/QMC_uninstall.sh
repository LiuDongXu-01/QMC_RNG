#!/bash/bin/
pd=`pwd`
cd $pd/source/sfmt/
make clean
rm -rf $pd/source/sfmt/bin/*
cd $pd/bin/
rm -rf  sfmt
cd $pd/source/well/
make clean
cd $pd/bin/
rm -rf well
cd $pd
