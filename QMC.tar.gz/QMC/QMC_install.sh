#!/bin/bash
pd=`pwd`
cd $pd/source/sfmt/
. run.sh
cd $pd/bin/
mkdir sfmt
cp -r $pd/source/sfmt/bin/Release/* $pd/bin/sfmt/
cd $pd/source/well/
make
cd $pd/bin/
mkdir well
cp $pd/source/well/bin/Release/QMC_test_v1 $pd/bin/well/QMC
cd $pd
